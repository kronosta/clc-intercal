package Language::INTERCAL::INET::Extend;

# extend bytecode, interpreter, splats and RC information for INTERNET code

# This file is part of CLC-INTERCAL

# Copyright (c) 2023 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use Carp;
use Fcntl qw(SEEK_SET SEEK_END);
use Net::Interface 1.0, qw(IPV6_ADDR_MULTICAST);
use Language::INTERCAL::ByteCode '1.-94.-2.1', qw(reg_name bc_skip BC_GUP);
use Language::INTERCAL::Splats '1.-94.-2.1', qw(faint SP_INTERNET SP_INVALID SP_NODIM);
use Language::INTERCAL::Server '1.-94.-2.1';
use Language::INTERCAL::Theft '1.-94.-2.1';
use Language::INTERCAL::Exporter '1.-94.-2';
use Language::INTERCAL::Interpreter '1.-94.-2.1';
use Language::INTERCAL::ArrayIO '1.-94.-2', qw(read_array_16 read_array_32);
use Language::INTERCAL::Rcfile '1.-94.-2';

use vars qw($VERSION $PERVERSION @EXPORT_OK);
($VERSION) = ($PERVERSION = "CLC-INTERCAL/Base INTERCAL/INET/Extend.pm 1.-94.-2.1") =~ /\s(\S+)$/;
@EXPORT_OK = qw(theft_server theft_default_server theft_callback);

my ($ipv6, $ip_class) = Language::INTERCAL::Server::has_ipv6();

if ($ipv6) {
    import Socket qw(AF_INET6);
    import Socket6 qw(inet_pton inet_ntop);
}

# our splats
use constant SP_CASE     => 900;
use constant SP_IPV6     => 901;

my ($reg_th, $theft_default_server);
my $reg_ar = reg_name('AR');
my $reg_io = reg_name('IO');

sub add_callback {
    my ($code, $ext, $module) = @_;
    $code->('new', \&_cb_new);
    $code->('run', \&_cb_run);
}

sub add_opcode {
    my ($code, $ext, $module) = @_;
    $code->('CSE', \&_i_cse);
    $code->('SMU', \&_i_smu);
    $code->('STE', \&_i_ste);
}

sub add_splat {
    my ($code, $ext, $module) = @_;
    $code->(SP_CASE, 'CASE', 'Implicit or explicit CASE failed: %');
	# A problem was encountered while looking for other INTERCAL
	# systems.
    $code->(SP_IPV6, 'IPV6', 'IPv6 Address Translation Problem: %');
	# The IPv6 Address Translation Table is full, or something
	# unexpected happened during the translation.
}

sub add_bytecode {
    my ($code, $ext, $module) = @_;
    $code->('STE', 'STEal', 'S', 45, 'C(E)C(E)C(R)'),
	# Followed by a count, I<count> expression, a second count, the
	# corresponding number of expressions, a third count and the
	# corresponding number of registers, defines a STEAL statement:
	# the first two counts should be #0 or #1, representing the presence
	# or absence of ON and FROM, respectively.
    $code->('SMU', 'SMUggle', 'S', 46, 'C(E)C(E)C(R)'),
	# Takes the same arguments as I<STE>, but defines a SMUGGLE statement.
    $code->('CSE', 'CaSE', 'S', 47, 'EC(ES)'),
	# Followed by an expression, a count and I<count> pairs of (expression,
	# statement), defines a CASE statement.
}

sub add_register {
    my ($code, $ext, $module) = @_;
    $code->('TH', '%', 'zeroone', 20, 0);
	# This register determines whether a program has been compiled
	# with INTERNET support. If the register is #0, the program
	# cannot be a victim of theft, but cannot steal or smuggle
	# anything; if the register is #1, the program has full network
	# support. If the register does not exist, the program will
	# splat trying to access it, but in any case would splat when
	# trying any network operation.
}

sub add_rcdef {
    my ($code, $ext, $module) = @_;
    $code->('BLURT', \&_c_blurt, undef, 0, 0, 'Default INETERNET port');
    $code->('READ', \&_c_read, \&_p_read, 1, 0, 'Default IPv6 multicast groups');
    $code->('THROW', \&_c_throw, \&_p_throw, 1, 0, 'Default IPv6 multicast hop limits');
}

sub _c_blurt {
    my ($rc, $mode, $ln) = @_;
    # port 0 means disable INTERNET functionality so we allow it
    $ln =~ /^(\d+)\s*$/ && $1 >= 0 && $1 < 65536 and return $1;
    die "Invalid value for $mode\: $ln\n";
}

sub _c_read {
    my ($rc, $mode, $ln) = @_;
    $ipv6 or return ''; # we won't be using this...
    my $limit;
    if ($ln =~ s/\b\s*THROWING\s*(\d+)\s*$//i) {
	$limit = $1;
	$limit >= 0 && $limit <= 255 or die "Invalid multicast hop limit: $limit\n";
    }
    my $v = inet_pton(&AF_INET6, $ln);
    defined $v or die "Invalid IPv6 address: $ln\n";
    my $type = Net::Interface->type($v);
    $type & IPV6_ADDR_MULTICAST or die "Not a multicast address: $ln\n";
    [$v, $limit];
}

sub _p_read {
    my ($value) = @_;
    my ($addr, $limit) = @$value;
    my $prn = inet_ntop(&AF_INET6, $addr);
    defined $limit and $prn .= " THROWING $limit";
    $prn;
}

sub _c_throw {
    my ($rc, $mode, $ln) = @_;
    $ipv6 or return ''; # we won't be using this...
    my $scope;
    if ($ln =~ s/\b\s*TO\s*(\d+)\s*$//i) {
	$scope = $1;
	$scope >= 0 && $scope <= 15 or die "Invalid multicast scope: $scope\n";
    }
    $ln =~ /^\s*(\d+)\s*$/ && $1 >= 0 && $1 <= 255 or die "Invalid multicast hop limit: $ln\n";
    [$1, $scope];
}

sub _p_throw {
    my ($value) = @_;
    my ($limit, $scope) = @$value;
    defined $scope and $limit .= " TO $scope";
    $limit;
}

sub _add_server {
    my ($int) = @_;
    $reg_th ||= reg_name('TH');
    my $th = $int->{default}{registers}{$reg_th};
    ! ($int->{compiling} & 1) && $th->{value} && $th->{value}->number or return;
    $int->{server} ||= Language::INTERCAL::Server->new;
    $theft_default_server ||=
	Language::INTERCAL::Theft->new($int->{server}, $int->{rc}, \&_theft, $int);
    $int->{theft_server} ||= $theft_default_server;
}

sub _cb_new {
    my ($int) = @_;
    $int->{theft_server} = $theft_default_server;
    $int->{theft_callback} = 0;
}

sub _cb_run {
    my ($int) = @_;
    _add_server($int);
}

# INTERPRETER functions we need
*_a = \&Language::INTERCAL::Interpreter::_a;
*_create_register = \&Language::INTERCAL::Interpreter::_create_register;
*_get_expression = \&Language::INTERCAL::Interpreter::_get_expression;
*_get_number = \&Language::INTERCAL::Interpreter::_get_number;
*_interleave = \&Language::INTERCAL::Interpreter::_interleave;
*_run = \&Language::INTERCAL::Interpreter::_run;
*_uninterleave = \&Language::INTERCAL::Interpreter::_uninterleave;
*_set_read_charset = \&Language::INTERCAL::Interpreter::_set_read_charset;

sub _theft {
    my ($type, $reg, $id, $theft, $int) = @_;
    my @res = eval {
	$reg =~ /^[\.,:;\@]/
	    or return '551 Invalid register type';
	if (! exists $int->{default}{registers}{$reg}) {
	    $reg =~ /^\@/ and return '552 No such register';
	    # we'll have to create the register
	    _create_register($int, $int->{default}, 'theft', $reg, {});
	}
	my $rp = $int->{default}{registers}{$reg};
	# check if they are allowed to steal it
	my $stealing = uc($type) eq 'STEAL';
	$stealing && $rp->{ignore}
	    and return '553 Cannot steal this, try smuggling';
	! $stealing && ! $rp->{ignore}
	    and return '554 Cannot smuggle this, try stealing';
	if ($int->{theft_callback}) {
	    &{$int->{theft_callback}}($int, $type, $reg)
		or return '555 Failed due to internal policy';
	}
	my @val = ();
	my $value = $rp->{value};
	if ($value->isa('Language::INTERCAL::Whirlpool')) {
	    # export filehandle
	    my $fh = $value->filehandle;
	    if ($fh) {
		my $rcs = $fh->read_charset;
		my $wcs = $fh->write_charset;
		my $mode = $fh->mode;
		my $port = _fh_export($theft->server, $fh);
		push @val, "$reg <- #$port BY ?$rcs BY ?$wcs BY ?$mode";
		# the following prevents the filehandle being garbage-collected
		# after being stolen
		$int->{stolen}{$fh} = $fh if $stealing;
	    }
	    for my $elem ($value->tail->sparse_list) {
		my ($n, $e) = @$elem;
		push @val, "$reg SUB #$e <- #" . ($n->number);
	    }
	    $value->nuke if $stealing;
	} elsif ($value->isa('Language::INTERCAL::Arrays')) {
	    # export array
	    my @s = $value->subscripts;
	    @s or return "550 Array not dimensioned";
	    push @val, "$reg <- " . join(' BY ', map { "#$_" } @s);
	    for my $elem ($value->sparse_list) {
		my ($n, @e) = @$elem;
		if ($n->number > 65535) {
		    my ($n1, $n2) = _uninterleave(2, $n);
		    $n1 = $n1->number;
		    $n2 = $n2->number;
		    $n = "#$n1 \xa2 #$n2";
		} else {
		    $n = '#' . ($n->number);
		}
		push @val, "$reg " . join(' ', map { "SUB #$_" } @e) . " <- $n";
	    }
	    $value->assign([]) if $stealing;
	} else {
	    # export number
	    my $n;
	    if ($value->number > 65535) {
		my ($n1, $n2) = _uninterleave(2, $value);
		$n1 = $n1->number;
		$n2 = $n2->number;
		$n = "#$n1 \xa2 #$n2";
	    } else {
		$n = '#' . ($value->number);
	    }
	    push @val, "$reg <- $n";
	    $value->assign(0) if $stealing;
	}
	return ('250 Here it is', @val, '.');
    };
    # if we get here, we didn't get to "return", so...
    $@ or return @res;
    chomp $@;
    $@ =~ s/\s+/ /g;
    $@ =~ s/^ //;
    $@ =~ s/ $//;
    return "550 $@";
}

sub _i_smu {
    my ($int, $tp, $name, $runenv, $cp, $ep) = @_;
    _ii_ste($int, $tp, $name, $runenv, $cp, $ep, 'SMUGGLE');
}

sub _i_ste {
    my ($int, $tp, $name, $runenv, $cp, $ep) = @_;
    _ii_ste($int, $tp, $name, $runenv, $cp, $ep, 'STEAL');
}

sub _ii_ste {
    my ($int, $tp, $name, $runenv, $cp, $ep, $operation) = @_;
    $int->{theft_server}
	or faint(SP_INVALID,
		 "This program is not allowed to $operation",
		 $name);
    my $theft = $int->{theft_server};
    my $servertype = _get_number($int, $tp, $name, $runenv, $cp, $ep, 0);
    faint(SP_INVALID, "$servertype expressions", $name)
	if $servertype < 0 || $servertype > 1;
    my ($server, $bc_mc);
    if ($servertype) {
	$server = _get_number($int, $tp, $name, $runenv, $cp, $ep, 0);
	($server, $bc_mc) = $theft->decode_address($server, 1);
    }
    my $pid;
    my $pidtype = _get_number($int, $tp, $name, $runenv, $cp, $ep, 0);
    faint(SP_INVALID, "$pidtype expressions", $name)
	if $pidtype < 0 || $pidtype > 1;
    $pidtype
	and $pid = _get_number($int, $tp, $name, $runenv, $cp, $ep, 0);
    if (! $servertype || defined $bc_mc) {
	# go looking for a server
	my @ips = $theft->find_theft_servers($bc_mc, $pid);
	@ips or faint(SP_CASE, 'No servers found admitting to run ' . ($pid ? $pid : 'INTERCAL'));
	$server = $ips[int(rand(scalar @ips))];
    }
    my $port;
    if (! $pidtype) {
	# get a random pid from server
	my %pids = $theft->pids_and_ports($server);
	my @pids = keys %pids;
	@pids or faint(SP_INTERNET, $server, 'Server does not run anything');
	$pid = $pids[int(rand(scalar @pids))];
	$port = $pids{$pid};
    }
    $theft->start_request($server, $pid, $port, $operation);
    eval {
	my $num = _get_number($int, $tp, $name, $runenv, $cp, $ep, 0);
	while ($num-- > 0) {
	    _run($int, $tp,
		 _a($runenv, assign => \&_x_ste, name => $name, server => $server),
		 $cp, $ep, 1);
	}
    };
    my $err = $@;
    # make sure we always call finish_request(), even if the theft splats
    $theft->finish_request;
    $err and die $err;
}

sub _x_ste {
    my ($int, $tp, $runenv, $cp, $ep, $type, $reg) = @_;
    $type eq 'R'
	or faint(SP_INVALID, 'Not a register', $runenv->{name});
    _create_register($int, $tp, $runenv->{name}, $reg, $runenv);
    my @v = $int->{theft_server}->request($reg);
    my $r = $tp->{registers}{$reg};
    my $i = $r->{ignore};
    return if $i;
    my @ops = ();
    my $server = $runenv->{server};
    for my $v (@v) {
	$v =~ s/\s+//g;
	substr($v, 0, length($reg)) eq $reg
	    or faint(SP_INTERNET, $server, "Wrong register received ($v) expected ($reg)");
	substr($v, 0, length($reg)) = '';
	$v =~ s/^(.*)<-//
	    or faint(SP_INTERNET, $server, "Value received ($v) is not an assignment");
	my $d = $1;
	if ($v =~ /^#(\d+)BY\?(\S+)BY\?(\S+)BY\?(\S+)$/) {
	    substr($reg, 0, 1) eq '@'
		or faint(SP_INTERNET, $server, "Filehandle data received for non-class register $reg");
	    my $port = $server . ':' . $1;
	    my $rcs = $2;
	    my $wcs = $3;
	    my $mode = $4;
	    $v = Language::INTERCAL::GenericIO->new('REMOTE', $mode, $port, $int->{server});
	    $v->read_charset($rcs);
	    $v->write_charset($wcs);
	} elsif ($v =~ s/^#(\d+)BY//i) {
	    my @sub = ($1);
	    $reg =~ /^[,;]/
		or faint(SP_INTERNET, $server, "Array dimension received for non array register $reg");
	    while ($v =~ s/^#(\d+)BY//i) {
		push @sub, $1;
	    }
	    $v =~ /^#(\d+)$/ or faint(SP_INTERNET, $server, "Invalid dimension ($v) received for $reg");
	    push @sub, $1;
	    $v = Language::INTERCAL::Arrays::Tail->from_list(\@sub);
	} elsif ($v =~ /^#(\d+)$/) {
	    $v = Language::INTERCAL::Numbers::Spot->new($1);
	} elsif ($v =~ /^#(\d+)\s*\xa2\s*#(\d+)$/) {
	    my ($v1, $v2) = ($1, $2);
	    $v = _interleave(2,
			    Language::INTERCAL::Numbers::Spot->new($v1),
			    Language::INTERCAL::Numbers::Spot->new($v2));
	} else {
	    faint(SP_INTERNET, $server, "Value ($v) syntax error");
	}
	if ($d eq '') {
	    push @ops, [$v, undef];
	} else {
	    my @t;
	    while ($d ne '') {
		my $orig = $d;
		$d =~ s/^SUB\s*#(\d+)\s*// && $1 < 65536
		    or faint(SP_INTERNET, $server, "Subscript ($orig) syntax error");
		push @t, $1;
	    }
	    push @ops, [$v, \@t];
	}
    }
    $r->{value}->nuke if $r->{value}->can('nuke');
    for my $op (@ops) {
	my ($v, $s) = @$op;
	$r->{value}->use($s, $v);
    }
    undef;
}

sub _i_cse {
    my ($int, $tp, $name, $runenv, $cp, $ep) = @_;
    $int->{theft_server}
	or faint(SP_INVALID, "This program is not allowed to CASE", $name);
    my $e = _get_expression($int, $tp, $name, $runenv, $cp, $ep, 1);
    ref $e or faint(SP_INVALID, "Not an expression", $name);
    my @l = ();
    if (UNIVERSAL::isa($e, 'Language::INTERCAL::Numbers')) {
	my $addr = $e->number;
	my $bc;
	($addr, $bc) = $int->{theft_server}->decode_address($addr, 1);
	if (defined $bc) {
	    my @ips = $int->{theft_server}->find_theft_servers($bc);
	    @l = map { $int->{theft_server}->encode_address($_) } @ips;
	} else {
	    @l = $int->{theft_server}->pids($addr);
	}
    } elsif (ref $e eq 'ARRAY') {
	# assume it is a tail array
	my $io = $tp->{registers}{$reg_io}{value}->number;
	_create_register($int, $tp, $name, $reg_ar, $runenv);
	my $ar = $tp->{registers}{$reg_ar}{value}->number;
	my $data = '';
	my $fh = Language::INTERCAL::GenericIO->new('STRING', 'r', \$data);
	_set_read_charset($int, $tp, $fh);
	read_array_16($io, \$ar, $fh, $e, 1);
	$tp->{registers}{$reg_ar}{value}->assign($ar);
	@l = $int->{theft_server}->dns_lookup($data);
    } elsif (UNIVERSAL::isa($e, 'Language::INTERCAL::Arrays')) {
	my $io = $tp->{registers}{$reg_io}{value}->number;
	_create_register($int, $tp, $name, $reg_ar, $runenv);
	my $ar = $tp->{registers}{$reg_ar}{value}->number;
	my @v = map { $_->number } $e->as_list;
	@v or faint(SP_NODIM);
	my $data = '';
	my $fh = Language::INTERCAL::GenericIO->new('STRING', 'r', \$data);
	_set_read_charset($int, $tp, $fh);
	if ($e->bits <= 16) {
	    read_array_16($io, \$ar, $fh, \@v, 0);
	} else {
	    read_array_32($io, \$ar, $fh, \@v, 0);
	}
	$tp->{registers}{$reg_ar}{value}->assign($ar);
	@l = $int->{theft_server}->dns_lookup($data);
    } else {
	faint(SP_INVALID, 'Expression type', $name);
    }
    my $num = _get_number($int, $tp, $name, $runenv, $cp, $ep, 0);
    # I don't think the grammar makes it possible to have $num == 0
    # however an assembler program can do anything, so we might as
    # well check; if there are no expressions, then by definition
    # all values are discarded.
    $num > 0 or return undef;
    # the documentation and the original post to alt.lang.intercal require
    # to first assign to all expressions, then execute all statements; this
    # is obviously awkward both to the programmer and to the implementer
    # but there we go...
    my @stmt;
    while ($num-- > 0) {
	# first assign to expression
	_run($int, $tp, _a($runenv, assign => sub { _x_cse(\@l, @_) }), $cp, $ep, 1);
	# then skip the statement and remember where it was
	my $len = bc_skip($int->{code}, $$cp, $ep)
	    or faint(SP_INVALID, '(unknown)', $name);
	$len > 0 or faint(SP_INVALID, 'empty statement', $name);
	my $ge = ord(substr($int->{code}, $$cp, 1));
	my $ab = $ge != BC_GUP && exists $tp->{ab_gerund}{$ge}
	       ? $tp->{ab_gerund}{$ge}
	       : 0;
	$ab or push @stmt, $$cp;
	$$cp += $len;
    }
    my $end = $$cp;
    for my $stmt (@stmt) {
	defined $stmt or next;
	$$cp = $stmt;
	_run($int, $tp, $runenv, $cp, $ep, 1);
    }
    $$cp = $end;
    undef;
}

sub _x_cse {
    my ($values, $int, $tp, $runenv, $cp, $ep, $type, $reg) = @_;
    @$values or return undef; # skip assignment if we ran out of values
    if ($type eq 'N') {
	# assign the next value to a number
	my $val = shift(@$values);
	my $bits = $val < 0x10000 ? 16 : 32;
	return Language::INTERCAL::Numbers->new($bits, $val);
    }
    $type eq 'R'
	or faint(SP_INVALID, 'Neither a number nor a register?', 'CSE');
    _create_register($int, $tp, $runenv->{name}, $reg, $runenv);
    my $i = $tp->{registers}{$reg}{ignore};
    my $e = $tp->{registers}{$reg}{value};
    if (UNIVERSAL::isa($e, 'Language::INTERCAL::Numbers')) {
	# assigning to a register, we'll take a single value
	my $val = shift(@$values);
	$e->assign($val) unless $i;
    } elsif (UNIVERSAL::isa($e, 'Language::INTERCAL::Arrays')) {
	# assigning to an array, we need to iterate over all elements
	# until we either run out of array or run out of values
	my $dim = $e->elements or faint(SP_NODIM);
	if ($i) {
	    $dim > @$values and $dim = @$values;
	    splice(@$values, 0, $dim);
	} else {
	    $e->partial_replace($values);
	}
    } elsif (UNIVERSAL::isa($e, 'Language::INTERCAL::Whirlpool')) {
	# we do not know how to assign to a whirlpool
	faint(SP_INVALID, "Cannot use whirlpool registers", 'CSE');
    } else {
	# we do not know how to assign to a whirlpool
	faint(SP_INVALID, "Unknown register value", 'CSE');
    }
    undef;
}

# functions used while exporting a filehandle

sub _fh_export {
    my ($server, $fh) = @_;
    $fh->{exported} and return $fh->{exported};
    my $port = $server->tcp_listen(\&_fh_open, \&_fh_line, \&_fh_close, $fh);
    $fh->{exported} = $port;
    $port;
}

sub _fh_open {
    my ($id, $sockhost, $peerhost, $close, $fh) = @_;
    $fh->{importers}{$id} = 0;
    return "202 $sockhost ($VERSION)";
}

sub _fh_line {
    my ($server, $id, $close, $line, $fh) = @_;
    exists $fh->{importers}{$id}
	or return "580 Internal error in server";
    my $filepos = $fh->{importers}{$id};
    if ($line =~ /^\s*TELL/i) {
	my $pos = eval { $fh->tell; };
	$@ || ! defined $pos and return "581 Not seekable";
	return "280 $filepos is the current file position";
    }
    if ($line =~ /^\s*SEEK\s+(-?\d+)\s+(SET|CUR|END)/i) {
	my ($delta, $whence) = ($1, uc $2);
	exists $fh->{seek_code} or return "581 Not seekable";
	if ($whence eq 'SET') {
	    $delta < 0 and return "582 Invalid file position";
	    $filepos = $delta;
	} elsif ($whence eq 'CUR') {
	    $filepos += $delta;
	    $filepos < 0 and return "582 Invalid file position";
	} else {
	    my $delta = $delta;
	    my $curpos;
	    $@ = '';
	    eval {
		my $oldpos = $fh->tell;
		$fh->seek(0, SEEK_END);
		$curpos = $fh->tell;
		$oldpos = $fh->seek($oldpos, SEEK_SET);
	    };
	    $@ and return "583 Cannot use SEEK_END on this filehandle";
	    $filepos = $curpos + $delta;
	    $filepos < 0 and return "582 Invalid file position";
	}
	$fh->{importers}{$id} = $filepos;
	return "281 $filepos is the new file position";
    }
    if ($line =~ /^\s*WRITE\s+(\d+)/i) {
	my $size = $1;
	exists $fh->{seek_code} and $fh->{seek_code}->($filepos, SEEK_SET);
	$@ = '';
	my $data = eval { $fh->write_binary($size) };
	if ($@) {
	    $@ =~ s/\n+/ /g;
	    return "584 $@";
	}
	eval {
	    exists $fh->{tell_code}
		and $fh->{importers}{$id} = &{$fh->{tell_code}}();
	};
	my $len = length $data;
	$server->read_out($id, "282 $len");
	$server->read_binary($id, $data);
	return ();
    }
    if ($line =~ /^\s*WRITE\s+TEXT\s+\/(\S*)\//i) {
	my $newline = $1;
	$newline =~ s/!(\d{3})/chr($1)/ge;
	$@ = '';
	my $data = eval {
	    exists $fh->{seek_code}
		and $fh->{seek_code}->($filepos, SEEK_SET);
	    $fh->write_text($newline);
	};
	if ($@) {
	    $@ =~ s/\n+/ /g;
	    return "584 $@";
	}
	eval {
	    exists $fh->{tell_code}
		and $fh->{importers}{$id} = &{$fh->{tell_code}}();
	};
	my $len = length $data;
	$server->read_out($id, "282 $len");
	$server->read_binary($id, $data);
	return ();
    }
    if ($line =~ /^\s*READ\s+(\d+)/i) {
	my $len = $1;
	my $code = sub {
	    my $data = shift;
	    defined $data && length($data) == $len
		or return "585 Data size mismatch";
	    $@ = '';
	    eval {
		exists $fh->{seek_code}
		    and $fh->{seek_code}->($filepos, SEEK_SET);
		$fh->read_binary($data);
	    };
	    if ($@) {
		$@ =~ s/\n+/ /g;
		return "586 $@";
	    }
	    eval {
		exists $fh->{tell_code}
		    and $fh->{importers}{$id} = &{$fh->{tell_code}}();
	    };
	    return "283 OK";
	};
	$server->alternate_callback($id, $len, $code);
	return "383 OK, send the data";
    }
    if ($line =~ /^\s*THANKS/i) {
	$$close = 1;
	return "284 You are welcome";
    }
    if ($line =~ /^\s*ISTERM/i) {
	my $isit = eval { $fh->is_terminal; };
	$@ || ! defined $isit and return "587 Information not available";
	$isit and return "285 Yes";
	return "286 No";
    }
    return "589 Command not understood";
}

sub _fh_close {
    my ($id, $fh) = @_;
    delete $fh->{importers}{$id};
}


# The following functions are supposed to be called with an INTERPRETER

sub theft_callback {
    @_ == 1 || @_ == 2
	or croak "Usage: theft_callback(INTERPRETER [, CODE])";
    my ($int) = shift;
    my $rv = $int->{theft_callback};
    $int->{theft_callback} = shift if @_;
    $rv;
}

sub theft_server {
    @_ == 1 || @_ == 2
	or croak "Usage: theft_server(INTERPRETER [, NEW_SERVER])";
    my $int = shift;
    my $old_server = $int->{theft_server};
    $int->{theft_server} = shift if @_;
    $old_server;
}

sub theft_default_server {
    @_ == 0 || @_ == 1
	or croak "Usage: theft_default_server [(NEW_SERVER)]";
    my $old_server = $theft_default_server;
    $theft_default_server = shift if @_;
    $old_server;
}

1
