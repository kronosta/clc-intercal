This is the resurrected CLC-INTERCAL compiler, starting with (per)version
1.-94.-2 from the author's own archives, now back in active development.

CLC-INTERCAL 1.-94.-2.1 has just escaped and is available from
[the download page](https://uilebheist.srht.site/dist/CLC-INTERCAL-1.-94.-2.1)
Older (per)versions are also available as downloadable tarballs.

This README file is part of the "Bundle" distribution, which contains
CLC-INTERCAL and all its optional components, each in its own separate
subdirectory, plus a number of other useful things in the "bonus"
directory. To install the components separately, refer to their own
README files, to install the whole bundle read on.

A working perl installation with the ability to install modules is
necessary to install CLC-INTERCAL, since most of it is written
in Perl; what is not written in Perl is written in INTERCAL and the
build system will take care to bootstrap the process.

Additionally, the INET package needs the following modules:

    Net::Interface           version 1.0 or newer, necessary
    Socket6                  necessary for IPv6
    IO::Socket::INET6        necessary for IPv6

Socket6 and IO::Socket::INET6 are very likely to be offered as pre-built
packages for most systems, if not they can be obtained from CPAN and
built from sources.

For Net::Interface, we found that the Debian package (libnet-interface-perl)
and the FreeBSD one (p5-Net-Interface) worked fine, but the NetBSD
package had a problem which meant it could not be used; OpenBSD and
Gentoo don't provide packages for it: in all these cases, building
it from source is easy enough, please see the [INSTALL file](INSTALL.md)
for information on how to find the sources, and a necessary patch to
make it work on all the systems we tested it on. There are other Perl
modules which provide similar functionality, but Net::Interface is
the only one which worked on all our test systems except NetBSD, and
for the latter it was a very simple patch to make it work.

The Bundle also includes the INTERCAL calculator, "intercalc", which
can use one of several user interfaces depending on what's installed
and the environment it runs on. The "batch" mode which just gets
expressions and statements from standard input and produces results on
standard output is always available, but the remaining interfaces
require some extra Perl modules to run:

    Term::ReadLine::Gnu      for line-based interface with editing and history
    Curses                   for a full-screen text interface
    Gtk3 or Gtk2             for X-based interface

All our test systems provided packages for these except NetBSD which
did not have a Gtk2 or Gtk3 package available prebuilt for download.

For more information about the required and recommended dependencies
and the packages to install on various operating systems, please see
[INSTALL file](INSTALL.md) or the
[online documentation](https://uilebheist.srht.site/docs/index.html#installing)

After installing the dependencies, to build the package use the standard
sequence of commands:

    perl Makefile.PL
    make
    make test              <- see note below about INET tests
    make install           <- as root or sudo

The "make test" includes testing of the INET (INTERNET) module,
and many of these tests require a working network connection able to
perform simple DNS queries: this may not be possible in a sandboxed build
environment, so these tests would fail. To skip these tests, create a file
"CLC-INTERCAL-INET/t/.skip-network" before running "make test". Some tests
use a network connection to localhost and will still run: to also disable
these tests, create a file "CLC-INTERCAL-INET/t/.skip-localhost" as well.
Delete these files again and re-run "make test" to re-enable the tests.

For more information please refer to the documentation in the "Docs"
package, which is included in directory CLC-INTERCAL-Docs/doc/html

The original README file for CLC-INTERCAL 1.-94.-2 can be found in the
CLC-INTERCAL-Base directory, where it describes how to install the base
system; other extensions have their own separate README. Note however that
such installation instructions are unnecessary if you install the whole
bundle using the instructions in this file.

The project is now hosted as a [git repository on
SourceHut](https://git.sr.ht/~uilebheist/CLC-INTERCAL) with a
[todo / bug-tracking list](https://todo.sr.ht/~uilebheist/CLC-INTERCAL)
in the unlikely case somebody uses this and finds a bug.

Also available: the [online documentation](https://uilebheist.srht.site/docs/)
is the same as the documentation found in the "Docs" package, but may
contain information about changes to the compiler which will form part
of a future escape. All older escapes are available for download on the
[download page](https://uilebheist.srht.site/dist/)

The Esolang wiki has an
[article about CLC-INTERCAL](https://esolangs.org/wiki/CLC-INTERCAL) which
complements the documentation in the distribution.

