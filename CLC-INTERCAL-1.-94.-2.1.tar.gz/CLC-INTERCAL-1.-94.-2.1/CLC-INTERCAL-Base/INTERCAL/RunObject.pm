package Language::INTERCAL::RunObject;

# Runtime for programs compiled to a Perl executable

# This file is part of CLC-INTERCAL

# Copyright (c) 2023 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($VERSION $PERVERSION);
($VERSION) = ($PERVERSION = "CLC-INTERCAL/Base INTERCAL/RunObject.pm 1.-94.-2.1") =~ /\s(\S+)$/;

use Carp;
use Getopt::Long;
use Language::INTERCAL::Exporter '1.-94.-2.1';
use Language::INTERCAL::GenericIO '1.-94.-2.1';
use Language::INTERCAL::Interpreter '1.-94.-2.1';
use Language::INTERCAL::Server '1.-94.-2.1';
use Language::INTERCAL::Rcfile '1.-94.-2.1';
use Language::INTERCAL::Extensions '1.-94.-2.1', qw(load_extension);
use vars qw(@EXPORT_OK);
@EXPORT_OK = qw(run_object);

sub run_object {
    my @extensions = @_;
    for my $extension (@extensions) {
	load_extension($extension);
    }
    my $rc = Language::INTERCAL::Rcfile->new();
    if (defined &Getopt::Long::Configure) {
        Getopt::Long::Configure qw(no_ignore_case auto_abbrev permute bundling pass_through);
    } else {
        $Getopt::Long::ignorecase = 0;
        $Getopt::Long::autoabbrev = 1;
        $Getopt::Long::order = $Getopt::Long::PERMUTE;
        $Getopt::Long::bundling = 1;
    }
    my $wimp = 0;
    my $trace = 0;
    my $stdtrace = undef;
    GetOptions(
        'wimp!'      => \$wimp,
        'trace!'     => \$trace,
        'stdtrace=s' => \$stdtrace,
        'nouserrc'   => sub { $rc->setoption('nouserrc', 1) },
        'nosystemrc' => sub { $rc->setoption('nosystemrc', 1) },
        'rcfile=s'   => sub { $rc->setoption(@_) },
    );
    $rc->load(1);
    my $fh;
    {
	my $caller = caller;
	no strict 'refs';
	$fh = Language::INTERCAL::GenericIO->new('FILE', 'w', \*{"$caller\::DATA"});
    }
    my $int = Language::INTERCAL::Interpreter->write($rc, $fh, 1);
    if (defined $stdtrace) {
        $trace = 1;
        my $mode = $stdtrace =~ s/^([ra]),//i ? lc($1) : 'r';
        my $th = Language::INTERCAL::GenericIO->new('FILE', $mode, $stdtrace);
        $int->setreg('@TRFH', $th);
    }
    $int->setreg('%WT', $wimp);
    $int->setreg('%TM', $trace);
    $int->setreg('^AV', \@ARGV);
    $int->setreg('^EV', [map { "$_=$ENV{$_}" } keys %ENV]);
    $int->server(Language::INTERCAL::Server->new());
    $int->start()->run()->stop();
}

1;
