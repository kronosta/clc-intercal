package Language::INTERCAL::Interpreter::State;

# Extends Interpreter with something to save its state and other internal things

# This file is part of CLC-INTERCAL

# Copyright (c) 2006-2008, 2023 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($VERSION $PERVERSION @ISA @EXPORT_OK);
($VERSION) = ($PERVERSION = "CLC-INTERCAL/Base INTERCAL/Interpreter/State.pm 1.-94.-2.2") =~ /\s(\S+)$/;

use Carp;
use Language::INTERCAL::Exporter '1.-94.-2';
use Language::INTERCAL::Interpreter '1.-94.-2.2', qw(
    reg_value reg_default reg_overload
    thr_ab_gerund thr_ab_label thr_ab_once thr_assign thr_grammar_record thr_registers thr_rules thr_stash
);

@ISA = qw(Language::INTERCAL::Interpreter);

use Language::INTERCAL::Splats '1.-94.-2.1', qw(faint SP_INTERNAL);
use Language::INTERCAL::RegTypes '1.-94.-2.2',
    qw(REG_spot REG_twospot REG_tail REG_hybrid REG_whp);
use Language::INTERCAL::ByteCode '1.-94.-2.2',
    qw(BC_CON BC_SWA BC_CRE BC_DES);
use Language::INTERCAL::Arrays '1.-94.-2.2',
    qw(make_list make_sparse_list list_subscripts make_array expand_sparse_list replace_array);

use constant STATE_SKIP_ONCE => 0x01;
use constant STATE_OVERRIDE  => 0x02;

@EXPORT_OK = qw(STATE_SKIP_ONCE STATE_OVERRIDE);

sub gave_up {
    @_ == 1 or croak "Usage: INTERPRETER->gave_up";
    my ($int) = @_;
    $int->{gave_up};
}

sub getrules {
    @_ == 2 or croak "Usage: INTERPRETER->getrules(GRAMMAR)";
    my ($int, $gra) = @_;
    my $rp = $int->{default}[thr_rules][$gra - 1] || [];
    wantarray ? ($rp, $int->{rules}) : $rp;
}

sub record_grammar {
    @_ == 2 or croak "Usage: INTERPRETER->record_grammar(HOW)";
    my ($int, $how) = @_;
    $int->{record_grammar} = $how;
    $int;
}

sub get_abstains {
    @_ == 1 or croak "Usage: INTERPRETER->get_abstains";
    my ($int) = @_;
    my $tp = $int->{default};
    my @labels = keys %{$tp->[thr_ab_label]};
    my @gerunds = keys %{$tp->[thr_ab_gerund]};
    my @onces = keys %{$tp->[thr_ab_once]};
    my $text = "ABR\n";
    $text .= pack('vvvv', $int->{ab_count}, scalar @labels, scalar @gerunds, scalar @onces);
    for my $l (@labels) {
	$text .= pack('vvv', $l, @{$tp->[thr_ab_label]{$l}});
    }
    for my $g (@gerunds) {
	$text .= pack('vvv', $g, @{$tp->[thr_ab_gerund]{$g}});
    }
    for my $o (@onces) {
	my ($u, $s) = split(/\./, $o);
	$text .= pack('vvvv', $u, $s, @{$tp->[thr_ab_once]{$o}});
    }
    $text;
}

sub set_abstains {
    @_ == 2 || @_ == 3
	or croak "Usage: INTERPRETER->set_abstains(DATA [, SKIP_ONCE])";
    my ($int, $text, $skip_once) = @_;
    $text =~ s/^ABR\n// or croak "Invalid abstain DATA";
    my ($count, $lc, $gc, @r) = unpack('v*', $text);
    defined $gc or croak "Invalid abstain DATA";
    my $oc = 0;
    if (! $skip_once) {
	@r or croak "Invalid abstain DATA";
	$oc = shift @r;
    }
    @r == 3 * ($lc + $gc + $oc) or croak "Invalid abstain DATA";
    my $tp = $int->{default};
    # create new abstain records
    $tp->[thr_ab_label] = {};
    $tp->[thr_ab_gerund] = {};
    $skip_once or $tp->[thr_ab_once] = {};
    $int->{ab_count} = $count;
    for (my $l = 0; $l < $lc; $l++) {
	my $n = shift @r;
	my $a = shift @r;
	my $c = shift @r;
	$tp->[thr_ab_label]{$n} = [$a, $c];
    }
    for (my $g = 0; $g < $gc; $g++) {
	my $n = shift @r;
	my $a = shift @r;
	my $c = shift @r;
	$tp->[thr_ab_gerund]{$n} = [$a, $c];
    }
    for (my $o = 0; $o < $oc; $o++) {
	my $u = shift @r;
	my $s = shift @r;
	my $a = shift @r;
	my $c = shift @r;
	$tp->[thr_ab_once]{"$u.$s"} = [$a, $c];
    }
    $int;
}

sub get_grammar_record {
    @_ == 1 or croak "Usage: INTERPRETER->get_grammar_record";
    my ($int) = @_;
    my $tp = $int->{default};
    my $gr = $tp->[thr_grammar_record];
    my $text = "GRR\n";
    my %smap = ();
    $text .= pack('v', scalar(@$gr));
    for my $g (@$gr) {
	$text .= chr($g->[0]);
	if ($g->[0] == BC_CON || $g->[0] == BC_SWA) {
	    $text .= pack('CC', $g->[1], $g->[2]);
	    next;
	}
	$g->[0] == BC_CRE || $g->[0] == BC_DES
	    or faint(SP_INTERNAL, "get_grammar_record found invalid record");
	$text .= pack('v', $g->[1]);
	$text .= _pack_symbol($int, $g->[2], \%smap);
	$text .= _pack_left($int, $g->[3], \%smap);
	$g->[0] == BC_CRE
	    and $text .= _pack_right($int, $g->[4], \%smap);
    }
    $text;
}

sub set_grammar_record {
    @_ == 2 or croak "Usage: INTERPRETER->set_grammar_record(DATA)";
    my ($int, $text) = @_;
    $text =~ s/^GRR\n// or croak "Invalid DATA";
    my ($gcount) = unpack('v', substr($text, 0, 2, ''));
    my $tp = $int->{default};
    my @smap = ();
    my @gr = ();
    for (my $n = 0; $n < $gcount; $n++) {
	my $t = ord(substr($text, 0, 1, ''));
	if ($t == BC_CON || $t == BC_SWA) {
	    my ($o1, $o2) = unpack('CC', substr($text, 0, 2, ''));
	    push @gr, [$t, $o1, $o2];
	    _load_opcode($tp, $o2);
	    if ($t == BC_CON) {
		_ii_CON($int, $tp, $o1, $o2);
	    } else {
		_ii_SWA($int, $tp, $o1, $o2);
	    }
	    next;
	}
	$t == BC_CRE || $t == BC_DES or croak "Invalid DATA";
	my ($gra) = unpack('v', substr($text, 0, 2, ''));
	my $sym = _unpack_symbol(\$text, $int, \@smap);
	my $left = _unpack_left(\$text, $int, \@smap);
	if ($t == BC_CRE) {
	    my $right = _unpack_right(\$text, $int, \@smap);
	    push @gr, [$t, $sym, $left, $right];
	    _ii_CRE($int, $tp, $gra, $sym, $left, $right);
	} else {
	    push @gr, [$t, $sym, $left];
	    _ii_DES($int, $tp, $gra, $sym, $left);
	}
    }
    $tp->[thr_grammar_record] = \@gr;
    $text eq '' or croak "Invalid DATA";
    $int;
}

sub _pack_symbol {
    my ($int, $sym, $smap) = @_;
    if (exists $smap->{$sym}) {
	return 'S' . pack('v', $smap->{$sym});
    }
    $sym = $int->{object}->symboltable->symbol($sym) || 0;
    my $num = scalar keys %$smap;
    $smap->{$sym} = $num;
    return 'M' . pack('v v/a*', $num, $sym);
}

sub _unpack_symbol {
    my ($text, $int, $smap) = @_;
    my $name;
    if ($$text =~ s/^S//) {
	my ($snum) = unpack('v', substr($$text, 0, 2, ''));
	$name = $smap->[$snum];
    } elsif ($$text =~ s/^M//) {
	my ($snum, $slen) = unpack('vv', substr($$text, 0, 4, ''));
	$name = substr($$text, 0, $slen, '');
	length($name) == $slen or croak "Invalid DATA";
	$smap->[$snum] = $name;
    } else {
	croak "Invalid DATA";
    }
    $int->{object}->symboltable->find($name, 0);
}

sub _pack_left {
    my ($int, $left, $smap) = @_;
    my $text = pack('v', scalar @$left);
    for my $prod (@$left) {
	$text .= $prod->[0];
	if ($prod->[0] eq 's') {
	    $text .= _pack_symbol($int, $prod->[1], $smap);
	} else {
	    $text .= pack('v/a*', $prod->[1]);
	}
	$text .= pack('v', $prod->[2]);
    }
    $text;
}

sub _unpack_left {
    my ($text, $int, $smap) = @_;
    my ($num) = unpack('v', substr($$text, 0, 2, ''));
    my @left = ();
    while ($num-- > 0) {
	my $type = substr($$text, 0, 1, '');
	my $data;
	if ($type eq 's') {
	    $data = _unpack_symbol($text, $int, $smap);
	} else {
	    my $l = unpack('v', substr($$text, 0, 2, ''));
	    $data = substr($$text, 0, $l, '');
	    length $data == $l or croak "Invalid DATA";
	}
	my $count = unpack('v', substr($$text, 0, 2, ''));
	push @left, [$type, $data, $count];
    }
    \@left;
}

sub _pack_right {
    my ($int, $right, $smap) = @_;
    my $text = pack('v', scalar @$right);
    for my $prod (@$right) {
	$text .= $prod->[0];
	if ($prod->[0] eq 's' || $prod->[0] eq 'n') {
	    $text .= pack('v', $prod->[1]);
	    $text .= _pack_symbol($int, $prod->[2], $smap);
	} elsif ($prod->[0] eq 'c' || $prod->[0] eq 'r') {
	    $text .= pack('v v/a*', $prod->[1], $prod->[2]);
	} elsif ($prod->[0] eq 'b') {
	    $text .= pack('v/a*', $prod->[1]);
	}
    }
    $text;
}

sub _unpack_right {
    my ($text, $int, $smap) = @_;
    my ($num) = unpack('v', substr($$text, 0, 2, ''));
    my @right = ();
    while ($num-- > 0) {
	my $type = substr($$text, 0, 1, '');
	if ($type eq 's' || $type eq 'n') {
	    my $n = unpack('v', substr($$text, 0, 2, ''));
	    my $s = _unpack_symbol($text, $int, $smap);
	    push @right, [$type, $n, $s];
	} elsif ($type eq 'c' || $type eq 'r') {
	    my $n = unpack('v', substr($$text, 0, 2, ''));
	    my $l = _unpack_symbol($text, $int, $smap);
	    my $s = substr($$text, 0, $l, '');
	    length $s == $l or croak "Invalid DATA";
	    push @right, [$type, $n, $s];
	} elsif ($type eq 'b') {
	    my $l = _unpack_symbol($text, $int, $smap);
	    my $s = substr($$text, 0, $l, '');
	    length $s == $l or croak "Invalid DATA";
	    push @right, [$type, $s];
	}
    }
    \@right;
}

sub get_events {
    @_ == 1 or croak "Usage: INTERPRETER->get_events";
    my ($int) = @_;
    my $text = "EVR\n";
    my $ep = $int->{events} || [];
    $text .= pack('v', scalar @$ep);
    for my $ev (@$ep) {
	my ($code, $cond, $cend, $body, $bend, $bge) = @$ev;
	$cond = substr($code, $cond, $cend - $cond);
	$body = substr($code, $body, $bend - $body);
	$text .= pack('vvv', $bge, length($cond), length($body));
	$text .= $cond;
	$text .= $body;
    }
    $text;
}

sub set_events {
    @_ == 2 or croak "Usage: INTERPRETER->set_events(DATA)";
    my ($int, $text) = @_;
    $text =~ s/^EVR\n// or croak "Invalid DATA";
    my ($count) = unpack('v', substr($text, 0, 2, ''));
    my @ev = ();
    for (my $i = 0; $i < $count; $i++) {
	my ($bge, $clen, $blen) = unpack('vvv', substr($text, 0, 6, ''));
	my $code = substr($text, 0, $blen + $clen, '');
	length($code) == $blen + $clen or croak "Invalid DATA";
	push @ev, [$code, 0, $clen, $clen, $clen + $blen, $bge];
    }
    $text eq '' or croak "Invalid DATA";
    $int->{events} = \@ev;
    $int;
}

sub get_registers {
    @_ == 1 or croak "Usage: INTERPRETER->get_registers";
    my ($int) = @_;
    my $tp = $int->{default};
    my $rp = $tp->[thr_registers];
    my @rcode = ();
    # we assume special registers are restored by re-running extensions
    # or by using INTERPRETER->read, so we never dump them here;
    # we do dump classes (but not filehandles yet)
    for my $type (REG_spot, REG_twospot, REG_tail, REG_hybrid, REG_whp) {
	for (my $number = 0; $number < @{$rp->[$type]}; $number++) {
	    my $rv = $rp->[$type][$number];
	    $rv or next;
	    next if $rv->[reg_default] && ! $rv->[reg_overload];
	    # dump this register
	    my @rv = ();
	    my $sp = $tp->[thr_stash][$type][$number] || [];
	    for my $level (@$sp, $rv) {
		my $v = $level->[reg_value];
		my $code = '';
		my @overload;
		$level->[reg_overload] and @overload = sort keys %{$level->[reg_overload]};
		$code .= pack('Cv', $level->[reg_default] ? 1 : 0, scalar @overload);
		for my $o (@overload) {
		    my $p = $level->[reg_overload]{$o};
		    $code .= pack('vva*a*', length $o, length $p, $o, $p);
		}
		if ($type == REG_spot) {
		    $code .= pack('v', $v);
		} elsif ($type == REG_twospot) {
		    $code .= pack('V', $v);
		} elsif ($type == REG_whp) {
		    my @subjects = sort { $a <=> $b } grep { /^\d+$/ } keys %$v;
		    $code .= pack('v', scalar @subjects);
		    for my $subject (@subjects) {
			$code .= pack('vv', $subject, $v->{$subject});
		    }
		    # XXX dump filehandle?
		} else {
		    if ($v && ref $v && @$v) {
			my @v = make_list($v);
			my @s = make_sparse_list(@v);
			my $mode;
			if (@s < @v) {
			    undef @v;
			    @v = @s;
			    $mode = 2;
			} else {
			    undef @s;
			    $mode = 1;
			}
			@s = list_subscripts($v);
			$code .= pack('Cv*', $mode, scalar(@s), scalar(@v), @s);
			if ($type == REG_hybrid) {
			    $code .= pack('V*', @v);
			} else {
			    $code .= pack('v*', @v);
			}
		    } else {
			# array not dimensioned
			$code .= pack('C', 0);
		    }
		}
		push @rv, $code;
	    }
	    my $len = pack('Cv*', $type, $number,
				  scalar @rv, map { length $_ } @rv);
	    push @rcode, join('', $len, @rv);
	}
    }
    join('', "REG\n", pack('v', scalar @rcode), @rcode);
}

sub set_registers {
    @_ == 2 || @_ == 3
	or croak "Usage: INTERPRETER->set_registers(DATA [, OVERRIDE])";
    my ($int, $text, $over) = @_;
    $text =~ s/^REG\n// or croak "Invalid DATA";
    my $tp = $int->{default};
    my $rp = $tp->[thr_registers];
    my $sp = $tp->[thr_stash];
    length $text >= 2 or croak "Invalid DATA";
    my ($count) = unpack('v', substr($text, 0, 2, ''));
    while ($count-- > 0) {
	length $text >= 5 or croak "Invalid DATA";
	my ($type, $number, $cnum) = unpack('Cvv', substr($text, 0, 5, ''));
	length $text >= 2 * $cnum or croak "Invalid DATA";
	my @clen = unpack('v*', substr($text, 0, 2 * $cnum, ''));
	my @rv = ();
	for my $clen (@clen) {
	    length $text >= $clen or croak "Invalid DATA";
	    my $code = substr($text, 0, $clen, '');
	    push @rv, $code;
	}
	next if $rp->[$type][$number] && ! $rp->[$type][$number][reg_default] && ! $over;
	my $stashit = 0;
	$rp->[$type][$number] = undef;
	$sp->[$type][$number] = undef;
	$int->_create_register($tp, $type, $number);
	for my $code (@rv) {
	    if ($stashit) {
		$int->_stash_register($tp, $type, $number);
	    }
	    $stashit = 1;
	    my $bv = $rp->[$type][$number];
	    my ($is_default, $n_overload) = unpack('Cv', substr($code, 0, 3, ''));
	    for (my $o = 0; $o < $n_overload; $o++) {
		my ($sl, $cl) = unpack('vv', substr($code, 0, 4, ''));
		my $s = substr($code, 0, $sl, '');
		length $s == $sl or croak "Invalid DATA";
		my $c = substr($code, 0, $cl, '');
		length $c == $cl or croak "Invalid DATA";
		$bv->[reg_overload]{$s} = $c;
	    }
	    $bv->[reg_default] = $is_default ? 1 : 0;
	    if ($type == REG_spot) {
		$bv->[reg_value] = unpack('v', substr($code, 0, 2, ''));
	    } elsif ($type == REG_twospot) {
		$bv->[reg_value] = unpack('V', substr($code, 0, 4, ''));
	    } elsif ($type == REG_whp) {
		my ($nsubjects) = unpack('v', substr($code, 0, 2, ''));
		while ($nsubjects-- > 0) {
		    my ($what, $when) = unpack('vv', substr($code, 0, 4, ''));
		    $bv->[reg_value]{$what} = $when;
		}
		# XXX set filehandle?
	    } else {
		my ($mode) = unpack('C', substr($code, 0, 1, ''));
		if ($mode) {
		    my ($nsubs, $nvals) = unpack('vv', substr($code, 0, 4, ''));
		    my @subs = unpack('v*', substr($code, 0, 2 * $nsubs, ''));
		    my $v = make_array(\@subs);
		    my @vals;
		    if ($type == REG_hybrid) {
			@vals = unpack('V*', substr($code, 0, 4 * $nvals, ''));
		    } else {
			@vals = unpack('v*', substr($code, 0, 2 * $nvals, ''));
		    }
		    $mode == 2 and @vals = expand_sparse_list(@vals);
		    replace_array($v, $type, @vals);
		    $bv->[reg_value] = $v;
		} else {
		    $bv->[reg_value] = undef;
		}
	    }
	}
    }
    $text eq '' or croak "Invalid DATA";
    $int;
}

sub get_constants {
    @_ == 1 or croak "Usage: INTERPRETER->get_constants";
    my ($int) = @_;
    my $tp = $int->{default};
    my $ap = $tp->[thr_assign];
    my @al = grep { ${$ap->{$_}} != $_ } keys %$ap;
    my @av = map { ($_ => ${$ap->{$_}}) } @al;
    my $text = "CON\n";
    $text .= pack('v*', scalar @al, @av);
    $text;
}

sub set_constants {
    @_ == 2 or croak "Usage: INTERPRETER->set_constants(DATA)";
    my ($int, $text) = @_;
    my $tp = $int->{default};
    $text =~ s/^CON\n// or croak "Invalid DATA";
    my ($count, @data) = unpack('v*', $text);
    @data == 2 * $count or croak "Invalid DATA";
    my %ap = ();
    while (@data) {
	my $c = shift @data;
	my $v = shift @data;
	$ap{$c} = \$v;
    }
    $tp->[thr_assign] = \%ap;
    $int;
}

sub get_state {
    @_ == 1 or croak "Usage: INTERPRETER->get_constants";
    my ($int) = @_;
    my $text = "STA\n";
    for my $v ($int->get_abstains(),
	       $int->get_grammar_record(),
	       $int->get_events(),
	       $int->get_registers(),
	       $int->get_constants())
    {
	$text .= pack('v/a*', $v);
    }
    $text;
}

sub set_state {
    @_ == 2 || @_ == 3
	or croak "Usage: INTERPRETER->set_state(DATA [, FLAGS])";
    my ($int, $text, $flags) = @_;
    $text =~ s/^STA\n// or croak "Invalid DATA";
    $int->{default}[thr_assign] = {}; # otherwise set_registers fails
    $flags ||= 0;
    # set abstains
    length $text >= 2 or croak "Invalid DATA";
    my ($len) = unpack('v', substr($text, 0, 2, ''));
    length $text >= $len or croak "Invalid DATA";
    $int->set_abstains(substr($text, 0, $len, ''), $flags & STATE_SKIP_ONCE);
    # replay grammar record
    length $text >= 2 or croak "Invalid DATA";
    ($len) = unpack('v', substr($text, 0, 2, ''));
    length $text >= $len or croak "Invalid DATA";
    $int->set_grammar_record(substr($text, 0, $len, ''));
    # set events
    length $text >= 2 or croak "Invalid DATA";
    ($len) = unpack('v', substr($text, 0, 2, ''));
    length $text >= $len or croak "Invalid DATA";
    $int->set_events(substr($text, 0, $len, ''));
    # set registers
    length $text >= 2 or croak "Invalid DATA";
    ($len) = unpack('v', substr($text, 0, 2, ''));
    length $text >= $len or croak "Invalid DATA";
    $int->set_registers(substr($text, 0, $len, ''), $flags & STATE_OVERRIDE);
    # set constants
    length $text >= 2 or croak "Invalid DATA";
    ($len) = unpack('v', substr($text, 0, 2, ''));
    length $text >= $len or croak "Invalid DATA";
    $int->set_constants(substr($text, 0, $len, ''));
    # all done
    $text eq '' or croak "Invalid DATA";
    $int;
}

1;
