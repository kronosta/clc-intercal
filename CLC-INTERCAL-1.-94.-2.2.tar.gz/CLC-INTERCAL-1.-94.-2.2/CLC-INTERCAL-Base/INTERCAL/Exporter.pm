package Language::INTERCAL::Exporter;

# Like the standard Exporter, but understand INTERCAL (per)version numbers

# This file is part of CLC-INTERCAL

# Copyright (c) 2006-2008, 2023 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use Carp;
require Exporter;

use vars qw($VERSION $PERVERSION @EXPORT @EXPORT_OK);
($VERSION) = ($PERVERSION = "CLC-INTERCAL/Base INTERCAL/Exporter.pm 1.-94.-2.1") =~ /\s(\S+)$/;
@EXPORT = qw(import);
@EXPORT_OK = qw(is_intercal_number import require_version compare_version);

sub is_intercal_number {
    @_ == 1 or croak "Usage: is_intercal_number(STRING)";
    my ($s) = @_;
    $s =~ /^-?\d+(?:\.-?\d+)*$/;
}

sub import {
    if (@_ > 1 && is_intercal_number($_[1])) {
	my ($req) = splice(@_, 1, 1);
	require_version($_[0], $req);
    }
    goto &Exporter::import;
}

sub require_version {
    my ($package, $required) = @_;
    $package = caller if ! defined $package;
    no strict 'refs';
    my $provided = ((${"${package}::PERVERSION"} || '0') =~ /\s(\S+$)/)[0];
    compare_version($required, $provided) <= 0
	or croak "$package perversion $provided is too old (required $required)";
}

sub compare_version {
    @_ == 2 or croak "Usage: compare_version(NUM, NUM)";
    my ($a, $b) = @_;
    my @a = split(/\./, $a);
    my @b = split(/\./, $b);
    while (@a || @b) {
	$a = @a ? shift @a : 0;
	$b = @b ? shift @b : 0;
	return -1 if $a < $b;
	return 1 if $a > $b;
    }
    0;
}

1;
