package Language::INTERCAL::InstallModule;

# This package helps installing an optional component of CLC-INTERCAL.

# This file is part of CLC-INTERCAL

# Copyright (c) 2008, 2023 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

require 5.005;
use strict;
use vars qw($VERSION $PERVERSION);
($VERSION) = ($PERVERSION = "CLC-INTERCAL/Base INTERCAL/InstallModule.pm 1.-94.-2.1") =~ /\s(\S+)$/;

use Config qw(%Config);
use File::Spec::Functions qw(catfile catdir curdir);
use ExtUtils::MakeMaker;
use Carp;

import Language::INTERCAL::Exporter '1.-94.-2.1';

my $type = '';
my $has_distribute = 0;
my $pm_dir = 'INTERCAL';
my $iacc_dir = 'Include';
my $iacc_suffix = 'iacc';
my $sick_suffix = 'i';
my $iasm_suffix = 'iasm';
my $bin_dir = 'bin';
my $html_dir = 'doc/html';
my $html_suffix = 'html';
my $htmlgen_suffix = 'hgen';

my @iacc = ();
my @sick = ();
my @iasm = ();
my @bin = ();
my @htmlcopy = ();
my @htmlgen = ();

sub in_bundle {
    $ENV{CLC_INTERCAL_BUNDLE}
	&& $ENV{CLC_INTERCAL_BUNDLE} eq '42'
	&& $ENV{CLC_INTERCAL_ROOT};
}

sub install {
    @_ == 3 || @_ == 4
	or croak "Usage: install Language::INTERCAL::InstallModule TYPE, HAS_DISTRIBUTE? [, PREREQ]";
    my ($class, $req) = @_;
    ($class, $type, $has_distribute, $req) = @_;

    open(MANIFEST, "MANIFEST")
	or die "Sorry, I can't function without file \"MANIFEST\"\n";

    while (<MANIFEST>) {
	chomp;
	s/\s+\S+$//;
	my $on = $_;
	if (s#^$pm_dir/*##o) {
	    if (s#^$iacc_dir/*##o) {
		push @iacc, $1 if /^(.*)\.$iacc_suffix$/o;
		push @sick, $1 if /^(.*)\.$sick_suffix$/o;
		push @iasm, $1 if /^(.*)\.$iasm_suffix$/o;
	    }
	} elsif (m#^$bin_dir/#o) {
	    s/\s+\S+$//;
	    push @bin, $_;
	} elsif (s#^$html_dir/##o) {
	    push @htmlcopy, $1 if /^(.*\.$html_suffix)$/o;
	    push @htmlgen, $1 if /^(.*)\.$htmlgen_suffix$/o;
	}
    }
    close MANIFEST;

    my %req = (
	'Carp' => 0,
	'Exporter' => 0,
    );
    if ($req) {
	$req{$_} = $req->{$_} for keys %$req;
    }

    my @filter = ();
    my $clcroot = curdir();
    in_bundle() and $clcroot = $ENV{CLC_INTERCAL_ROOT};
    if (-f "Generate") {
	# that's correct - if Generate exists HERE, execute one THERE
	# you are not supposed to understand that
	@filter = (PM_FILTER => "\$(PERL) $clcroot/Generate"),
    }

    # NAME must be Language::INTERCAL because our modules are installed
    # there, even if this is not Base
    WriteMakefile(NAME => "Language::INTERCAL",
		  DISTNAME => "CLC-INTERCAL-$type",
		  EXE_FILES => \@bin,
		  VERSION => $VERSION,
		  PERL_MALLOC_OK => 1,
		  @filter,
		  PREREQ_PM => \%req,
		  clean => { FILES => 'iacc_to_io sick_to_io' },
		  ($type eq 'Base' ? ( realclean => { FILES => 'aux/iacc.src aux/asm.bc' } ) : ()),
		  NO_META => 1,
		  NO_MYMETA => 1,
    );
}

sub MY::constants {
    package MY;
    use File::Spec::Functions qw(catfile catdir curdir);
    my $i = shift->SUPER::constants(@_);
    my $clcroot = curdir();
    my $dist = $has_distribute;
    my @rcdir = (catdir($clcroot, qw(INTERCAL Include)));
    if (Language::INTERCAL::InstallModule::in_bundle()) {
	$clcroot = $ENV{CLC_INTERCAL_ROOT};
	$i =~ s/^(PERL\s*=.*)$/$1 "-I$clcroot\/\$(INST_ARCHLIB)" "-I$clcroot\/\$(INST_LIB)"/gm;
	$i =~ s/^(FULLPERL\s*=.*)$/$1 "-I$clcroot\/\$(INST_ARCHLIB)" "-I$clcroot\/\$(INST_LIB)"/gm;
	push @rcdir, catdir($clcroot, qw(INTERCAL Include));
	$dist = 1;
    }
    my %rcfile;
    for my $rcdir (@rcdir) {
	opendir(RCDIR, $rcdir) or next;
	while (defined (my $ent = readdir RCDIR)) {
	    $ent =~ /^\./ and next;
	    $ent =~ /\.sickrc$/i or next;
	    my $fn = catfile($rcdir, $ent);
	    -f $fn or next;
	    exists $rcfile{$ent} and next;
	    $rcfile{$ent} = $fn;
	}
	closedir RCDIR;
    }
    if (! exists $rcfile{'system.sickrc'}) {
	# there must be an installed one somewhere
	for my $rcdir (@INC) {
	    my $fn = catfile($rcdir, qw(Language INTERCAL Include system.sickrc));
	    -f $fn or next;
	    $rcfile{'system.sickrc'} = $fn;
	    last;
	}
    }
    my $rcfile = '';
    my $extensions = '';
    exists $rcfile{'system.sickrc'} and $rcfile .= ' --rcfile=' . (delete $rcfile{'system.sickrc'});
    for my $ent (sort keys %rcfile) {
	$rcfile .= " --rcfile=$rcfile{$ent}";
	$ent =~ s/\.sickrc$//i;
	$extensions .= " --extension=$ent";
    }
    $i .= "\n# Needed to run iacc\n";
    $i .= "INST_IACC = \$(INST_LIB)/Language/INTERCAL/Include\n";
    $i .= "INST_HTMLDOC = blib/htmldoc\n";
    $i .= "INST_IOFILES = blib/iofiles\n";
    $i .= "SICK_OPTIONS = --build$extensions$rcfile --batch --bug=0 --ubug=0 --stdtrace=/dev/null --notrace\n";
#    $i .= "SICK_OPTIONS += -v\n";
    $i .= "SICK = \$(FULLPERL) -I\$(INST_ARCHLIB) -I\$(INST_LIB) \\\n";
    my $sick = $dist
	     ? "-I$clcroot/\$(INST_ARCHLIB) -I$clcroot/\$(INST_LIB) $clcroot/\$(INST_SCRIPT)/sick"
	     : "-S sick";
    $i .= "\t-I\$(INST_ARCHLIB) -I\$(INST_LIB) $sick \\\n";
    $i .= "\t\$(SICK_OPTIONS)\n";
    $i .= "CLC_INTERCAL_TYPE = $type\n";
    $i;
}

sub MY::test {
    package MY;
    my $i = shift->SUPER::test(@_);
    if (Language::INTERCAL::InstallModule::in_bundle()) {
	my $clcroot = $ENV{CLC_INTERCAL_ROOT};
	$i =~ s/('\$\(INST_ARCHLIB\)')/$1, '$clcroot\/\$(INST_ARCHLIB)', '$clcroot\/\$(INST_LIB)'/gm;
	$i =~ s/("-I\$\(INST_ARCHLIB\)")/$1 "-I$clcroot\/\$(INST_ARCHLIB)" "-I$clcroot\/\$(INST_LIB)"/gm;
    }
    $i;
}

sub MY::postamble {
    package MY;
    use File::Spec::Functions qw(catfile curdir);
    my $postpre = '';
    my $iacc = '';

    my $i = shift->SUPER::postamble(@_);
    if ($type eq 'Base') {
	$postpre = '$(INST_IOFILES)/postpre.io';
	$iacc = '$(INST_IOFILES)/iacc.io';
	$i .= <<EOF;
$postpre : pm_to_blib \$(INST_IOFILES)/\$(DFSEP).exists aux/mkpostpre
	\$(MAKE) -C aux PERL=\$(ABSPERLRUN) postpre

$iacc : pm_to_blib \$(INST_IOFILES)/\$(DFSEP).exists aux/mkfiles aux/iacc.prefix aux/iacc.prefix
	\$(MAKE) -C aux PERL=\$(ABSPERLRUN) iacc

IACC_IO = \$(INST_IOFILES)/iacc.io
POSTPRE_IO = --postpre \$(INST_IOFILES)/postpre.io

EOF
    } else {
	$i .= <<EOF;
IACC_IO = iacc
POSTPRE_IO =

EOF
    }

    $i .= "\$(INST_IOFILES)/\$(DFSEP).exists :: Makefile.PL\n"
	. "\t\$(NOECHO) \$(MKPATH) \$(INST_IOFILES)\n"
	. "\t\$(NOECHO) \$(CHMOD) 755 \$(INST_IOFILES)\n"
	. "\t\$(NOECHO) \$(TOUCH) \$(INST_IOFILES)/\$(DFSEP).exists\n\n";

    $i .= <<EOI for @iacc;
pure_all :: pm_to_blib $postpre $iacc \$(INST_IACC)/$_.io
	\$(NOECHO) \$(NOOP)

\$(INST_IACC)/$_.io : $postpre $iacc \$(INST_IACC)/$_.$iacc_suffix
	\$(SICK) -lObject \$(POSTPRE_IO) -p\$(IACC_IO) --output \$(INST_IACC)/$_.io \$(INST_IACC)/$_.$iacc_suffix

EOI

    $i .= <<EOI for @sick;
pure_all :: \$(INST_IACC)/$_.io
	\$(NOECHO) \$(NOOP)

\$(INST_IACC)/$_.io : \$(INST_IACC)/sick.io \\
		\$(INST_IACC)/postpre.io \\
		\$(INST_IACC)/$_.$sick_suffix
	\$(SICK) -lObject -psick --output \$(INST_IACC)/$_.io \$(INST_IACC)/$_.$sick_suffix

EOI

    $i .= <<EOI for @iasm;
pure_all :: \$(INST_IACC)/$_.io
	\$(NOECHO) \$(NOOP)

\$(INST_IACC)/$_.io : \$(INST_IACC)/asm.io \\
		\$(INST_IACC)/postpre.io \\
		\$(INST_IACC)/$_.$iasm_suffix
	\$(SICK) -lObject -pasm --output \$(INST_IACC)/$_.io \$(INST_IACC)/$_.$iasm_suffix

EOI

    $i .= <<EOI for @htmlcopy;
all :: \$(INST_HTMLDOC)/$_
	\$(NOECHO) \$(NOOP)

\$(INST_HTMLDOC)/$_ : \$(INST_HTMLDOC)/\$(DFSEP).exists $html_dir/$_
	\$(CP) $html_dir/$_ \$(INST_HTMLDOC)/$_

EOI

    my $clcroot = Language::INTERCAL::InstallModule::in_bundle() ? $ENV{CLC_INTERCAL_ROOT} : curdir();

    $i .= <<EOI for @htmlgen;
all :: \$(INST_HTMLDOC)/$_.$html_suffix
	\$(NOECHO) \$(NOOP)

\$(INST_HTMLDOC)/$_.$html_suffix : \$(INST_HTMLDOC)/\$(DFSEP).exists $clcroot/Generate $html_dir/$_.$htmlgen_suffix
	\$(PERL) $clcroot/Generate $html_dir/$_.$htmlgen_suffix \$(INST_HTMLDOC)/$_.$html_suffix

EOI

    $i .= "\$(INST_HTMLDOC)/\$(DFSEP).exists :: Makefile.PL\n"
	. "\t\$(NOECHO) \$(MKPATH) \$(INST_HTMLDOC)\n"
	. "\t\$(NOECHO) \$(CHMOD) 755 \$(INST_HTMLDOC)\n"
	. "\t\$(NOECHO) \$(TOUCH) \$(INST_HTMLDOC)/\$(DFSEP).exists\n\n";

    $i;
};

1;
