package Language::INTERCAL::Backend::Perl;

# Produce a Perl executable

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL INTERCAL/Backend/Perl.pm 1.-94.-4";

# same as Object backend, with a different file extension

use Language::INTERCAL::Exporter '1.-94.-4';
use Language::INTERCAL::Backend::Object '1.-94.-4';

use vars qw(@ISA);
@ISA = qw(Language::INTERCAL::Backend::Object);

use constant default_suffix => 'pl';

1;
