package Language::INTERCAL::Reggrim;

# Regular grimages - INTERCAL's answer to regular expressions

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL INTERCAL/Reggrim.pm 1.-94.-4";

use Carp;

use Language::INTERCAL::Exporter '1.-94.-4';
use Language::INTERCAL::Splats '1.-94.-4', qw(:SP);

use vars qw(@EXPORT_OK);

@EXPORT_OK = qw(rg_compile);

sub rg_compile {
    @_ == 1 or croak "Usage: rg_compile(TEXT)";
    my ($text) = @_;
    faint(SP_TODO, "reglar grimaces");
}

1;
