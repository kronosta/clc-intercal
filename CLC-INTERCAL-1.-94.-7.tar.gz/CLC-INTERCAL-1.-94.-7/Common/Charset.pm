package Language::INTERCAL::Charset;

# Character sets

# This file is part of CLC-INTERCAL

# Copyright (c) 2002 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. The principal points are:

# * No charge can be made for distributing CLC-INTERCAL under any conditions.
#   This condition does not apply to payment of copying/distribution expenses
#   provided that no handling or other charge is added to such expenses.

# * The author cannot accept any liability whatsoever for any damage caused
#   by the software, directly or indirectly. No warranty of any kind can be
#   offered. Using the software in a way which causes any form of damage is
#   expressely prohibited.

# * In addition, the author's details shall not be entered into any mailing
#   list or public directory, without the author's written permission.

# * CLC-INTERCAL can be redistributed only under an identical licence
#   agreement. Any modified or derived work must also be covered by the
#   same identical agreement as the original work.

# See the file "licence.iacc" in the software installation directory (or the
# distribution, if the software has not been installed) for a full licence
# agreement. Please note that, this being an INTERCAL licence agreement, you
# must submit a text file to "licence.iacc", which will agree to it only if
# the text file happened to contain the correct licence agreement. See the
# README file in the distribution for more details.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Charset.pm 1.-94.-8";

use Carp;

use constant MAX_STASH => 15;

use Language::INTERCAL::Exporter '1.-94.-8';

use vars qw(@EXPORT @EXPORT_OK);

@EXPORT = ();
@EXPORT_OK = qw(fromascii toascii charset charset_default charset_name);

my @charsets;
my %charsets;

BEGIN {
    @charsets = qw(ASCII);
    %charsets = ( ASCII => 1 );
}

use constant charset_default => $charsets{ASCII};

sub charset {
    @_ == 1 or croak "Usage: charset(CHARSET)";
    my ($charset) = @_;
    $charset =~ s/\s+//g;
    if ($charset =~ /^\d+$/) {
	return $charsets{ASCII} if $charset == 0;
	return undef if $charset < 1 || $charset > @charsets;
	return $charset;
    } else {
	return $charsets{$charset} if exists $charsets{$charset};
	eval "require Language::INTERCAL::Charset::$charset";
	return undef if $@;
	push @charsets, $charset;
	$charsets{$charset} = @charsets;
	return $charsets{$charset};
    }
}

sub charset_name {
    @_ == 1 or croak "Usage: charset_name(CHARSET)";
    my ($charset) = @_;
    $charset =~ s/\s+//g;
    if ($charset =~ /^\d+$/) {
	return 'ASCII' if $charset == 0;
	return undef if $charset < 1 || $charset > @charsets;
	return $charsets[$charset - 1];
    } else {
	return $charset if exists $charsets{$charset};
	eval "require Language::INTERCAL::Charset::$charset";
	return undef if $@;
	push @charsets, $charset;
	$charsets{$charset} = @charsets;
	return $charset;
    }
}

sub toascii {
    @_ == 1 or croak "Usage: toascii(CHARSET)";
    my $charset = charset(@_);
    return sub { shift } if ! defined $charset || $charset == $charsets{ASCII};
    $charset = $charsets[$charset - 1];
    no strict;
    return \&{"Language::INTERCAL::Charset::${charset}::\L${charset}\E2ascii"};
}

sub fromascii {
    @_ == 1 or croak "Usage: fromascii(CHARSET)";
    my $charset = charset(@_);
    return sub { shift } if ! defined $charset || $charset == $charsets{ASCII};
    $charset = $charsets[$charset - 1];
    no strict;
    return \&{"Language::INTERCAL::Charset::${charset}::ascii2\L${charset}\E"};
}

1;
