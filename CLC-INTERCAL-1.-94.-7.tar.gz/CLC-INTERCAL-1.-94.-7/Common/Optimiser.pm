package Language::INTERCAL::Optimiser;

# Optimiser for INTERCAL bytecode; see also "optimise.iacc"

# This file is part of CLC-INTERCAL

# Copyright (c) 2002 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. The principal points are:

# * No charge can be made for distributing CLC-INTERCAL under any conditions.
#   This condition does not apply to payment of copying/distribution expenses
#   provided that no handling or other charge is added to such expenses.

# * The author cannot accept any liability whatsoever for any damage caused
#   by the software, directly or indirectly. No warranty of any kind can be
#   offered. Using the software in a way which causes any form of damage is
#   expressely prohibited.

# * In addition, the author's details shall not be entered into any mailing
#   list or public directory, without the author's written permission.

# * CLC-INTERCAL can be redistributed only under an identical licence
#   agreement. Any modified or derived work must also be covered by the
#   same identical agreement as the original work.

# See the file "licence.iacc" in the software installation directory (or the
# distribution, if the software has not been installed) for a full licence
# agreement. Please note that, this being an INTERCAL licence agreement, you
# must submit a text file to "licence.iacc", which will agree to it only if
# the text file happened to contain the correct licence agreement. See the
# README file in the distribution for more details.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Optimiser.pm 1.-94.-8";

use Carp;

use Language::INTERCAL::Exporter '1.-94.-8';
use Language::INTERCAL::Splats '1.-94.-8', qw(:SP);
use Language::INTERCAL::ByteCode '1.-94.-8', qw(:BC);

sub new {
    @_ == 1 or croak "Usage: new Language::INTERCAL::Optimiser";
    my ($class) = @_;
    bless {}, $class;
}

sub append {
    @_ == 2 or croak "Usage: OPTIMISER->append(OTHER_OPTIMISER)";
    my ($opt, $other) = @_;

    my @k = keys %$other;
    @$opt{@k} = @$other{@k};

    $opt;
}

sub read_optimiser {
    @_ == 2 or croak "Usage: OPTIMISER->read_optimiser(FILEHANDLE)";
    my ($opt, $fh) = @_;

    my @k = keys %$opt;
    $fh->read_binary(pack('v', scalar(@k)));
    for my $left (@k) {
	my $right = $opt->{$left};
	$fh->read_binary(pack('va*va*', length($left), $left,
					length($right), $right));
    }

    $opt;
}

sub write_optimiser {
    @_ == 2 or croak
	"Usage: write_optimiser Language::INTERCAL::Optimiser(FILEHANDLE)";
    my ($class, $fh) = @_;
    my $opt = bless {}, $class;

    my $keys = unpack('v', $fh->write_binary(2));
    while ($keys-- > 0) {
	my $llen = unpack('v', $fh->write_binary(2));
	my $left = $fh->write_binary($llen);
	my $rlen = unpack('v', $fh->write_binary(2));
	my $right = $fh->write_binary($rlen);
	$opt->{$left} = $right;
    }

    $opt;
}

sub add {
    @_ == 3 or croak "Usage: OPTIMISER->add(LEFT, RIGHT)";
    my ($opt, $left, $right) = @_;
    $opt->{$left} = $right;
    $opt;
}

sub optimise {
    @_ == 2 or croak "Usage: OPTIMISER->optimise(CODE)";
    my ($opt, $code) = @_;
    # TODO... ("Optimiser? Which Optimiser?")
    $code;
}

1;
