package Language::INTERCAL::Object;

# Object file library

# This file is part of CLC-INTERCAL

# Copyright (c) 2002 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. The principal points are:

# * No charge can be made for distributing CLC-INTERCAL under any conditions.
#   This condition does not apply to payment of copying/distribution expenses
#   provided that no handling or other charge is added to such expenses.

# * The author cannot accept any liability whatsoever for any damage caused
#   by the software, directly or indirectly. No warranty of any kind can be
#   offered. Using the software in a way which causes any form of damage is
#   expressely prohibited.

# * In addition, the author's details shall not be entered into any mailing
#   list or public directory, without the author's written permission.

# * CLC-INTERCAL can be redistributed only under an identical licence
#   agreement. Any modified or derived work must also be covered by the
#   same identical agreement as the original work.

# See the file "licence.iacc" in the software installation directory (or the
# distribution, if the software has not been installed) for a full licence
# agreement. Please note that, this being an INTERCAL licence agreement, you
# must submit a text file to "licence.iacc", which will agree to it only if
# the text file happened to contain the correct licence agreement. See the
# README file in the distribution for more details.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Object.pm 1.-94.-8";

use Carp;

use constant MAX_STASH     =>     15;
use constant MAX_CREATE    =>      7;
use constant SPAN_SPACE    =>      2;
use constant MAX_STATEMENT => 0xf000;

use Language::INTERCAL::Exporter '1.-94.-8';
use Language::INTERCAL::Splats '1.-94.-8',
	qw(:SP splatname splatdescription);
use Language::INTERCAL::WriteNumbers '1.-94.-8',
	qw(write_number);
use Language::INTERCAL::ReadNumbers '1.-94.-8',
	qw(roman_type_default read_number roman_type);
use Language::INTERCAL::GenericIO '1.-94.-8',
	qw($stdwrite $stdread $stdsplat $devnull);
use Language::INTERCAL::ArrayIO '1.-94.-8',
	qw(read_array_16 read_array_32
	   write_array_16 write_array_32
	   iotype_default iotype);
use Language::INTERCAL::Charset::Baudot '1.-94.-8',
	qw(ascii2baudot);
use Language::INTERCAL::Charset '1.-94.-8',
	qw(charset_default charset);
use Language::INTERCAL::ByteCode '1.-94.-8',
	qw(:BC is_constant bytedecode);
use Language::INTERCAL::Parser '1.-94.-8';
use Language::INTERCAL::Optimiser '1.-94.-8';
use Language::INTERCAL::Numbers '1.-94.-8';

use vars qw(@EXPORT @EXPORT_OK %EXPORT_TAGS);

use constant HAS_IGNORE    => 0x01;
use constant HAS_VALUE     => 0x02;
use constant HAS_DIMENSION => 0x04;
use constant HAS_OVERLOAD  => 0x08;
use constant HAS_ENROL     => 0x10;
use constant HAS_HANDLE    => 0x20;
use constant HAS_DEFAULT   => 0x40;

use constant STMT_NORMAL   => 0x0000; # There is such a thing?
use constant STMT_UNSCH    => 0x0001;
use constant STMT_WALTZ    => 0x0002;

my %special_registers;
my @conversions;

BEGIN {
    @EXPORT = ();
    @EXPORT_OK = qw(reg_list);
    %EXPORT_TAGS = ();

    %special_registers = (
	# special "spot" registers

	IP => ['%',  1, 1],                   # instruction pointer
	CP => ['%',  2, 0],                   # code pointer
	TP => ['%',  3, 0],                   # thread pointer
	AC => ['%',  4, 0],                   # arg count
	EC => ['%',  5, 0],                   # env count
	RT => ['%',  6, roman_type_default],  # roman style
	IO => ['%',  7, iotype_default],      # I/O style
	AR => ['%',  8, 0],                   # array read value
	AW => ['%',  9, 0],                   # array write value
	OV => ['%', 10, 0],                   # current overload value
	BA => ['%', 11, 2],                   # current base
	CF => ['%', 12, 0],                   # come from style
	CR => ['%', 13, charset_default],     # Character set for Reads
	CW => ['%', 14, charset_default],     # Character set for Writes
	CN => ['%', 15, 0],                   # class number
	SN => ['%', 16, 0],                   # scratch number
	GR => ['%', 17, 1],                   # grammar
	IS => ['%', 18, 1],                   # initial symbol
	CB => ['%', 19, 0],                   # compiler bug, explainable
	CU => ['%', 20, 0],                   # compiler bug, unexplainable
	ES => ['%', 21, 2],                   # extra symbol
	IC => ['%', 22, 0],                   # Is Compiler
	OS => ['%', 23, 0],                   # Syscall interface
	LM => ['%', 24, 1],                   # loop mode

	# special "tail" registers

	AV => ['^',  1],                      # arg vector
	EV => ['^',  2],                      # env vector
	SV => ['^',  3],                      # scratch vector
	TV => ['^',  4],                      # second scratch vecror

	# whirlpool registers are not special, but they get some added value

	OWFH => ['@', 1, 'write_fh'],         # object's write filehandle
	ORFH => ['@', 2, 'read_fh'],          # object's read filehandle
	OSFH => ['@', 3, 'splat_fh'],         # object's splat filehandle
	SWFH => ['@', 4, $stdwrite],          # standard write filehandle
	SRFH => ['@', 5, $stdread],           # standard read filehandle
	SSFH => ['@', 6, $stdsplat],          # standard splat filehandle
	SNFH => ['@', 7, $devnull],           # standard null filehandle
	RSFH => ['@', 8, 'rs_fh'],            # reserved special filehandle
    );

    @conversions = (
	[\&roman_type, SP_ROMAN, 'ROMAN'],
	[\&iotype, SP_IOTYPE, 'IOTYPE'],
	[\&charset, SP_CHARSET, 'CHARSET'],
    );

    my %spec = ( '%' => 'DOS', '^' => 'SHF', '@' => 'WHP' );
    my %bspec = ( '%' => BC_DOS, '^' => BC_SHF, '@' => BC_WHP );
    my @bsubname = ();
    my @isubname = ();
    my @sp = keys %special_registers;
    for my $rname (@sp) {
	my $bsubname = "BREG_$rname";
	my $isubname = "IREG_$rname";
	push @bsubname, $bsubname;
	push @isubname, $isubname;
	my $rvalue = $special_registers{$rname};
	my @bsubvalue = ( $bspec{$rvalue->[0]}, BC($rvalue->[1]) );
	my $isubvalue = $rvalue->[0] . $rvalue->[1];
	no strict 'refs';
	*$bsubname = sub () { @bsubvalue };
	*$isubname = sub () { $isubvalue };
    }

    push @EXPORT_OK, @bsubname, @isubname;
    $EXPORT_TAGS{BREG} = \@bsubname;
    $EXPORT_TAGS{IREG} = \@isubname;
    @sp = sort {
	$spec{$special_registers{$a}[0]} cmp $spec{$special_registers{$b}[0]} ||
	$special_registers{$a}[1] <=> $special_registers{$b}[1];
    } @sp;
    *reg_list = sub () { @sp };

    my @cnvname = ();
    for (my $cnum = 1; $cnum <= @conversions; $cnum++) {
	my $cnvname = "ENC_" . $conversions[$cnum - 1][2];
	push @cnvname, $cnvname;
	my $cnvnum = $cnum;
	no strict 'refs';
	*$cnvname = sub () { $cnvnum };
    }

    push @EXPORT_OK, @cnvname, 'enc_list';
    $EXPORT_TAGS{ENC} = \@cnvname;
    *enc_list = sub () { @cnvname };
}

sub new {
    @_ == 1 or @_ == 3
	or croak "Usage: new Language::INTERCAL::Object [(ARGV, ENVP)]";
    my ($class, @args) = @_;
    my $object = bless {
	'statements' => [[-1, (0) x 11]],
	'file' => [],
#__TRACE_START__
	'trace' => [],
	'last_traced' => '',
	'trace_fh' => 0,
	# 'trace_fh' => $stdsplat,
#__TRACE_END__
	'read_fh' => $stdread,
	'write_fh' => $stdwrite,
	'splat_fh' => $stdsplat,
	'rs_fh' => $devnull,
	'optimiser' => Language::INTERCAL::Optimiser->new(),
	'codesize' => 0,
    }, $class;
    $object->reset(@args);
    $object;
}

sub file {
    @_ == 3 or croak "Usage: OBJECT->file(FILENAME, TEXT)";
    my ($object, $file, $text) = @_;
    push @{$object->{file}}, [$file, $text];
    $object;
}

sub is_compiler {
    @_ == 1 or @_ == 2 or croak "Usage: OBJECT->is_compiler [(VALUE)]";
    my ($object) = shift;
    if ($@) {
	$object->{threads}[0]{registers}{&IREG_IC}{value} =
	    new Language::INTERCAL::Numbers::Spot $_[0] ? 1 : 0;
	$object;
    } else {
	${$object->{threads}[0]{registers}{&IREG_IC}{value}};
    }
}

sub code {
    @_ == 2 or croak "Usage: OBJECT->code(BYTECODE)";
    my ($object, $code) = @_;
    @{$object->{file}} and faint(SP_SUBVERSION);
    my $stmt = @{$object->{statements}};
    faint(SP_INDIGESTION) if $stmt > MAX_STATEMENT;
    my @add = (-1, 0, 0, $code, 0, _opcode($code), 0);
    $object->{statements}[$stmt] = \@add;
    for my $thread (@{$object->{threads}}) {
	if ($thread->{statements} != $object->{statements}) {
	    $thread->{statements}[$stmt] = \@add;
	}
    }
    $object->{codesize} = $stmt;
    $object;
}

sub _code {
    my ($code, $fileno, $startpos, $endpos, $tree, $compile, $thread) = @_;
    my $stmt = @{$thread->{statements}};
    faint(SP_INDIGESTION) if $stmt > MAX_STATEMENT;
    my @add =
	($fileno, $startpos, $endpos, $code, $compile, _opcode($code), $tree);
    $thread->{statements}[$stmt] = \@add;
}

sub append {
    @_ == 2 or croak "Usage: OBJECT->append(OTHER_OBJECT)";
    my ($object, $other) = @_;
    @{$object->{threads}} == 1 && @{$other->{threads}} == 1 or
	faint(SP_INDECISION);
    my $thread = $object->{threads}[0];
    my $otherthread = $other->{threads}[0];

    faint(SP_SUBVERSION) if @{$object->{file}} && @{$other->{statements}} > 1;
    my ($throw_away, @STMT) = @{$other->{statements}};
    faint(SP_INDIGESTION) if @{$object->{statements}} + @STMT > MAX_STATEMENT;

    # append text
    my $origfile = @{$object->{file}};
    push @{$object->{file}}, @{$other->{file}};

    # append code
    $object->{codesize} += $other->{codesize};
    my $origstmt = @{$object->{statements}};
##print STDERR "compile=(${$thread->{compile}}, ${$otherthread->{compile}})\n";
    for (my $sn = 1; $sn < @{$other->{statements}}; $sn++) {
	# make a shallow copy to avoid unwanted sharing
	my @sp = @{$other->{statements}[$sn]};
	# adjust file number, if present
	$sp[0] += $origfile if $sp[0] >= 0;
	# adjust compilation level if necessary
##print STDERR "sp[$sn] compile=$sp[4] ";
	$sp[4] = $sp[4] >= ${$otherthread->{compile}}
	       ? ${$thread->{compile}}
	       : 0;
##print STDERR "=> $sp[4]\n";
	# no need for a loop, we are single threaded
	push @{$object->{statements}}, \@sp;
    }

    # append abstain
    while (my ($gerlab, $val) = each %{$otherthread->{abstain}}) {
	$thread->{abstain}{$gerlab} = _copy($val);
    }
    $object->{abstime} = $other->{abstime}
	if $object->{abstime} < $other->{abstime};

    my $grammar = $thread->{grammar};
    my $othergrammar = $otherthread->{grammar};

    # now append any register which has been modified
    for my $rname (keys %{$otherthread->{registers}}) {
	next if exists $otherthread->{registers}{$rname}{is_default};
	next if $rname eq IREG_IP || $rname eq IREG_CP || $rname eq IREG_TP ||
		$rname eq IREG_AC || $rname eq IREG_AV ||
		$rname eq IREG_EC || $rname eq IREG_EV;
	# no need to _create_register -- we are single threaded
	$thread->{registers}{$rname} =
	    _copy($otherthread->{registers}{$rname});
	# if this is a grammar symbol, we need to fix it
	if ($rname eq IREG_IS || $rname eq IREG_ES) {
	    my $symb = ${$thread->{registers}{$rname}{value}};
##print STDERR " [$rname : $symb ";
	    $symb = $othergrammar->[0]->symbol($symb);
##print STDERR "($symb) ";
	    $symb = $grammar->[0]->find_symbol($symb);
	    $thread->{registers}{$rname}{value} =
		new Language::INTERCAL::Numbers::Spot $symb;
##print STDERR "=> $symb]";
	}
    }

    # and copy any grammar defined in the object
    for (my $gram = 0; $gram < @$grammar && $gram < @$othergrammar; $gram++) {
	$grammar->[$gram]->append($othergrammar->[$gram]);
    }
    for (my $gram = @$grammar; $gram < @$othergrammar; $gram++) {
	$grammar->[$gram] = $othergrammar->[$gram]->copy(1);
    }

    # they will certainly have done something weird with the grammar
    # however, it's their responsibility to fix that!
    # ${$thread->{compile}}++;

    $object;
}

sub _opcode {
    my ($code) = @_;
    my $cp = 0;
    my $raf = 0;
    my $clone = 0;
    my $gerund = 0;
    my $label = 0;
    my $abstain = 0;
    while ($cp < length($code)) {
	my $byte = ord(substr($code, $cp, 1));
	$cp++;
	if ($byte == BC_RAF) {
	    $raf = $cp;
	    eval { _expression({}, {}, $code, \0, \$cp, 0) };
	    last if $@;
	} elsif ($byte == BC_CLO) {
	    $clone = 1;
	} elsif ($byte == BC_GER) {
	    eval { $gerund = ${ unBC($code, \$cp) }};
	    last if $@;
	} elsif ($byte == BC_LAB) {
	    eval { $label = ${ unBC($code, \$cp) }};
	    last if $@;
	} elsif ($byte == BC_ABS) {
	    $abstain = 1;
	} else {
	    return ($cp, $raf, $byte, $clone, $gerund, $label, $abstain);
	}
    }
    # statement has no opcode?
    return ($cp, $raf, 0, $clone, $gerund, $label, $abstain);
}

sub reset {
    @_ == 1 or @_ == 3 or croak "Usage: OBJECT->reset([ARGV, ENVP])";
    my ($object, $argv, $envp) = (@_, [], []);
    $object->{assign} = {};
    $object->{modules} = {};
    # remove any compiled code except precompiled without source
    my $stmt = $object->{statements};
    $#$stmt = $object->{codesize};
    # if we are resetting an object obtained from another version, the number
    # of acceptable grammar/stashes might be different - look it up
    my $create = MAX_CREATE;
    $create = @{$object->{threads}[0]{grammar}}
	if exists $object->{threads} &&
	   @{$object->{threads}} &&
	   @{$object->{threads}[0]{grammar}} > $create;
    my $stash = MAX_STASH;
    $stash = @{$object->{threads}[0]{stash}}
	if exists $object->{threads} &&
	   @{$object->{threads}} &&
	   @{$object->{threads}[0]{stash}} > $stash;
    my $s = undef;
    my $compile = 1;
    my $thread = {
	statements => $stmt,
	compile => \$compile,
	registers => {},
	abstain => {},
	loops => [],
	grammar => [map { $s = new Language::INTERCAL::Parser($s) }
			(0..$create)],
	stash => [map { {} } (0..$stash)],
	running => 1,
    };
    $object->{abstime} = 0;
    $object->{threads} = [$thread];
    # reset "compile" counter
    for my $st (@{$object->{statements}}) {
	$st->[4] = 0;
    }
    # now initialise registers
    for my $reg (values %special_registers) {
	my ($regname, $regnum, $default) = @$reg;
	my $regptr = $regname . $regnum;
	if ($regname eq '@') {
	    _create_register($object, $regptr);
	} else {
	    $thread->{registers}{$regptr} = {};
	}
	if (defined $default) {
	    if ($regname eq '@') {
		if (ref $default) {
		    $thread->{registers}{$regptr}{file} = $default;
		} else {
		    $thread->{registers}{$regptr}{file} = $object->{$default};
		}
	    } else {
		$thread->{registers}{$regptr}{value} =
		    new Language::INTERCAL::Numbers::Spot $default;
	    }
	}
	$thread->{registers}{$regptr}{is_default} = 1;
    }
    _store_vector($thread, IREG_AC, IREG_AV, $argv) if $argv;
    _store_vector($thread, IREG_EC, IREG_EV, $envp) if $envp;
    $object;
}

sub setargs {
    @_ == 2 or croak "Usage: OBJECT->setargs(ARGV)";
    my ($object, $argv) = @_;
    _store_vector($object->{threads}[0], IREG_AC, IREG_AV, $argv);
    $object;
}

sub setenv {
    @_ == 2 or croak "Usage: OBJECT->setenv(ENVV)";
    my ($object, $envv) = @_;
    _store_vector($object->{threads}[0], IREG_EC, IREG_EV, $envv);
    $object;
}

sub _clone {
    my ($object, $thread) = @_;
    my $new_thread = {
	# loops don't change, bue new can be added or old removed, so we need
	# a shallow copy
	loops => [@{$thread->{loops}}],
	# abstain will be a shallow copy - they remain shared individually,
	# but can be unshared as necessary
	abstain => {%{$thread->{abstain}}},
	statements => $thread->{statements},
	registers => {
	    map { ( $_ => $thread->{registers}{$_} ) }
		keys %{$thread->{registers}},
	},
	grammar => [ @{$thread->{grammar}} ], # shallow copy intentional
	stash => [],
	compile => $thread->{compile},
	running => $thread->{running},
    };
    # for stashes, we make a two level shallow copy
    for (my $i = 0; $i < @{$thread->{stash}}; $i++) {
	my $s = $thread->{stash}[$i];
	$new_thread->{stash}[$i] = { map { ($_ => $s->{$_}) } keys %$s };
    }
    my $tp = @{$object->{threads}};
    $object->{threads}[$tp] = $new_thread;
    _separate_register($object, $thread, $new_thread, IREG_IP);
    _separate_register($object, $thread, $new_thread, IREG_CP);
    $new_thread;
}

sub generate_code {
    @_ == 6 or @_ == 7 or croak
	"Usage: OBJECT->generate_code(BACKEND, NAME, BASENAME, FILESPEC, ORIG)";
    my ($object, $backend, $name, $basename, $filespec, $orig, $options) = @_;
    $options ||= {};
    my $verb = $options->{verbose};
    $backend = 'Language::INTERCAL::Backend::' . $backend;
    eval "require $backend"; die $@ if $@;
    my $suffix = $backend->default_suffix;
    my $mode = $backend->default_mode;
    my $handle = '';
    my $filename = undef;
    my %p = ('%' => '%', 'p' => $basename, 's' => $suffix, 'o' => $orig);
    if (defined $suffix) {
	$filename = $filespec;
	$filename =~ s/%([%ops])/$p{$1}/ge;
	&$verb($filename) if $verb;
	$handle = new Language::INTERCAL::GenericIO 'FILE', 'r', $filename;
    } else {
	&$verb('') if $verb;
    }
    $name =~ s/%([%ops])/$p{$1}/ge;
    $backend->generate($object, $name, $handle, $options);
    undef $handle;
    if (defined $filename && defined $mode) {
	chmod $mode & ~umask, $filename;
    }
    $object;
}

sub _store_vector {
    my ($thread, $count, $vector, $data) = @_;
    delete $thread->{registers}{$count}{is_default};
    $thread->{registers}{$count}{value} =
	new Language::INTERCAL::Numbers::Spot scalar(@$data);
    my $size = 0;
    my %data = ();
    for (my $a = 1; $a <= @$data; $a++) {
	my $s = ascii2baudot($data->[$a - 1]);
	$size = length($s) if $size < length($s);
	my @val = unpack("C*", $s);
	for (my $b = 1; $b <= @val; $b++) {
	    $data{"$a $b"} = {
		value => new Language::INTERCAL::Numbers::Spot($val[$b - 1]),
	    };
	}
    }
    $thread->{registers}{$vector}{dimension} = [scalar(@$data), $size];
    $thread->{registers}{$vector}{value} = \%data;
    delete $thread->{registers}{$vector}{is_default};
}

sub _ip {
    my ($thread) = @_;
    ($thread->{registers}{&IREG_IP}{value},
     $thread->{registers}{&IREG_CP}{value});
}

sub _ip_set {
    my ($thread, $ip, $cp) = @_;
    $thread->{registers}{&IREG_IP}{value} =
	new Language::INTERCAL::Numbers::Spot $ip;
    $thread->{registers}{&IREG_CP}{value} =
	new Language::INTERCAL::Numbers::Spot $cp;
}

sub do {
    @_ == 2 or croak "Usage: OBJECT->do(CODE)";
    my ($object, $code) = @_;
    my $tp = ${$object->{threads}[0]{registers}{&IREG_TP}{value}};
    $tp = 0 if $tp >= @{$object->{threads}};
    return undef if $tp >= @{$object->{threads}};
    my $thread = $object->{threads}[$tp];
    my ($ip, $cp) = _ip($thread);
    _ip_set($thread, 0, 0);
    $thread->{statements}[0][3] = $code . chr(BC_HCF);
    _run_code($object, $thread);
    $thread->{registers}{&IREG_IP}{value} = $ip;
    $thread->{registers}{&IREG_CP}{value} = $cp;
    $object;
}

sub call {
    @_ == 4 or croak "Usage: OBJECT->call(MODULE, LABEL, SHREGS)";
    my ($object, $module, $label, $shregs) = @_;
    ref $shregs && 'HASH' eq ref $shregs
	or croak "SHREGS must be a hash reference";
    if (defined $module) {
	exists $object->{modules}{$module}
	    or faint(SP_PURE, $module);
	$module = $object->{modules}{$module};
    } else {
	$module = $object;
    }
    # always use thread 0, no matter what is really current
    my $thread = $module->{threads}[0];
    $thread->{registers}{&IREG_TP}{value} =
	new Language::INTERCAL::Numbers::Spot 0;
    # nuke any previous error
    unsplat($module, $thread);
    # find starting point
    my $ip = 1;
    my $cp = 0;
    _trace_init($module);
    _trace($module, $ip, $cp, "<call $label>", 2);
    my $start = $label ? _find_label($module, $thread, $label, \$ip, \$cp) : 1;
    _trace($module, $ip, $cp, "<start=$start>", 2);
    _ip_set($thread, $start, 0);
    # set the other registers
    my %saveregs = ();
    while (my ($rname, $rval) = each %$shregs) {
	$rname =~ /^[.,:;\@%\^](\d+)$/ && $1 >= 1 && $1 <= 0xffff
	    or croak "Invalid register $rname";
	_create_register($module, $rname)
	    if ! exists $thread->{registers}{$rname};
	$saveregs{$rname} = $thread->{registers}{$rname};
	# type checking ? what type checking?
	$thread->{registers}{$rname} = $rval;
	my $xval = 'undef';
	if (exists $rval->{value} && ! 'ARRAY' eq ref $rval->{value}) {
	    $xval = ${$rval->{value}};
	} elsif (exists $rval->{dimension}) {
	    $xval = "[" . join(',', @{$rval->{dimension}}) . ']';
	}
	_trace($module, $ip, $cp, "$rname=$xval", 2);
    }
    _trace_exit($module, $thread);
    # execute program
    $thread->{running} = 1;
    run($module);
    # restore "shared" registers
    _trace_init($module);
    _trace($module, $ip, $cp, "<end $label>", 2);
    while (my ($rname, $rval) = each %saveregs) {
	my $xval = 'undef';
	my $oval = $thread->{registers}{$rname};
	if (exists $oval->{value} && ! 'ARRAY' eq ref $oval->{value}) {
	    $xval = ${$oval->{value}};
	} elsif (exists $oval->{dimension}) {
	    $xval = "[" . join(',', @{$oval->{dimension}}) . ']';
	}
	_trace($module, $ip, $cp, "$rname=$xval", 2);
	$thread->{registers}{$rname} = $rval;
    }
    _trace_exit($module, $thread);
    # propagate splats
    faint($module->{splat}, $module->{splatcause})
	if exists $module->{splat};
    $object;
}

sub step {
    @_ == 1 or croak "Usage: OBJECT->step";
    my ($object) = @_;
    my $tp = $object->{threads}[0]{registers}{&IREG_TP}{value};
    $$tp = 0 if $$tp >= @{$object->{threads}};
    return undef if $$tp >= @{$object->{threads}}; # should never happen
    my $thread = $object->{threads}[$$tp];
    if (! $thread->{running}) {
	# see if there is at least one active thread...
	my $otp = $$tp;
	while (1) {
	    $$tp++;
	    $$tp = 0 if $$tp >= @{$object->{threads}};
	    $thread = $object->{threads}[$$tp];
	    last if $thread->{running};
	    return undef if $$tp == $otp;
	}
    }
    # if we get here, $thread is running
    _run_code($object, $thread);
    $$tp++;
    $$tp = 0 if $$tp >= @{$object->{threads}};
    $object;
}

sub run {
    @_ == 1 or croak "Usage: OBJECT->run";
    my ($object) = @_;
    my $tp = $object->{threads}[0]{registers}{&IREG_TP}{value};
    $$tp = 0 if $$tp >= @{$object->{threads}};
    return undef if $$tp >= @{$object->{threads}};
    while (1) {
	my $thread = $object->{threads}[$$tp];
	if (! $thread->{running}) {
	    # see if there is at least one active thread...
	    my $otp = $$tp;
	    while (1) {
		$$tp++;
		$$tp = 0 if $$tp >= @{$object->{threads}};
		$thread = $object->{threads}[$$tp];
		last if $thread->{running};
		return undef if $$tp == $otp;
	    }
	}
	_run_code($object, $thread);
	$$tp++;
	$$tp = 0 if $$tp >= @{$object->{threads}};
    }
}

sub _run_code {
    my ($object, $thread) = @_;
    my ($ip, $cp) = _ip($thread);
    my $tsp = $thread->{statements};
    if ($$ip < @$tsp &&
	$tsp->[$$ip][0] >= 0 &&
	$tsp->[$$ip][4] < ${$thread->{compile}})
    {
	_revalidate($object, $thread, $tsp, $$ip);
    }
    if ($$ip >= @$tsp) {
	# try to compile a statement -- will automatically generate a splat
	# if there is no more source code
	_compile($object, $thread, $$ip, 1);
    }
    my $stp = $tsp->[$$ip];
    my $code = $stp->[3];
#__TRACE_START__
    _trace_init($object);
    my $tp = 0;
    $tp++ while $tp < @{$object->{threads}} &&
		$thread != $object->{threads}[$tp];
    $tp = '?' if  $tp >= @{$object->{threads}} ||
		  $thread != $object->{threads}[$tp];
    _trace($object, $$ip, $$cp, "<$tp,$$ip,$$cp>", 2);
#__TRACE_END__
    my $remove_loop = 0;
    my $waltz = STMT_NORMAL;
    my $oldip = $$ip; # to check for COME FROMs later
    eval {
	my $abstain = $stp->[11];
	if ($stp->[7] != BC_HCF) {
	    my $time = 0;
	    my $ta = $thread->{abstain};
	    if ($stp->[9] && exists $ta->{'G' . $stp->[9]}) {
		my ($gabstain, $gtime) = @{$ta->{'G' . $stp->[9]}};
		($abstain, $time) = ($gabstain, $gtime) if $gtime > $time;
	    }
	    if ($stp->[10] && exists $ta->{'L' . $stp->[10]}) {
		my ($labstain, $ltime) = @{$ta->{'L' . $stp->[10]}};
		($abstain, $time) = ($labstain, $ltime) if $ltime > $time;
	    }
	}
	if ($abstain) {
	    # statement is ABSTAINed FROM
	    $$cp = 0;
	    $$ip++;
	} else {
	    while ($$cp < length($code)) {
		$waltz = _statement($object, $thread, $code, $ip, $cp, undef);
		last if $waltz == STMT_WALTZ;
		$remove_loop++ if $waltz == STMT_UNSCH;
	    }
	    if ($waltz != STMT_WALTZ && $$cp >= length($code) && $$ip > 0) {
		# end of this code - go to next
		$$cp = 0;
		$$ip++;
	    }
	}
    };
    if ($@) {
	$waltz = STMT_WALTZ;
	my $code = 0;
	my $splat = $@;
	$splat =~ s/\n+$//;
	$code = $1 if $splat =~ s/^(\d+)\s*//;
	$object->splat($thread, $code, $splat);
    }
    eval {
	# process any events/loops
	for (my $loop = 0; $loop < @{$thread->{loops}}; $loop++) {
	    _trace($object, $$ip, 0, "{", 2);
	    my ($body, $cond) = @{$thread->{loops}[$loop]};
	    my $doit = 1;
	    my $splat_fh = $object->{splat_fh};
	    $object->{splat_fh} = $devnull;
	    for my $c (@$cond) {
		eval {
		    my $lcp = 0;
		    _expression($object, $thread, $c, $ip, \$lcp, 0);
		    faint(SP_GARBAGE, "event/loop") if $lcp < length($c);
		};
		$doit = 0, last if $@;
		_trace($object, $$ip, 0, "|", 2);
	    }
	    $object->{splat_fh} = $splat_fh;
	    if ($doit) {
		my $lcp = 0;
		my $remove = 0;
		while ($lcp < length($body)) {
		    my $stmt = _statement($object, $thread, $body,
					  $ip, \$lcp, undef);
		    $remove = 1 if $stmt == STMT_UNSCH;
		    last if $stmt == STMT_WALTZ;
		}
		splice(@{$thread->{loops}}, $loop, 1) if $remove;
	    }
	    _trace($object, $$ip, 0, "}", 2);
	}
    };
    if ($@) {
	$waltz = STMT_WALTZ;
	my $code = 0;
	my $splat = $@;
	$splat =~ s/\n+$//;
	$code = $1 if $splat =~ s/^(\d+)\s*//;
	$object->splat($thread, $code, $splat);
    }
    # see if we have any come froms - but not if we've waltzed out
    # of the current code
    if ($waltz != STMT_WALTZ && $oldip > 0) {
	my $label = $thread->{statements}[$oldip][10];
	my $gerund = 0;
	if (${$thread->{registers}{&IREG_CF}{value}} & 2) {
	    $gerund = $thread->{statements}[$oldip][9];
	}
	if ($label || $gerund) {
	    eval { _come_from($object, $thread, $label, $gerund, $ip, $cp); };
	    if ($@) {
		$waltz = STMT_WALTZ;
		my $code = 0;
		my $splat = $@;
		$splat =~ s/\n+$//;
		$code = $1 if $splat =~ s/^(\d+)\s*//;
		$object->splat($thread, $code, $splat);
	    }
	}
    }
    my $loop = @{$thread->{loops}} - 1;
    while ($remove_loop-- > 0) {
	$loop-- while $loop >= 0 &&
		      @{$thread->{loops}[$loop][1]} > 0;
	faint(SP_SCHEDULE) if $loop < 0;
	splice(@{$thread->{loops}}, $loop, 1);
    }
    _trace_exit($object, $thread);
    1;
}

sub eval {
    @_ == 2 or croak "Usage: OBJECT->eval(CODE)";
    my ($object, $code) = @_;
    my $tp = ${$object->{threads}[0]{registers}{&IREG_TP}{value}};
    $tp = 0 if $tp >= @{$object->{threads}};
    return undef if $tp >= @{$object->{threads}};
    my $thread = $object->{threads}[$tp];
    my ($oldip, $oldcp) = _ip($thread);
    my $value = new Language::INTERCAL::Numbers::Spot(0);
    _ip_set($thread, 0, 0);
    my ($ip, $cp) = _ip($thread);
    $thread->{statements}[0][3] = $code;
    _trace_init($object);
    eval {
	$value = _expression($object, $thread, $code, $ip, $cp, 1);
	faint(SP_GARBAGE, "expression") if $cp < length($code);
    };
    _trace_exit($object, $thread);
    $thread->{registers}{&IREG_IP}{value} = $oldip;
    $thread->{registers}{&IREG_CP}{value} = $oldcp;
    if ($@) {
	my $splat = 0;
	$splat = $1 if $@ =~ s/^(\d+)\s*//;
	$@ =~ s/\n+$//;
	$object->splat($thread, $splat, $@);
	$value = new Language::INTERCAL::Numbers::Spot(0);
    }
    return $value;
}

sub _statement {
    my ($object, $thread, $code, $ip, $cp, $clone) = @_;
    faint(SP_INVALID, "???? _statement") if $$cp >= length($code);
    my $byte = ord(substr($code, $$cp, 1));
    _trace($object, $$ip, $$cp, $byte, 0);
    $$cp++;
    my $oldip = $$ip;
    my $oldcp = $$cp;
    if ($byte == BC_HCF) {
	faint(SP_WALTZ) if defined $clone && ! $clone;
	if ($$ip > 0) {
	    if (defined $clone) {
		_ip_set($clone, $$ip, $$cp);
	    }
	    my $s = $thread->{statements};
	    my $file = $s->[$$ip][0];
	    do {
		$$ip++;
		if ($$ip < @$s &&
		    $s->[$$ip][0] >= 0 &&
		    $s->[$$ip][4] < ${$thread->{compile}})
		{
		    _revalidate($object, $thread, $s, $$ip);
		}
		if ($$ip >= @$s) {
		    if (_compile($object, $thread, $$ip, 0)) {
			$thread->{running} = 0;
		    }
		}
	    } while ($thread->{running} && $s->[$$ip][0] == $file);
	    $$cp = 0;
	}
	return STMT_WALTZ;
    } elsif ($byte == BC_ABS) {
	# no-op
    } elsif ($byte == BC_GER || $byte == BC_LAB) {
	my $throw_away = _expression($object, $thread, $code, $ip, $cp, 0);
    } elsif ($byte == BC_CFR) {
	my $label = _expression($object, $thread, $code, $ip, $cp, 0);
	my $gerund = _expression($object, $thread, $code, $ip, $cp, 1);
	my $stash = _expression($object, $thread, $code, $ip, $cp, 0);
	my $count = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	while ($count-- > 0) {
	    my $r = _register($object, $thread, $code, $ip, $cp, 0);
	}
    } elsif ($byte == BC_ROU) {
	my $count = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	while ($count-- > 0) {
	    my $register = _register($object, $thread, $code, $ip, $cp, 1);
	    _read($object, $thread, $register, $ip, $cp);
	}
    } elsif ($byte == BC_WIN) {
	my $count = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my @reg = ();
	while ($count-- > 0) {
	    push @reg, _register($object, $thread, $code, $ip, $cp, 1);
	}
	$oldcp = $$cp;
	for my $register (@reg) {
	    _write($object, $thread, $register, $ip, $cp, $clone);
	}
    } elsif ($byte == BC_STO) {
	my $value = _expression($object, $thread, $code, $ip, $cp, 1);
	my $register = _register($object, $thread, $code, $ip, $cp, 1);
	$oldcp = $$cp;
	_store($object, $thread, $value, $register, $ip, $cp, $clone);
    } elsif ($byte == BC_CAR) {
	my $value = _expression($object, $thread, $code, $ip, $cp, 1);
	my $register = _register($object, $thread, $code, $ip, $cp, 0);
	$oldcp = $$cp;
	_create_array($object, $thread, $register, $value, $ip, $cp, $clone);
    } elsif ($byte == BC_COM) {
	my $splat = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $comment = _register($object, $thread, $code, $ip, $cp, 1);
	my $data = _convert_read($object, $thread, $comment, 0, $ip, $cp);
	faint($splat, $data);
    } elsif ($byte == BC_IGN) {
	my $remember = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $count = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	while ($count-- > 0) {
	    my $register = _register($object, $thread, $code, $ip, $cp, 0);
	    _ignore($object, $thread, $register, $remember, $clone);
	}
    } elsif ($byte == BC_SKI) {
	my $abstain = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $gerund = _expression($object, $thread, $code, $ip, $cp, 1);
	my $label = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $abstime = ++$object->{abstime};
	my @idx = ();
	push @idx, 'L' . $label if $label > 0;
	$gerund = [$gerund] unless 'ARRAY' eq ref $gerund;
	push @idx, map { 'G' . $$_ } grep { $$_ > 0 } @$gerund;
	my $negate = $abstain ? 0 : 1;
	for my $idx (@idx) {
	    if (! exists $thread->{abstain}{$idx}) {
		my $a = [0, 0];
		for my $th (@{$object->{threads}}) {
		    $th->{abstain}{$idx} = $a;
		}
	    }
	    $clone->{abstain}{$idx} = [$negate, $abstime]
		if defined $clone && $clone;
	    @{$thread->{abstain}{$idx}} = ($abstain, $abstime);
	}
    } elsif ($byte == BC_AST) {
	my $stash = _expression($object, $thread, $code, $ip, $cp, 0);
	my $count = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	# we get all the code, in case anything changed $cp
	my @ast = ();
	while ($count-- > 0) {
	    my $how = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	    my $value = 0;
	    $value = _expression($object, $thread, $code, $ip, $cp, 0)
		if $how & 1;
	    my $owner = 0;
	    $owner = _register($object, $thread, $code, $ip, $cp, 0)
		if $how & 2;
	    my $register = _register($object, $thread, $code, $ip, $cp, 0);
	    push @ast, [$how, $register, $owner, $value];
	}
	$oldcp = $$cp;
	# now execute it all
	for my $s (@ast) {
	    my ($how, $reg, $own, $val) = @$s;
	    _stash($object, $thread, $stash, $reg, $clone);
	    _store($object, $thread, $val, $reg, $ip, $cp, $clone) if $how & 1;
	    _enslave($object, $thread, $reg, $own, $clone) if $how & 2;
	}
    } elsif ($byte == BC_RET) {
	my $stash = _expression($object, $thread, $code, $ip, $cp, 0);
	my $count = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $size = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $assign = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	# start getting all the code, in case we're retrieving $cp
	my @ret = ();
	while ($count-- > 0) {
	    push @ret, _register($object, $thread, $code, $ip, $cp, 0);
	}
	$oldcp = $$cp;
	for my $register (@ret) {
	    _retrieve($object, $thread, $stash, $register, $size, $assign,
		      $ip, $cp, $clone);
	}
    } elsif ($byte == BC_ENS) {
	my $slave = _register($object, $thread, $code, $ip, $cp, 0);
	my $owner = _register($object, $thread, $code, $ip, $cp, 0);
	_enslave($object, $thread, $slave, $owner, $clone);
    } elsif ($byte == BC_FRE) {
	my $slave = _register($object, $thread, $code, $ip, $cp, 0);
	my $owner = _register($object, $thread, $code, $ip, $cp, 0);
	_free($object, $thread, $slave, $owner, $clone);
    } elsif ($byte == BC_DIV) {
	faint(SP_MAGIC, "Diversion during black magic is too dangerous")
	    if defined $clone && $clone;
	_expression($object, $thread, $code, $ip, $cp, 1);
    } elsif ($byte == BC_EVA) {
	my $register = _register($object, $thread, $code, $ip, $cp, 1);
	my ($value, $type) =
	    _get_slice($object, $thread, $register, $ip, $cp, 1);
	my $c = pack('C*', map { $$_ } @$value);
	my $lcp = 0;
	my $lip = 0;
	_trace($object, $$ip, $$cp, "/", 2);
	while ($lcp< length($c)) {
	    _statement($object, $thread, $c, \$lip, \$lcp, $clone);
	}
	_trace($object, $$ip, $$cp, "/", 2);
    } elsif ($byte == BC_CLO) {
	faint(SP_MAGIC, "Nested black magic") if defined $clone && $clone;
	my $new_thread = _clone($object, $thread);
	# run one statement in parallel (with limitations)
	my $w = _statement($object, $thread, $code, $ip, $cp, $new_thread);
	if ($w != STMT_WALTZ) {
	    _ip_set($new_thread, $$ip, $$cp);
	}
    } elsif ($byte == BC_RAF) {
	faint(SP_INVALID, "???? _statement/RAF") if $$cp + 2 >= length($code);
#	my $length = ord(substr($code, $$cp, 1));
#	$$cp++;
#	$length += ord(substr($code, $$cp, 1)) << 8;
#	_trace($object, $$ip, $$cp, $length, 2);
#	$$cp++;
	my $dos = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	if (rand(100) >= $dos) {
	    if (defined $clone) {
		faint(SP_MAGIC, "Random fire disrupted the black magic")
		    if $clone;
		faint(SP_WALTZ);
	    }
	    if ($$ip > 0) {
		$$ip++;
		$$cp = 0;
	    }
	    return STMT_WALTZ;
	}
    } elsif ($byte == BC_ENR) {
	my $register = _register($object, $thread, $code, $ip, $cp, 0);
	my $class = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	_enrol($object, $thread, $register, $class, $clone);
    } elsif ($byte == BC_GRA) {
	my $register = _register($object, $thread, $code, $ip, $cp, 0);
	_graduate($object, $thread, $register, $clone);
    } elsif ($byte == BC_SCH) {
	my $count = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $not_really = $count & 1;
	$count >>= 1;
	if ($count == 0) {
	    return STMT_UNSCH unless $not_really;
	    my $body = _expression($object, $thread, $code, $ip, $cp, 1);
	    my $cond = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	    if ($cond != 1) {
		my $c = pack('C*', map { $$_ }
				       'ARRAY' eq ref $body ? @$body : $$body);
		my $lcp = 0;
		my $lip = 0;
		_trace($object, $$ip, $$cp, "/", 2);
		while ($lcp< length($c)) {
		    _statement($object, $thread, $c, \$lip, \$lcp, $clone);
		}
		_trace($object, $$ip, $$cp, "/", 2);
	    }
	} else {
	    my @cond = ();
	    while ($count-- > 0) {
		my $cond = _expression($object, $thread, $code, $ip, $cp, 1);
		if ('ARRAY' eq ref $cond) {
		    $cond = pack("C*", map { $$_ } @$cond);
		} else {
		    $cond = chr($$cond);
		}
		push @cond, $cond;
	    }
	    my $body = pop @cond;
	    unshift @{$thread->{loops}}, [$body, \@cond] unless $not_really;
	}
    } elsif ($byte == BC_SIN) {
	my $module = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $file = _register($object, $thread, $code, $ip, $cp, 1);
	my ($fhandle, $fnumber) =
	    _filehandle($object, $thread, $file, $ip, $cp, 'w', 1);
	my $count = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my %map = ();
	while ($count-- > 0) {
	    my $lreg = _register($object, $thread, $code, $ip, $cp, 0);
	    my $rreg = _register($object, $thread, $code, $ip, $cp, 0);
	    _share($object, $thread, \%map, $lreg, $rreg);
	}
	my $label;
	my $sin;
	if ($fnumber >= 0) {
	    faint(SP_PURE, $module)
		if ! exists $object->{modules}{$module};
	    $sin = $object->{modules}{$module};
	    $label = $fnumber;
	} else {
	    $sin = write_object Language::INTERCAL::Object($fhandle);
	    $object->{modules}{$module} = $sin;
	    $label = 0;
	}
	$sin->call(undef, $label, \%map);
    } elsif ($byte == BC_CFS) {
	my $file = _register($object, $thread, $code, $ip, $cp, 1);
	my ($fh, $fn) = 
	    _filehandle($object, $thread, $file, $ip, $cp, 'r', 0);
	my $waltz = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	_ip_set($thread, $$ip, $$cp);
	faint(SP_WALTZ) if defined $clone && ! $clone;
	if ($waltz & 4) {
	    $object->remove_source($waltz & 8);
	}
	if ($waltz & 2) {
	    $object->strip;
	}
	$object->read_object($fh);
	if ($waltz & 1) {
	    $thread->{running} = 0 if $$ip > 0;
	}
	return STMT_WALTZ;
    } elsif ($byte == BC_CON) {
	my $mreg = _register($object, $thread, $code, $ip, $cp, 1);
	my $mname = _convert_read($object, $thread, $mreg, 0, $ip, $cp);
	my $freg = _register($object, $thread, $code, $ip, $cp, 1);
	my $fname = _convert_read($object, $thread, $freg, 0, $ip, $cp);
	my $count = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my @args = ();
	while ($count-- > 0) {
	    push @args, _register($object, $thread, $code, $ip, $cp, 1);
	}
	eval "require $mname"; die $@ if $@;
	no strict 'refs';
	&{"${mname}::$fname"}($object, $thread, @args);
    } elsif ($byte == BC_CRE) {
	my $grammar = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $symbol = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $left = _get_grammar_left($object, $thread, $code, $ip, $cp, 1);
	my $right = _get_grammar_right($object, $thread, $code, $ip, $cp);
	_create($object, $thread, $grammar, $symbol, $left, $right, $clone);
    } elsif ($byte == BC_OPT) {
	my $which = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $left = _expression($object, $thread, $code, $ip, $cp, 1);
	$left = pack('C*', 'ARRAY' eq ref $left ? @$left : $left);
	my $right = _expression($object, $thread, $code, $ip, $cp, 1);
	$right = pack('C*', 'ARRAY' eq ref $right ? @$right : $right);
	if ($which == 0) {
	    $object->{optimiser}->add($left, $right);
	} elsif ($which <= @{$thread->{grammar}}) {
	    $object->{grammar}[$which - 1]->optimise($left, $right);
	} else {
	    faint(SP_NOOPTIMISER, $which);
	}
    } elsif ($byte == BC_RSA) {
	my $move = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	while ($move-- > 0) {
	    my $from = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	    my $to = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	    _destroy_all($object, $thread, $to, $clone);
	    ($thread->{grammar}[$from], $thread->{grammar}[$to]) =
		($thread->{grammar}[$to], $thread->{grammar}[$from]);
	}
	my $nuke = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	while ($nuke-- > 0) {
	    my $grammar = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	    _destroy_all($object, $thread, $grammar, $clone);
	}
    } elsif ($byte == BC_DES) {
	my $grammar = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $symbol = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $left1 = _get_grammar_left($object, $thread, $code, $ip, $cp, 0);
	my $swap = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	if ($swap == 0) {
	    _destroy($object, $thread, $grammar, $symbol, $left1, $clone);
	} else {
	    my $left2 = _get_grammar_left($object, $thread, $code, $ip, $cp, 0);
	    _convert($object, $thread, $grammar, $symbol,
		     $left1, $left2, $swap - 1, $clone);
	}
    } elsif ($byte == BC_FCO) {
	_force_compile($object);
    } elsif ($byte == BC_BUG) {
	my $explain = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	faint($explain ? SP_BUG : SP_UNEXPLAINABLE);
    } else {
	faint(SP_INVALID, sprintf("0x%02x", $byte), "_statement");
    }
    if ($oldip != $$ip) {
	if (defined $clone) {
	    faint(SP_WALTZ) unless $clone;
	    _ip_set($clone, $oldip, $oldcp);
	}
	return STMT_WALTZ;
    }
    return STMT_NORMAL;
}

sub _rtype {
    my ($object, $thread, $code, $ip, $cp) = @_;
    if ($$cp >= length($code)) {
	faint(SP_INVALID, "???? _rtype");
    }
    my $byte = ord(substr($code, $$cp, 1));
    _trace($object, $$ip, $$cp, $byte, 0);
    $$cp++;
    while ($byte == BC_DIV) {
	# execute the statement, but don't let it waltz
	_statement($object, $thread, $code, $ip, $cp, 0);
	if ($$cp >= length($code)) {
	    faint(SP_INVALID, "???? _rtype");
	}
	$byte = ord(substr($code, $$cp, 1));
	_trace($object, $$ip, $$cp, $byte, 0);
	$$cp++;
    }
    if ($byte == BC_SPO) {
	return '.';
    } elsif ($byte == BC_TSP) {
	return ':';
    } elsif ($byte == BC_TAI) {
	return ',';
    } elsif ($byte == BC_HYB) {
	return ';';
    } elsif ($byte == BC_WHP) {
	return '@';
    } elsif ($byte == BC_DOS) {
	return '%';
    } elsif ($byte == BC_SHF) {
	return '^';
    } elsif ($byte == BC_TYP) {
	my $reg = _register($object, $thread, $code, $ip, $cp, 0);
	return $reg->[0];
    } elsif ($byte == BC_CTY) {
	my $required = _rtype($object, $thread, $code, $ip, $cp);
	faint(SP_INVALID, sprintf("0x%02x", $$required), "_rtype")
	    if ref $required;
	my $found = _rtype($object, $thread, $code, $ip, $cp);
	faint(SP_INVALID, sprintf("0x%02x", $$found), "_rtype")
	    if ref $found;
	return $found if $required eq $found;
	faint(SP_NOCLASS) if $required eq '@';
	faint(SP_ISCLASS, $found . 'xxx') if $found eq '@';
	faint(SP_NOARRAY, $found . 'xxx') if $required =~ /^[,;^]/;
	faint(SP_ISARRAY, $found . 'xxx');
    } else {
	return \$byte;
    }
}

sub _register {
    my ($object, $thread, $code, $ip, $cp, $subscript) = @_;
    my $rtype = _rtype($object, $thread, $code, $ip, $cp);
    if (! ref $rtype) {
	my $num = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	$num > 0xffff and faint(SP_SPOT, "Register", $rtype . $num);
	return [$rtype, $num];
    }
    my $byte = $$rtype;
    if ($byte == BC_OVR) {
	my $reg = _register($object, $thread, $code, $ip, $cp, 1);
	return $reg if $reg->[0] eq '/';
	faint(SP_OVERLOAD, 'overload') if $reg->[0] eq '\\';
	return ['/', $reg];
    } elsif ($byte == BC_OWN) {
	my $num = _expression($object, $thread, $code, $ip, $cp, 0);
	my $reg = _register($object, $thread, $code, $ip, $cp, 0);
	my $ret = _owner($object, $thread, $reg, $num);
	_trace($object, $$ip, $$cp, '(' . $ret->[0] . $ret->[1] . ')', 2);
	return $ret;
    } elsif ($byte == BC_SUB && $subscript) {
	my $sub = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	$sub < 1 || $sub > 0xffff and faint(SP_SUBSCRIPT, $sub);
	my $reg = _register($object, $thread, $code, $ip, $cp, 1);
	$reg->[0] =~ m(^[,;^/\\\@])
	    or faint(SP_NOARRAY, $reg->[0] . $reg->[1]);
	return [@$reg, $sub];
    } elsif ($byte == BC_OVM) {
	my ($val1, $val2);
	if ($$cp < length($code) && ord(substr($code, $$cp, 1)) == BC_INT) {
	    # minor optimisation - avoid interleaving and uninterleaving
	    $$cp++;
	    $val1 = _expression($object, $thread, $code, $ip, $cp, 0)->spot;
	    $val2 = _expression($object, $thread, $code, $ip, $cp, 0)->spot;
	} else {
	    my $val = _expression($object, $thread, $code, $ip, $cp, 0);
	    my $base = ${$thread->{registers}{&IREG_BA}{value}};
	    ($val1, $val2) = _uninterleave($base, $val);
	}
	return ['\\', [$$val1, $$val2]];
    } else {
	faint(SP_INVALID, sprintf("0x%02x", $byte), "_register");
    }
}

sub _expression {
    my ($object, $thread, $code, $ip, $cp, $multiple) = @_;
    if ($$cp >= length($code)) {
	faint(SP_INVALID, "???? _expression");
    }
    my $byte = ord(substr($code, $$cp, 1));
    _trace($object, $$ip, $$cp, $byte, 0);
    $$cp++;
    while ($byte == BC_DIV) {
	# execute the statement, but don't let it waltz
	_statement($object, $thread, $code, $ip, $cp, 0);
	if ($$cp >= length($code)) {
	    faint(SP_INVALID, "???? _expression");
	}
	$byte = ord(substr($code, $$cp, 1));
	_trace($object, $$ip, $$cp, $byte, 0);
	$$cp++;
    }
    my $base = ${$thread->{registers}{&IREG_BA}{value}};
    if ($byte == BC_INT) {
	my @val1 = _expression($object, $thread, $code, $ip, $cp, 0)
		       ->spot
		       ->digits($base);
	my @val2 = _expression($object, $thread, $code, $ip, $cp, 0)
		       ->spot
		       ->digits($base);
	my @result = ();
	while (@val1 && @val2) {
	    push @result, (shift @val1), (shift @val2);
	}
	return from_digits Language::INTERCAL::Numbers $base, @result;
    } elsif ($byte == BC_SEL) {
	my @val1 = _expression($object, $thread, $code, $ip, $cp, 0)
		       ->digits($base);
	my @val2 = _expression($object, $thread, $code, $ip, $cp, 0)
		       ->digits($base);
	unshift @val1, 0 while @val1 < @val2;
	my @result = map { [] } (0..$base - 1);
	while (@val2) {
	    my $val1 = pop @val1;
	    my $val2 = pop @val2;
	    my $result = 0;
	    if ($val1 && $val2) {
		unshift @{$result[$val2]}, $val1 > $val2 ? $val1 : $val2;
	    } else {
		unshift @{$result[$val2]}, 0;
	    }
	}
	@result = map { @{ $result[$_] } } (0..$base - 1);
	return from_digits Language::INTERCAL::Numbers $base, @result;
    } elsif ($byte == BC_BUT) {
	my $prefer = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	faint(SP_ILLEGAL, "${prefer}BUT", $base)
	    if $prefer != 7 && $prefer > $base - 2;
	my @value = _expression($object, $thread, $code, $ip, $cp, 0)
		        ->digits($base);
	unshift @value, $value[-1];
	my @result = ();
	while (@value > 1) {
	    my $val1 = shift @value;
	    my $val2 = $value[0];
	    if ($val1 == $prefer || $val2 == $prefer) {
		push @result, $prefer;
	    } elsif ($val1 > $val2) {
		push @result, $val1;
	    } else {
		push @result, $val2;
	    }
	}
	return from_digits Language::INTERCAL::Numbers $base, @result;
   } elsif ($byte == BC_AWC) {
	faint(SP_ILLEGAL, "AWC", $base) if $base < 3;
	my @value = _expression($object, $thread, $code, $ip, $cp, 0)
		        ->digits($base);
	unshift @value, $value[-1];
	my @result = ();
	while (@value > 1) {
	    my $val = shift @value;
	    push @result, $val + $value[0];
	}
	return from_digits Language::INTERCAL::Numbers $base, @result;
    } elsif ($byte == BC_SWB) {
	my @value = _expression($object, $thread, $code, $ip, $cp, 0)
		        ->digits($base);
	unshift @value, $value[-1];
	my @result = ();
	while (@value > 1) {
	    my $val = shift @value;
	    push @result, ($val - $value[0]) % $base;
	}
	return from_digits Language::INTERCAL::Numbers $base, @result;
    } elsif ($byte == BC_SPL) {
	faint(SP_SPLAT) if ! exists $thread->{splat};
	return new Language::INTERCAL::Numbers::Spot($thread->{splat});
    } elsif ($byte == BC_IND) {
	my $register = _register($object, $thread, $code, $ip, $cp, 0);
	$register = $register->[1] if $register->[0] eq '/';
	return new Language::INTERCAL::Numbers::Spot($register->[1]);
    } elsif ($byte == BC_FLA) {
	my $label = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	$label = _find_label($object, $thread, $label, $ip, $cp);
	_trace($object, $$ip, $$cp, "($label)", 2);
	return new Language::INTERCAL::Numbers::Spot($label);
    } elsif ($byte == BC_CLA) {
	my $subjects = _expression($object, $thread, $code, $ip, $cp, 1);
	$subjects = [$subjects] unless 'ARRAY' eq ref $subjects;
	my $class = _find_class($thread, map { $$_ } @$subjects);
	_trace($object, $$ip, $$cp, "(\@$class)", 2);
	return new Language::INTERCAL::Numbers::Spot($class);
    } elsif ($byte == BC_LEC) {
	my $register = _register($object, $thread, $code, $ip, $cp, 0);
	my $subject = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my ($lecture, $class) = _find_lecture($object, $thread, $register,
					      $subject, $ip, $cp);
	_trace($object, $$ip, $$cp, "($lecture)", 2);
	return new Language::INTERCAL::Numbers::Spot($lecture);
    } elsif ($byte == BC_LCL) {
	my $register = _register($object, $thread, $code, $ip, $cp, 0);
	my $subject = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my ($lecture, $class) = _find_lecture($object, $thread, $register,
					      $subject, $ip, $cp);
	_trace($object, $$ip, $$cp, "($class)", 2);
	return new Language::INTERCAL::Numbers::Spot(substr($class, 1));
    } elsif ($byte == BC_MUL && $multiple) {
	my $size = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my @value = ();
	while ($size-- > 0) {
	    push @value, _expression($object, $thread, $code, $ip, $cp, 0);
	}
	return \@value;
    } elsif ($byte == BC_ENC) {
	my $conv = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	faint(SP_ENCODE, $conv) if $conv < 1 || $conv > @conversions;
	my $string = _register($object, $thread, $code, $ip, $cp, 1);
	my $data = _convert_read($object, $thread, $string, 0, $ip, $cp);
	my ($func, $splat) = @{$conversions[$conv - 1]};
	my $ret = &$func($data);
	faint($splat, $data) if ! defined $ret;
	_trace($object, $$ip, $$cp, "($ret)", 2);
	return new Language::INTERCAL::Numbers::Spot($ret);
    } elsif ($byte == BC_EVA) {
	my $register = _register($object, $thread, $code, $ip, $cp, 1);
	my ($value, $type) =
	    _get_slice($object, $thread, $register, $ip, $cp, 1);
	my $c = pack('C*', map { $$_ } @$value);
	my $lcp = 0;
	my $lip = 0;
	_trace($object, $$ip, $$cp, "/", 2);
	$value = _expression($object, $thread, $c, \$lip, \$lcp, $multiple);
	_trace($object, $$ip, $$cp, "/", 2);
	faint(SP_GARBAGE, "Extra Vehicular Activity") if $lcp < length($c);
	return $value;
    } elsif ($byte == BC_FIG) {
	my $symbol = _register($object, $thread, $code, $ip, $cp, 1);
	my $data = _convert_read($object, $thread, $symbol, 0, $ip, $cp);
	chomp($data);
	my $idx = $thread->{grammar}[0]->find_symbol($data);
	_trace($object, $$ip, $$cp, "($idx)", 2);
	return new Language::INTERCAL::Numbers::Spot($idx);
    } elsif ($byte == BC_GCO || $byte == BC_GCE and $multiple) {
	my $grammar = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $symbol = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my $source = _register($object, $thread, $code, $ip, $cp, 1);
	my $data = _convert_read($object, $thread, $source, 0, $ip, $cp);
	return _generate_value($object, $thread, $grammar, $symbol,
			       $data, $byte == BC_GCE);
    } else {
	if (is_constant($byte)) {
	    my $icp = $$cp;
	    $$cp--;
	    my $val = unBC($code, $cp);
	    _trace($object, $$ip, $$cp, '#' . $$val, 2) if $icp != $$cp;
	    return $object->{assign}{$$val} if exists $object->{assign}{$$val};
	    return $val;
	}
	$$cp--;
	my $register = eval { _register($object, $thread, $code, $ip, $cp, 1) };
	if ($@) {
	    $@ =~ s/_register/_expression/g;
	    die $@;
	}
	return _get($object, $thread, $register, $ip, $cp) unless $multiple;
	return (_get_slice($object, $thread, $register, $ip, $cp, 1))[0];
    }
}

sub _s_expression {
    my ($object, $thread, $code, $ip, $cp, $value) = @_;
    if ($$cp >= length($code)) {
	faint(SP_INVALID, "???? _s_expression");
    }
    my $byte = ord(substr($code, $$cp, 1));
    _trace($object, $$ip, $$cp, $byte, 0);
    $$cp++;
    my $base = ${$thread->{registers}{&IREG_BA}{value}};
    if ($byte == BC_INT) {
	my ($val1, $val2) = _uninterleave($base, $value);
	_s_expression($object, $thread, $code, $ip, $cp, $val1);
	_s_expression($object, $thread, $code, $ip, $cp, $val2);
	return;
    } elsif ($byte == BC_SEL) {
	_s_expression($object, $thread, $code, $ip, $cp, $value);
	my @value = $value->digits($base);
	my $num = 0;
	for my $v (@value) {
	    $num = 1 if $v;
	    $v = $num;
	}
	$value = from_digits Language::INTERCAL::Numbers $base, @value;
	_s_expression($object, $thread, $code, $ip, $cp, $value);
    } elsif ($byte == BC_BUT) {
	my $prefer = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	my @value = $value->digits($base);
	faint(SP_ILLEGAL, "${prefer}BUT", $base)
	    if $prefer != 7 && $prefer > $base - 2;
	my @check = @value;
	push @value, $value[0];
	my @result = ();
	while (@value > 1) {
	    my $val1 = shift @value;
	    my $val2 = $value[0];
	    if ($val1 == $prefer && $val2 == $prefer) {
		push @result, $prefer;
	    } elsif ($val1 == $prefer) {
		push @result, $val2;
	    } elsif ($val2 == $prefer) {
		push @result, $val1;
	    } elsif ($val1 > $val2) {
		push @result, $val2;
	    } else {
		push @result, $val1;
	    }
	}
	my $new_value = from_digits Language::INTERCAL::Numbers $base, @result;
	$value = $$value;
	unshift @result, $result[-1];
	while (@result > 1) {
	    my $val1 = shift @result;
	    my $val2 = $result[0];
	    my $result = '';
	    if ($val1 == $prefer || $val2 == $prefer) {
		$result = $prefer;
	    } elsif ($val1 > $val2) {
		$result = $val1;
	    } else {
		$result = $val2;
	    }
	    if ($result != shift @check) {
		faint(SP_ASSIGN, $base, "${prefer}BUT", $value)
	    }
	}
	_s_expression($object, $thread, $code, $ip, $cp, $new_value);
    } elsif ($byte == BC_AWC) {
	my @value = $value->digits($base);
	faint(SP_ILLEGAL, "AWC", $base) if $base < 3;
	my @check = @value;
	my $carry = 0;
	for my $v (reverse @value) {
	    ($v, $carry) = ($carry, ($v - $carry) % $base);
	}
	my $new_value = from_digits Language::INTERCAL::Numbers $base, @value;
	$value = $$value;
	unshift @value, $value[-1];
	while (@value > 1) {
	    my $val1 = shift @value;
	    $val1 = ($val1 + $value[0]) % $base;
	    if ($val1 != shift @check) {
		faint(SP_ASSIGN, $base, "AWC", $value);
	    }
	}
	_s_expression($object, $thread, $code, $ip, $cp, $new_value);
    } elsif ($byte == BC_SWB) {
	my @value = $value->digits($base);
	my @check = @value;
	my $carry = 0;
	for my $v (reverse @value) {
	    ($v, $carry) = ($carry, ($v + $carry) % $base);
	}
	my $new_value = from_digits Language::INTERCAL::Numbers $base, @value;
	$value = $$value;
	unshift @value, $value[-1];
	while (@value > 1) {
	    my $val1 = shift @value;
	    $val1 = ($val1 -$value[0]) % $base;
	    if ($val1 != shift @check) {
		faint(SP_ASSIGN, $base, "SWB", $value);
	    }
	}
	_s_expression($object, $thread, $code, $ip, $cp, $new_value);
    } elsif ($byte == BC_SPL) {
	# Assigning to splat is quite fatal
	faint($$value);
    } elsif ($byte == BC_IND) {
	# Hey! we cvan assign to register numbers now! Modify constants!
	my $register = _register($object, $thread, $code, $ip, $cp, 1);
	my $v = new Language::INTERCAL::Numbers::Spot($register->[1]);
	$object->{assign}{$$v} = $value;
    } elsif ($byte == BC_ENC) {
	my $conv = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	faint(SP_ENCODE, $conv) if $conv < 1 || $conv > @conversions;
	my ($func, $splat) = @{$conversions[$conv - 1]};
	$value = $$value;
	my $res = &$func($value);
	faint($splat, $value) if ! defined $res || $res != $value;
	$res = new Language::INTERCAL::Numbers::Spot($res);
	_s_expression($object, $thread, $code, $ip, $cp, $res);
    } elsif ($byte == BC_DIV) {
	faint(SP_DIVERSION);
    } elsif (is_constant($byte)) {
	my $icp = $$cp;
	$$cp--;
	my $val = unBC($code, $cp);
	_trace($object, $$ip, $$cp, '#' . $$val, 2) if $icp != $$cp;
	$object->{assign}{$$val} = $value;
    } else {
	$$cp--;
	my $register = eval { _register($object, $thread, $code, $ip, $cp, 1) };
	die $@ if $@ && ($@ !~ /^(\d+)\s/ || $1 != SP_INVALID);
	faint(SP_INVALID, sprintf("0x%02x", $byte), "_s_expression") if $@;
	_store($object, $thread, $value, $register, $ip, $cp, undef);
    }
}

sub _uninterleave {
    my ($base, $value) = @_;
    my @value = $value->twospot->digits($base);
    my @val1 = ();
    my @val2 = ();
    while (@value) {
	push @val1, shift @value;
	push @val2, shift @value;
    }
    return (from_digits Language::INTERCAL::Numbers($base, @val1),
	    from_digits Language::INTERCAL::Numbers($base, @val2));
}

sub _set_fh {
    my $name = shift;
    my $reg = shift;
    @_ == 1 or @_ == 2 or croak "Usage: OBJECT->$name [(FILEHANDLE)]";
    my $object = shift;
    if (@_) {
	my $t = shift;
	ref $t && UNIVERSAL::isa($t, 'Language::INTERCAL::GenericIO')
	    or croak "Invalid filehandle";
	$object->{$name} = $t;
	for my $thread (@{$object->{threads}}) {
	    $thread->{registers}{$reg}{file} = $t;
	}
    } else {
	$object->{$name};
    }
}

sub splat {
    @_ == 2 or @_ == 4 or croak "Usage: OBJECT->splat(THREAD [, CODE, CAUSE])";
    my $object = shift;
    my $thread = shift;
    if ($thread =~ /^\d+$/) {
	$thread = 0 if $thread >= @{$object->{threads}};
	return () if $thread >= @{$object->{threads}};
	$thread = $object->{threads}[$thread];
    }
    if (@_) {
	my ($num, $cause) = @_;
	$num %= 1000;
	my $desc = splatdescription($num, $cause);
	$thread->{splat} = $num;
	$thread->{splatcause} = $num;
	$thread->{splatname} = splatname($num);
	$thread->{splatdescription} = $desc;
	$thread->{running} = 0;
	_set_read_charset($object, $thread, 'splat_fh');
	$object->{splat_fh}->read_text(sprintf "%03d %s\n", $num, $desc);
	return $object;
    } elsif (exists $thread->{splat}) {
	return $thread->{splat} unless wantarray;
	return ($thread->{splat}, $thread->{splatname},
		$thread->{splatdescription});
    } else {
	return ();
    }
}

sub splat_fh {
    _set_fh('splat_fh', IREG_OSFH, @_);
}

sub unsplat {
    @_ == 2 or croak "Usage: OBJECT->unsplat(THREAD)";
    my $object = shift;
    my $thread = shift;
    if ($thread =~ /^\d+$/) {
	$thread = 0 if $thread >= @{$object->{threads}};
	return $object if $thread >= @{$object->{threads}};
	$thread = $object->{threads}[$thread];
    }
    delete $thread->{splat};
    delete $thread->{splatname};
    delete $thread->{splatcause};
    delete $thread->{splatdescription};
    _ip_set($thread, 1, 0);
    $object;
}

sub _set_read_charset {
    my ($object, $thread, $fh) = @_;
    $fh = $object->{$fh};
    my $ch = ${$thread->{registers}{&IREG_CR}{value}};
    $fh->read_charset($ch);
}

sub _set_write_charset {
    my ($object, $thread, $fh) = @_;
    $fh = $object->{$fh};
    my $ch = ${$thread->{registers}{&IREG_CW}{value}};
    $fh->write_charset($ch);
}

sub _store {
    my ($object, $thread, $value, $register, $ip, $cp, $clone) = @_;
    my ($type, $number, @sub) = @$register;
    if ($type eq '\\') {
	if ('ARRAY' eq ref $value) {
	    faint(SP_NOARRAY, "overload") if @$value != 1;
	    $value = $value->[0];
	}
	faint(SP_SUBSCRIPT, "overload with more than 1 subscript")
	    if @sub > 1;
	_trace($object, $$ip, $$cp, "($$value)", 2);
	my ($val1, $val2) = @$number;
	while ($val1 <= $val2 && $val1 <= 0xffff) {
	    for my $rtype ('.', ',', ':', ';', '@', '%', '^') {
		my $n = $rtype . $val1;
		next if exists $thread->{registers}{$n} &&
			exists $thread->{registers}{$n}{ignore};
		if (! exists $thread->{registers}{$n}) {
		    next if $rtype eq '%' || $rtype eq '^';
		    _create_register($object, $n);
		}
		_separate_register($object, $thread, $clone, $n)
		    if defined $clone && $clone;
		my $regptr = $thread->{registers}{$n};
		_store_overload($n, $regptr, $value, @sub);
	    }
	    $val1++;
	}
	return;
    }
    my $overload = 0;
    my @osub = ();
    if ($type eq '/') {
	$overload = 1;
	@osub = @sub;
	($type, $number, @sub) = @$number;
	faint(SP_NOARRAY, "/$type$number") if @sub;
    }
    $number = $type . $number;
    return if exists $thread->{registers}{$number} &&
	      exists $thread->{registers}{$number}{ignore};
    _create_register($object, $number)
	if ! exists $thread->{registers}{$number};
    _separate_register($object, $thread, $clone, $number)
	if defined $clone && $clone;
    my $regptr = $thread->{registers}{$number};
    if ($overload) {
	_store_overload($number, $regptr, $value, @osub);
	return;
    }
    # enslave %OS to the register about to be modified
    $thread->{registers}{&IREG_OS}{owner} = [$number];
    if (exists $regptr->{overload}) {
	faint(SP_NOARRAY, $number) if @sub;
	_overloaded_store($object, $thread, $register, $number,
			  $regptr, $ip, $value);
	return;
    }
    if ($type eq '.' || $type eq ':' || $type eq '%') {
	faint(SP_NOARRAY, $number) if @sub;
	if ('ARRAY' eq ref $value) {
	    faint(SP_NOARRAY, $number) if @$value != 1;
	    $value = $value->[0];
	}
	_trace($object, $$ip, $$cp, "($$value)", 2);
	my $base = ${$thread->{registers}{&IREG_BA}{value}};
	if ($base < 2) { $base = 2 } elsif ($base > 7) { $base = 7 }
	my $max = (qw(65535 59048 65535 15624 46655 16806))[$base - 2];
	if ($type ne ':') {
	    $value = $value->spot;
	    $$value > $max and faint(SP_TWOSPOT, $number, $$value);
	} else {
	    $value = $value->twospot;
	    $$value > ($max + 1) * ($max + 1) - 1
		and faint(SP_TOOMANYSPOTS, $$value, $number);
	}
	if ($number eq IREG_IP) {
	    $$ip = $$value;
	} elsif ($number eq IREG_CP) {
	    $$cp = $$value;
	} elsif ($number eq IREG_BA) {
	    my $base = $$value;
	    faint(SP_BASE, $base) if $base < 2 || $base > 7;
	} elsif ($number eq IREG_GR) {
	    my $gnum = $$value;
	    faint(SP_EVOLUTION, $gnum) if $gnum > @{$thread->{grammar}};
	} elsif ($number eq IREG_IS) {
	    $value = new Language::INTERCAL::Numbers::Spot 1 if $$value < 1;
	} elsif ($number eq IREG_IC) {
	    $value = new Language::INTERCAL::Numbers::Spot 1 if $$value > 1;
	}
	delete $regptr->{is_default};
	$regptr->{value} = $value;
	return;
    }
    if (@sub) {
	if ('ARRAY' eq ref $value) {
	    faint(SP_NOARRAY, $number) if @$value != 1;
	    $value = $value->[0];
	}
	$value = $type eq ';' ? $value->twospot : $value->spot;
	_trace($object, $$ip, $$cp, "($$value)", 2);
	exists $thread->{registers}{$number}{dimension}
	    or faint(SP_NODIM, $number);
	my @dim = @{$thread->{registers}{$number}{dimension}};
	my $index = join(' ', @sub);
	faint(SP_SUBSCRIPT, "wrong number of subscripts")
	    if @dim != @sub;
	while (@dim) {
	    my $d = shift @dim;
	    my $s = shift @sub;
	    faint(SP_SUBSCRIPT, $s) if $s < 1 || $s > $d;
	}
	$thread->{registers}{$number}{value}{$index} = {}
	    if ! exists $thread->{registers}{$number}{value}{$index};
	delete $thread->{registers}{$number}{is_default};
	$regptr = $regptr->{value}{$index};
	if ($type eq '@') {
	    my $s = $$value;
	    faint(SP_EARLY, $index, $number, $s) if $s < 1000;
	    my $ptr = _find_label($object, $thread, $s, $ip, $cp);
	    $regptr->{place} = $ptr;
	    $regptr->{compile} = ${$thread->{compile}};
	}
	$regptr->{value} = $value;
	return;
    }
    faint(SP_ISCLASS, $number) if $type eq '@';
    # (re)dimension array
    my @value = 'ARRAY' eq ref $value ? @$value : ($value);
    faint(SP_SUBSCRIPT, "dimension with no subscripts") if @value < 1;
    for my $v (@value) {
	$v = $$v;
	$v < 1 || $v > 0xffff and faint(SP_SUBSCRIPT, $v);
    }
    $thread->{registers}{$number}{value} = {};
    $thread->{registers}{$number}{dimension} = \@value;
    delete $thread->{registers}{$number}{is_default};
}

sub _store_overload {
    my ($number, $regptr, $value, @sub) = @_;
    if (@sub) {
	if ('ARRAY' eq ref $value) {
	    faint(SP_NOARRAY, "/$number") if @$value != 1;
	    $value = $value->[0];
	}
	$value = $value->spot;
	exists $regptr->{overload} or faint(SP_NODIM, "/$number");
	faint(SP_SUBSCRIPT, "overload with more than one subscript")
	    if 1 != @sub;
	my $index = shift @sub;
	my $dim = length($regptr->{overload});
	faint(SP_SUBSCRIPT, $index)
	    if $index < 1 || $index > $dim;
	$value = $$value;
	$value > 0xff and faint(SP_SPOT, "/$number", $value);
	substr($regptr->{overload}, $index - 1, 1) = chr($value);
	delete $regptr->{is_default};
	return;
    }
    # (re)dimension overload array
    if ('ARRAY' eq ref $value) {
	faint(SP_SUBSCRIPT, "overload with more than one subscript")
	    if 1 != @$value;
	$value = $value->[0];
    }
    $value = $value->spot;
    if ($$value) {
	$regptr->{overload} = chr(0) x $$value;
    } else {
	delete $regptr->{overload};
    }
    delete $regptr->{is_default};
}

sub _overloaded_store {
    my ($object, $thread, $register, $rname, $regptr, $ip, $value) = @_;
    my $code = $regptr->{overload};
    delete $regptr->{overload};
    my $lcp = 0;
    unshift @{$thread->{registers}{&IREG_OV}{owner}}, $register;
    _trace($object, $$ip, $lcp, "[", 2);
    eval {
	_s_expression($object, $thread, $code, $ip, \$lcp, $value);
	faint(SP_GARBAGE, "overload assign to", $rname)
	    if $lcp < length($code);
    };
    _trace($object, $$ip, $lcp, "]", 2);
    shift @{$thread->{registers}{&IREG_OV}{owner}};
    die $@ if $@;
    $regptr->{overload} = $code;
}

sub _ignore {
    my ($object, $thread, $register, $remember, $clone) = @_;
    my ($type, $number, @sub) = @$register;
    faint(SP_OVERLOAD, "ignore") if $type eq '/' || $type eq '\\';
    $number = $type . $number;
    _create_register($object, $number)
	if ! exists $thread->{registers}{$number};
    if ($remember) {
	delete $thread->{registers}{$number}{ignore};
    } else {
	$thread->{registers}{$number}{ignore} = 0;
    }
    return $object if ! defined $clone || ! $clone;
    _separate_register($object, $thread, $clone, $number)
	if defined $clone && $clone;
    if ($remember) {
	$clone->{registers}{$number}{ignore} = 0;
    } else {
	delete $clone->{registers}{$number}{ignore};
    }
    $object;
}

# The following subroutine handles the rather dubious case in which the
# compiled program has changed, and the program counter needs adjusting
# in all threads to find where the current code has gone. The reason it
# is called _forall_statements is because this can only happen when we
# sweep through the program, for example to find come froms, labels, and
# what have you. In all other cases, the program counter automagically
# adapts to the code. Really. Look at _run_code() if you don't believe me
sub _forall_statement {
    my ($object, $thread, $ip, $cp, $code) = @_;
    my $sp = $thread->{statements};

    # first get a list of threads sharing @statements which need updating
    my @threads = grep { $_->{statements} == $sp && $_->{running} }
		       @{$object->{threads}};

    # then save the file/pos for each statement
    my $fp = $object->{file};
    for my $th (@threads) {
	my ($ip, $cp) = _ip($th);
	my ($file, $pos);
	if ($$ip == 0) {
	    $file = -3;
	} elsif ($$ip < @$sp) {
	    my $s = $sp->[$$ip];
	    $file = $s->[0];
	    $pos = $s->[1];
	} elsif ($$ip > 1) {
	    my $s = $sp->[$$ip - 1];
	    $file = $s->[0];
	    $pos = $s->[2];
	    while ($file < @$fp && $pos >= length($fp->[$file][1])) {
		$file++;
		$pos = 0;
	    }
	} else {
	    $file = $pos = 0;
	}
	$th = [$th, $ip, $file, $pos];
    }

    # if file < 0 or the thread is dead the IP won't need to change
    @threads = grep { $_->[2] >= 0 } @threads;

    # now start at the first statement and see if we need any recompile
    my $st = 1;
    my $tc = ${$thread->{compile}};
    while (1) {
	# note, we could keep statements "from the next file" or at least
	# keep track of the position in the source to avoid recompiling
	# later statements. We'll do this in a later version
	if ($st < @$sp && $sp->[$st][0] >= 0 && $sp->[$st][4] < $tc) {
	    _revalidate($object, $thread, $sp, $st);
	}
	if ($st >= @$sp) {
	    last if _compile($object, $thread, $st, 0);
	}
	# now we have a compiled statement, execute whatever code they gave us
	my $s = $sp->[$st];
	&$code($st, $s);
	# look for dangling program counters
	my $tp = 0;
	while ($tp < @threads) {
	    my ($th, $ip, $file, $start) = @{$threads[$tp]};
	    $tp++;
	    # if file < $s->[0] or file == $s->[0] && start <= $s->[2]...
	    next if $file > $s->[0];
	    next if $file == $s->[0] && $start >= $s->[2];
	    # this will cause Heisenbugs when running the quantum emulator;
	    # however this is required by the definition of the language
	    $tp--;
	    $$ip = $st;
	    splice(@threads, $tp, 1);
	}
	$st++;
    }

    # if there are still dangling program counters, the corresponding threads
    # will have died a mysterious death, like Schr�dinger's cat
    if (@threads) {
	my $last = scalar(@$sp);
	_compile($object, $thread, $last, 1);
	for my $th (@threads) {
	    ${$th->[1]} = $last;
	}
    }
}

sub _come_from {
    my ($object, $thread, $label, $gerund, $ip, $cp) = @_;
    $label > 0xffff and faint(SP_SPOT, "Label", $label);
    my @dest = ();
    # we cannot keep an index of come froms, because they might not
    # have been compiled yet!
    _forall_statement($object, $thread, $ip, $cp, sub {
	my ($st, $stp) = @_;
	return if $stp->[7] != BC_CFR;
	my $abstain = $stp->[11];
	my $time = 0;
	my $ta = $thread->{abstain};
	if ($stp->[9] && exists $ta->{'G' . $stp->[9]}) {
	    my ($gabstain, $gtime) = @{$ta->{'G' . $stp->[9]}};
	    ($abstain, $time) = ($gabstain, $gtime) if $gtime > $time;
	}
	if ($stp->[10] && exists $ta->{'L' . $stp->[10]}) {
	    my ($labstain, $ltime) = @{$ta->{'L' . $stp->[10]}};
	    ($abstain, $time) = ($labstain, $ltime) if $ltime > $time;
	}
	return if $abstain;
	my $code = $stp->[3];
	my $lcp = $stp->[5];
	my $raf = $stp->[6];
	my $clone = $stp->[8];
	_trace($object, $ip, 0, "<", 2);
	my $lst = $st;
	my $lwant = ${_expression($object, $thread, $code, \$lst, \$lcp, 0)};
	my $gwant = _expression($object, $thread, $code, \$lst, \$lcp, 1);
	my %gwant = map { $$_ ? ($$_ => 1) : () }
		    'ARRAY' eq ref $gwant ? @$gwant : $gwant;
	if ($lwant != $label && ! exists $gwant{$gerund}) {
	    _trace($object, $ip, 0, ">", 2);
	    return;
	}
	if (defined $raf && $raf > 0) {
	    my $dos = ${_expression($object, $thread, $code, \$lst, \$raf, 0)};
	    if (rand(100) >= $dos) {
		_trace($object, $ip, 0, ">", 2);
		return;
	    }
	}
	my $stash = _expression($object, $thread, $code, \$lst, \$lcp, 0);
	my $count = ${_expression($object, $thread, $code, \$lst, \$lcp, 0)};
	my @regs = ();
	while ($count-- > 0) {
	    push @regs, _register($object, $thread, $code, \$lst, \$lcp, 0);
	}
	_trace($object, $ip, 0, "!>", 2);
	push @dest, [$lst, $lcp, $clone, $stash, @regs];
    });
    faint(SP_COMEFROM, $label)
	if @dest > 1 && ! (${$thread->{registers}{&IREG_CF}{value}} & 1);
    while (@dest > 1 || (@dest && $dest[0][2])) {
	my ($lst, $lcp, $op, $stash, @regs) = @{shift @dest};
	my $new_thread = _clone($object, $thread);
	for my $reg (@regs) {
	    # note: stash the "old" IP/CP, not the "new" LST/LCP
	    _stash($object, $new_thread, $stash, $reg, $thread);
	}
	_ip_set($new_thread, $lst, $lcp);
    }
    if (@dest) {
	my ($lst, $lcp, $op, $stash, @regs) = @{shift @dest};
	for my $reg (@regs) {
	    # note: stash the "old" IP/CP, not the "new" LST/LCP
	    _stash($object, $thread, $stash, $reg, undef);
	}
	$$ip = $lst;
	$$cp = $lcp;
	return;
    }
}

sub _find_class {
    my ($thread, @subjects) = @_;
    my @found = ();
    my $tr = $thread->{registers};
    for my $class (grep { /^\@/ && exists $tr->{$_}{value} } keys %$tr) {
	my $ok = 1;
	for my $subject (@subjects) {
	    next if exists $tr->{$class}{value}{$subject};
	    $ok = 0;
	    last;
	}
	push @found, $class if $ok;
    }
    faint(SP_HOLIDAY, join(' + ', @subjects)) if ! @found;
    return substr($found[0], 1) if @found == 1;
    faint(SP_CLASSWAR, $found[0], $found[1]);
}

sub _find_lecture {
    my ($object, $thread, $register, $subject, $ip, $cp) = @_;
    my ($type, $number, @sub) = @$register;
    faint(SP_OVERLOAD, "_find_lecture") if $type eq '/' || $type eq '\\';
    $number = $type . $number;
    my $tr = $thread->{registers};
    faint(SP_NOSTUDENT, $number)
	if ! exists $tr->{$number} || ! exists $tr->{$number}{enrol};
    my @found = ();
    for my $class (keys %{$tr->{$number}{enrol}}) {
	$class = '@' . $class;
	push @found, $class if exists $tr->{$class}{value}{$subject};
    }
    faint(SP_NOCURRICULUM, $subject, $number) if ! @found;
    faint(SP_CLASSWAR, $found[0], $found[1]) if @found > 1;
    my $class = $found[0];
    my $cptr = $tr->{$class}{value}{$subject};
    return ($cptr->{place}, $class)
	if exists $cptr->{place} &&
	   exists $cptr->{compile} &&
	   $cptr->{compile} == ${$thread->{compile}};
    my $s = ${$cptr->{value}};
    faint(SP_EARLY, $subject, $class, $s) if $s < 1000;
    my $ptr = _find_label($object, $thread, $s, $ip, $cp);
    $cptr->{place} = $ptr;
    $cptr->{compile} = ${$thread->{compile}};
    return ($ptr, $class);
}

sub _enrol {
    my ($object, $thread, $register, $class, $clone) = @_;
    my ($type, $number, @sub) = @$register;
    faint(SP_OVERLOAD, "_enrol") if $type eq '/' || $type eq '\\';
    $number = $type . $number;
    my $tr = $thread->{registers};
    _create_register($object, $number)
	if ! exists $tr->{$number};
    _separate_register($object, $thread, $clone, $number)
	if defined $clone && $clone;
    $tr->{$number}{enrol} = {}
	if ! exists $tr->{$number}{enrol};
    $tr->{$number}{enrol}{$class} = 1;
}

sub _graduate {
    my ($object, $thread, $register, $clone) = @_;
    my ($type, $number, @sub) = @$register;
    faint(SP_OVERLOAD, "_graduate") if $type eq '/' || $type eq '\\';
    $number = $type . $number;
    my $tr = $thread->{registers};
    faint(SP_NOSTUDENT, $number)
	if ! exists $tr->{$number} || ! exists $tr->{$number}{enrol};
    _separate_register($object, $thread, $clone, $number)
	if defined $clone && $clone;
    delete $tr->{$number}{enrol};
}

sub _find_label {
    my ($object, $thread, $label, $ip, $cp) = @_;
    faint(SP_NOSUCHLABEL, $label) if ! $label;
    my @found = ();
    _forall_statement($object, $thread, $ip, $cp, sub {
	my ($st, $stp) = @_;
	push @found, $st if $stp->[10] == $label;
    });
    faint(SP_NOSUCHLABEL, $label) if ! @found;
    return $found[0] if @found == 1;
    faint(SP_REPEATLABEL, scalar(@found), $label);
}

sub _get {
    my ($object, $thread, $register, $ip, $cp) = @_;
    my ($type, $number, @sub) = @$register;
    my @osub = ();
    my $overload = 0;
    if ($type eq '/') {
	$overload = 1;
	@osub = @sub;
	($type, $number, @sub) = @$number;
	faint(SP_NOARRAY, "/$type$number") if @sub;
    } elsif ($type eq '\\') {
	faint(SP_OVERLOAD, "_get");
    }
    $number = $type . $number;
    my $regptr = $thread->{registers}{$number};
    return _get_overload($number, $regptr, @osub) if $overload;
    if (exists $regptr->{overload}) {
	return _overloaded_get($object, $thread, $register, $regptr, $ip);
    }
    if ($type eq '.' || $type eq ':' || $type eq '%') {
	if ($number eq IREG_IP) {
	    return new Language::INTERCAL::Numbers::Spot($$ip);
	} elsif ($number eq IREG_CP) {
	    return new Language::INTERCAL::Numbers::Spot($$cp);
	} elsif (exists $regptr->{value}) {
	    return $regptr->{value};
	} else {
	    return new Language::INTERCAL::Numbers 0, $type eq ':' ? 32 : 16;
	}
    }
    exists $thread->{registers}{$number}
	&& exists $thread->{registers}{$number}{dimension}
	    or faint(SP_NODIM, $number);
    faint(SP_ISARRAY, $number) unless @sub;
    my @dim = @{$thread->{registers}{$number}{dimension}};
    faint(SP_SUBSCRIPT, "wrong number of subscripts")
	if @dim != @sub;
    my $index = join(' ', @sub);
    while (@dim) {
	my $d = shift @dim;
	my $s = shift @sub;
	faint(SP_SUBSCRIPT, $s) if $s < 1 || $s > $d;
    }
    $regptr = $regptr->{value}{$index};
    if (exists $regptr->{value}) {
	return $regptr->{value};
    }
    return new Language::INTERCAL::Numbers 0, $type eq ';' ? 32 : 16;
}

sub _get_overload {
    my ($number, $regptr, @sub) = @_;
    exists $regptr->{overload} or faint(SP_NODIM, "/$number");
    faint(SP_ISARRAY, "/$number") unless @sub;
    faint(SP_SUBSCRIPT, "wrong number of subscripts")
	if 1 != @sub;
    my $dim = length($regptr->{overload});
    my $index = shift @sub;
    faint(SP_SUBSCRIPT, $index) if $index < 1 || $index > $dim;
    return new Language::INTERCAL::Numbers::Spot(
		    ord(substr($regptr->{overload}, $index - 1, 1)));
}

sub _overloaded_get {
    my ($object, $thread, $register, $regptr, $ip) = @_;
    my $code = $regptr->{overload};
    delete $regptr->{overload};
    my $value = $thread->{registers}{&IREG_OV}{value};
    if (exists $regptr->{value}) {
	$thread->{registers}{&IREG_OV}{value} = $regptr->{value};
    } else {
	delete $thread->{registers}{&IREG_OV}{value};
    }
    unshift @{$thread->{registers}{&IREG_OV}{owner}}, $register;
    my $lcp = 0;
    my $val;
    _trace($object, $$ip, $lcp, "[${$regptr->{value}}", 2);
    eval {
	$val = _expression($object, $thread, $code, $ip, \$lcp, 0);
	faint(SP_GARBAGE, "overload code") if $lcp < length($code);
    };
    _trace($object, $$ip, $lcp, ($val ? $$val : '?') . "]", 2);
    shift @{$thread->{registers}{&IREG_OV}{owner}};
    if (defined $value) {
	$thread->{registers}{&IREG_OV}{value} = $value;
    } else {
	delete $thread->{registers}{&IREG_OV}{value};
    }
    $regptr->{overload} = $code;
    die $@ if $@;
    $val;
}

sub _get_slice {
    my ($object, $thread, $register, $ip, $cp, $zero) = @_;
    my ($type, $number, @sub) = @$register;
    faint(SP_OVERLOAD, "_get_slice") if $type eq '\\';
    $number = $type . $number;
    $type eq '@' and faint(SP_ISCLASS, $number);
    my $dim = -1;
    $dim = @{$thread->{registers}{$number}{dimension}}
	if exists $thread->{registers}{$number} &&
	   exists $thread->{registers}{$number}{dimension} &&
	   @{$thread->{registers}{$number}{dimension}};
    my $isoverloaded = exists $thread->{registers}{$number} &&
		       exists $thread->{registers}{$number}{overload};
    if ($type =~ /^[.:%\/]/ || @sub == $dim || $isoverloaded) {
	return (_get($object, $thread, $register, $ip, $cp),
		$type eq ':' ? 32 : 16);
    }
    exists $thread->{registers}{$number}
	&& exists $thread->{registers}{$number}{dimension}
	    or faint(SP_NODIM, $number);
    my $regptr = $thread->{registers}{$number};
    my @dim = @{$regptr->{dimension}};
    faint(SP_SUBSCRIPT, "wrong number of subscripts")
	if @dim < @sub;
    my @index = @sub;
    while (@sub) {
	my $d = shift @dim;
	my $s = shift @sub;
	faint(SP_SUBSCRIPT, $s) if $s < 1 || $s > $d;
    }
    $regptr = $regptr->{value};
    @sub = (1) x @dim;
    $sub[-1] = 0;
    my @ret = ();
    my $mask = $type eq ';' ? 32 : 16;
    my $null = new Language::INTERCAL::Numbers 0, $mask;
    while (1) {
	my $idx = @sub;
	while ($idx-- > 0) {
	    $sub[$idx] ++;
	    last if $sub[$idx] <= $dim[$idx];
	    $sub[$idx] = 1;
	}
	last if $idx < 0;
	$idx = join(' ', @index, @sub);
	if (exists $regptr->{$idx}{value}) {
	    push @ret, $regptr->{$idx}{value}
		if $zero || ${$regptr->{$idx}{value}};
	} elsif ($zero) {
	    push @ret, $null;
	}
    }
    return (\@ret, $mask);
}

sub _filehandle {
    my ($object, $thread, $file, $ip, $cp, $mode, $isnum) = @_;
    if ($file->[0] eq '@') {
	my $number = '@' . $file->[1];
	if (exists $thread->{registers}{$number} &&
	    exists $thread->{registers}{$number}{file})
	{
	    return ($thread->{registers}{$number}{file}, -1);
	}
    }
    my $fname = _convert_read($object, $thread, $file, 0, $ip, $cp);
    return (0, $fname) if $isnum && $fname =~ /^\d+$/;
    my $fh = new Language::INTERCAL::GenericIO 'FILE', $mode, $fname;
    return ($fh, -1);
}

sub _read {
    my ($object, $thread, $register, $ip, $cp) = @_;
    if ($register->[0] eq '@') {
	my $number = '@' . $register->[1];
	faint(SP_IGNORANCE, $register->[1])
	    if ! exists $thread->{registers}{$number};
	my $class = $thread->{registers}{$number};
	# if the class is open for reading, use it
	if (exists $class->{file} && $class->{file}->can_read) {
	    $object->{read_fh} = $class->{file};
	    return;
	}
	faint(SP_CLASSIO, $register->[1], 'read')
	    if ! exists $class->{value}{2};
	# TODO (1.-90) - link read_fh to class
	faint(SP_TODO, 'reading out to lecture');
    }
    _do_read($object, $thread, $register, 1, $object->{read_fh}, $ip, $cp);
}

sub _convert_read {
    my ($object, $thread, $register, $roman, $ip, $cp) = @_;
    my $line = new Language::INTERCAL::GenericIO('STRING', 'r', \'');
    _do_read($object, $thread, $register, $roman, $line, $ip, $cp);
    ${$line->read_data()};
}

sub _do_read {
    my ($object, $thread, $register, $roman, $fh, $ip, $cp) = @_;
    _set_read_charset($object, $thread, 'read_fh');
    my ($value, $type) = _get_slice($object, $thread, $register, $ip, $cp, 0);
    if ('ARRAY' eq ref $value) {
	$value = [ map { $$_ } @$value ];
	my $iotype = ${$thread->{registers}{&IREG_IO}{value}};
	my $iovalue = ${$thread->{registers}{&IREG_AR}{value}};
	if ($type == 32) {
	    read_array_32($iotype, \$iovalue, $fh, $value, $roman);
	} else {
	    read_array_16($iotype, \$iovalue, $fh, $value, $roman);
	}
	$thread->{registers}{&IREG_AR}{value} =
	    new Language::INTERCAL::Numbers::Spot($iovalue);
    } else {
	$value = $$value;
	if ($roman) {
	    my $rt = ${$thread->{registers}{&IREG_RT}{value}};
	    read_number($value, $rt, $fh);
	} else {
	    $fh->read_text("$value\n");
	}
	return;
    }
}

sub read_fh {
    _set_fh('read_fh', IREG_ORFH, @_);
}

sub _write {
    my ($object, $thread, $register, $ip, $cp, $clone) = @_;
    if ($register->[0] eq '@') {
	my $number = '@' . $register->[1];
	faint(SP_IGNORANCE, $register->[1])
	    if ! exists $thread->{registers}{$number};
	my $class = $thread->{registers}{$number};
	# if the class is open for writing, use it
	if (exists $class->{file} && $class->{file}->can_write) {
	    $object->{write_fh} = $class->{file};
	    return;
	}
	faint(SP_CLASSIO, $register->[1], 'writ')
	    if ! exists $class->{value}{1};
	# TODO (1.-90) - link write_fh to class
	faint(SP_TODO, 'writing in from lecture');
    }
    _set_write_charset($object, $thread, 'write_fh');
    my ($type, $number, @subs) = @$register;
    my $fh = $object->{write_fh};
    my $isoverload = exists $thread->{registers}{$number} &&
		     exists $thread->{registers}{$number}{overload};
    if ($type =~ /^[.:%\/\\]/ || @subs || $isoverload) {
	my $value = new Language::INTERCAL::Numbers::Twospot(write_number($fh));
	_store($object, $thread, $value, $register, $ip, $cp, $clone);
	return;
    }
    $type eq '@' and faint(SP_ISCLASS, "$type$number");
    $number = $type . $number;
    exists $thread->{registers}{$number}
	&& exists $thread->{registers}{$number}{dimension}
	    or faint(SP_NODIM, $number);
    # enslave %OS to the register about to be modified
    $thread->{registers}{&IREG_OS}{owner} = [$number];
    my $arraysize = 1;
    my $mask = $type eq ';' ? 32 : 16;
    for my $mul (@{$thread->{registers}{$number}{dimension}}) {
	$arraysize *= $mul;
    }
    my $iotype = ${$thread->{registers}{&IREG_IO}{value}};
    my $iovalue = ${$thread->{registers}{&IREG_AW}{value}};
    my @values = ();
    if ($type eq ';') {
	@values = write_array_32($iotype, \$iovalue, $fh, $arraysize);
    } else {
	@values = write_array_16($iotype, \$iovalue, $fh, $arraysize);
    }
    $thread->{registers}{&IREG_AW}{value} =
	new Language::INTERCAL::Numbers::Spot($iovalue);
    faint(SP_NOSPACE, scalar(@values), $number, $arraysize)
	if @values > $arraysize;
    _separate_register($object, $thread, $clone, $number)
	if defined $clone && $clone;
    my $array = $thread->{registers}{$number};
    $object->_unflatten($thread, $register, $number,
			$mask, $array, $ip, @values)
	unless exists $array->{ignore};
}

sub _unflatten {
    my ($object, $thread, $register, $number, $mask, $array, $ip, @values) = @_;
    my @dims = @{$array->{dimension}};
    return if @dims == 0;
    my @subscript = (1) x @dims;
    $subscript[-1] = 0;
    my @ret = ();
    delete $array->{is_default};
    $array = $array->{value};
    while (1) {
	my $idx = @subscript;
	while ($idx-- > 0) {
	    $subscript[$idx] ++;
	    last if $subscript[$idx] <= $dims[$idx];
	    $subscript[$idx] = 1;
	}
	last if $idx < 0;
	my $index = join(' ', @subscript);
	$array->{$index}{value} =
	    new Language::INTERCAL::Numbers(@values ? shift(@values) : 0,
						    $mask);
    }
}

sub write_fh {
    _set_fh('write_fh', IREG_OWFH, @_);
}

sub rs_fh {
    _set_fh('rs_fh', IREG_RSFH, @_);
}

sub _separate_register {
    my ($object, $thread, $clone, $reg) = @_;
    return if $thread->{registers}{$reg} != $clone->{registers}{$reg};
    $clone->{registers}{$reg} = _copy($clone->{registers}{$reg});
    for (my $i = 0; $i < @{$thread->{stash}}; $i++) {
	next if ! exists $thread->{stash}[$i]{$reg};
	$clone->{stash}[$i]{$reg} = _copy($thread->{stash}[$i]{$reg});
    }
}

sub _separate_grammar {
    my ($object, $thread, $clone, $gram) = @_;
    return if $gram >= @{$thread->{grammar}} ||
	      $thread->{grammar}[$gram] != $clone->{grammar}[$gram];
    $clone->{grammar}[$gram] = $clone->{grammar}[$gram]->copy(1);
    $clone->{statements} = _copy($clone->{statements});
    $clone->{compile} = _copy($clone->{compile});
}

sub _stash {
    my ($object, $thread, $stash, $register, $clone) = @_;
    my ($type, $number) = @$register;
    faint(SP_OVERLOAD, "stash") if $type eq '/' || $type eq '\\';
    $number = $type . $number;
    $stash = $$stash;
    $stash >= @{$thread->{stash}} and faint(SP_SPOT, "Stash", $number);
    my $stashptr = $thread->{stash}[$stash];
    _create_register($object, $number)
	if ! exists $thread->{registers}{$number};
    _separate_register($object, $thread, $clone, $number)
	if defined $clone && $clone;
    _create_stash($object, $thread->{registers}{$number}, $stash, $number)
	if ! exists $stashptr->{$number};
    unshift @{$stashptr->{$number}}, _copy($thread->{registers}{$number});
    $object;
}

sub _copy {
    my ($src) = @_;
    ref $src or return $src;
    'ARRAY' eq ref $src and return [map {_copy($_)} @$src];
    'HASH' eq ref $src and return {map {($_ => _copy($src->{$_}))} keys %$src};
    'SCALAR' eq ref $src and do { my $s = $$src; return \$s };
    UNIVERSAL::isa($src, 'Language::INTERCAL::Numbers') and return $src->copy;
    $src;
}

sub _retrieve {
    my ($object, $thread, $stash, $register, $size, $assign, $ip, $cp, $clone)
	= @_;
    my ($type, $number) = @$register;
    faint(SP_OVERLOAD, "retrieve") if $type eq '/' || $type eq '\\';
    $number = $type . $number;
    $stash = $$stash;
    $stash >= @{$thread->{stash}} and faint(SP_SPOT, "Stash", $number);
    $stash = $thread->{stash}[$stash];
    $size > 0 or faint(SP_FORGET);
    _create_register($object, $number)
	if ! exists $thread->{registers}{$number};
    exists $stash->{$number} && @{$stash->{$number}} >= $size
	or faint(SP_HIDDEN, $number);
    _separate_register($object, $thread, $clone, $number)
	if defined $clone && $clone;
    if ($assign) {
	# enslave %OS to the register about to be modified
	$thread->{registers}{&IREG_OS}{owner} = [$number];
	splice(@{$stash->{$number}}, 0, $size - 1) if $size > 1;
	$thread->{registers}{$number} = shift @{$stash->{$number}};
	if ($number eq IREG_IP) {
	    $$ip = ${$thread->{registers}{$number}{value}};
	} elsif ($number eq IREG_CP) {
	    $$cp = ${$thread->{registers}{$number}{value}};
	}
    } else {
	splice(@{$stash->{$number}}, 0, $size);
    }
}

sub _enslave {
    my ($object, $thread, $slave, $owner, $clone) = @_;
    my ($slave_type, $slave_number) = @$slave;
    faint(SP_OVERLOAD, "enslave")
	if $slave_type eq '/' || $slave_type eq '\\';
    $slave_number = $slave_type . $slave_number;
    my ($owner_type, $owner_number) = @$owner;
    faint(SP_OVERLOAD, "enslave")
	if $owner_type eq '/' || $owner_type eq '\\';
    $owner_number = $owner_type . $owner_number;
    _create_register($object, $slave_number)
	if ! exists $thread->{registers}{$slave_number};
    _separate_register($object, $thread, $clone, $slave_number)
	if defined $clone && $clone;
    unshift @{$thread->{registers}{$slave_number}{owner}}, $owner;
}

sub _owner {
    my ($object, $thread, $slave, $owner) = @_;
    my ($slave_type, $slave_number) = @$slave;
    faint(SP_OVERLOAD, "get owner of")
	if $slave_type eq '/' || $slave_type eq '\\';
    $slave_number = $slave_type . $slave_number;
    $slave_number = IREG_OV if $slave_number eq '@0';
    faint(SP_FREE, $slave_number)
	if ! exists $thread->{registers}{$slave_number}
	|| ! exists $thread->{registers}{$slave_number}{owner};
    $owner = $$owner;
    faint(SP_OWNER, $owner) if $owner < 0 || $owner > 0xffff;
    my $num = @{$thread->{registers}{$slave_number}{owner}};
    faint(SP_NOOWNER, $slave_number, $owner, $num) if $owner > $num;
    return $thread->{registers}{$slave_number}{owner}[$owner - 1];
}

sub _free {
    my ($object, $thread, $slave, $owner, $clone) = @_;
    my ($slave_type, $slave_number) = @$slave;
    faint(SP_OVERLOAD, "free")
	if $slave_type eq '/' || $slave_type eq '\\';
    $slave_number = $slave_type . $slave_number;
    my ($owner_type, $owner_number) = @$owner;
    faint(SP_OVERLOAD, "free")
	if $owner_type eq '/' || $owner_type eq '\\';
    $owner_number = $owner_type . $owner_number;
    faint(SP_FREE, $slave_number)
	if ! exists $thread->{registers}{$slave_number}
	|| ! exists $thread->{registers}{$slave_number}{owner};
    _separate_register($object, $thread, $clone, $slave_number)
	if defined $clone && $clone;
    my $o = $thread->{registers}{$slave_number}{owner};
    for (my $i = 0; $i < @$o; $i++) {
	next if $o->[$i][0] ne $owner_type;
	next if $o->[$i][1] ne $owner->[1];
	splice(@$o, $i, 1);
	delete $thread->{registers}{$slave_number}{owner} if @$o == 0;
	return $object;
    }
    faint(SP_NOBELONG, $slave_number, $owner_number);
}

sub _share {
    my ($object, $thread, $map, $lreg, $rreg) = @_;
    my ($ltype, $lnumber) = @$lreg;
    my ($rtype, $rnumber) = @$rreg;
    faint(SP_CONFUSION, $ltype, $rtype) if $ltype ne $rtype;
    faint(SP_OVERLOAD, "share") if $ltype eq '/' || $ltype eq '\\';
    $lnumber = $ltype . $lnumber;
    _create_register{$object, $lnumber}
	if ! exists $thread->{registers}{$lnumber};
    $rnumber = $rtype . $rnumber;
    $map->{$rnumber} = $thread->{registers}{$lnumber};
}

sub _create_register {
    my ($object, $register) = @_;
    faint(SP_SPECIAL, $register) if $register !~ /^[.:,;\@]/;
    my %register = (is_default => 1);
    $register{dimension} = [65535] if $register =~ /^\@/;
    for my $thread (@{$object->{threads}}) {
	$thread->{registers}{$register} = \%register;
    }
}

sub _create_stash {
    my ($object, $regptr, $stash, $register) = @_;
    my @stash = ();
    for my $thread (@{$object->{threads}}) {
	$thread->{stash}[$stash]{$register} = \@stash
	    if $regptr == $thread->{registers}{$register};
    }
}

sub read_object {
    @_ == 2 or croak "Usage: OBJECT->read_object(FILEHANDLE)";
    my ($object, $fh) = @_;
    my $saversfh = $object->{rs_fh};
    $object->{rs_fh} = $devnull;

##print STDERR "Reading object\n";

    # this used to use Data::Dumper, but this format is more portable across
    # languages (if less human readable)
    my ($perversion) = $PERVERSION =~ /(\S+)$/;
    $fh->read_text("CLC-INTERCAL $perversion Object File\n");
    $fh->read_text("TO MODIFY, EDIT SOURCE AND REPACKAGE\n");
##print STDERR "Size after headers: ", &{$fh->{tell_code}}, "\n";

    my $h = $object->{assign};
    my @k = keys %$h;
    $fh->read_binary(pack('v', scalar(@k)));
    for my $k (@k) {
	my $v = $h->{$k}->pack;
	my $vlen = (length($k) > 2 ? 1 : 0) | (length($v) > 2 ? 2 : 0);
	$fh->read_binary(pack('vCa*', $k, $vlen, $v));
    }
##print STDERR "Size after assign: ", &{$fh->{tell_code}}, "\n";

    my $k = $object->{file};
    $fh->read_binary(pack('v', scalar(@$k)));
    for my $f (@$k) {
	$fh->read_binary(pack('va*va*', length($f->[0]), $f->[0],
					length($f->[1]), $f->[1]));
    }
##print STDERR "Size after files: ", &{$fh->{tell_code}}, "\n";

    $fh->read_binary(pack('V', $object->{abstime}));
    # find all abstain
    my %abstainptr = ();
    for my $thread (@{$object->{threads}}) {
	for my $sp (values %{$thread->{abstain}}) {
	    $abstainptr{$sp} = $sp;
	}
    }

    # read out all these separate abstain
    @k = keys %abstainptr;
    $fh->read_binary(pack('v', scalar(@k)));
    for (my $s = 0; $s < @k; $s++) {
	$fh->read_binary(pack('CV', @{$abstainptr{$k[$s]}}));
	$abstainptr{$k[$s]} = $s;
    }
##print STDERR "Size after abstain: ", &{$fh->{tell_code}}, "\n";

    # find all the unique arrays of statements...
    my %listptr = ();
    for my $p ($object, @{$object->{threads}}) {
	my $s = $p->{statements};
	$listptr{$s} = $s;
    }

    # read out all these statements
    @k = keys %listptr;
    $fh->read_binary(pack('v', scalar(@k)));
    for (my $s = 0; $s < @k; $s++) {
	my $p = $listptr{$k[$s]};
	$listptr{$k[$s]} = $s;
	$fh->read_binary(pack('v', scalar(@$p) - 1));
	for (my $pp = 1; $pp < @$p; $pp++) {
	    my @s = @{$p->[$pp]}[0..4];
	    my $code = $s[3];
	    $s[3] = length($code);
	    $fh->read_binary(pack('v5a*', @s, $code));
	}
    }
    my $sptr = $listptr{$object->{statements}};
    $fh->read_binary(pack('vv', $sptr, $object->{codesize}));
##print STDERR "Size after statements: ", &{$fh->{tell_code}}, "\n";

    # now find out all the unique stashes and registers...
    my %ptr = ();
    for my $thread (@{$object->{threads}}) {
	for my $reg (values %{$thread->{registers}}) {
	    $ptr{$reg} = $reg;
	}
	for my $stash (@{$thread->{stash}}) {
	    for my $regst (values %$stash) {
		for my $reg (@$regst) {
		    $ptr{$reg} = $reg;
		}
	    }
	}
    }

    # read out all the distinct values
    @k = keys %ptr;
    $fh->read_binary(pack('v', scalar(@k)));
    my @fhlist = (0, $stdread, $stdwrite, $stdsplat, $devnull);
    my %fhptr = map { ($fhlist[$_] => $_) } (0..@fhlist-1);
    my $fhignore = @fhlist;
    for (my $cnt = 0; $cnt < @k; $cnt++) {
	my $reg = $k[$cnt];
	_read_register($fh, $ptr{$reg}, \@fhlist, \%fhptr);
	$ptr{$reg} = $cnt;
    }
##print STDERR "Size after regptr: ", &{$fh->{tell_code}}, "\n";

    for my $fhname (qw(read_fh write_fh splat_fh trace_fh rs_fh)) {
	my $savefh = $object->{$fhname};
	$savefh = 0 if ! ref $savefh;
	if (! exists $fhptr{$savefh}) {
	    my $fhnum = @fhlist;
	    $fhlist[$fhnum] = $savefh;
	    $fhptr{$savefh} = $fhnum;
	}
	$fh->read_binary(pack('v', $fhptr{$savefh}));
    }

    splice(@fhlist, 0, $fhignore);
    $fh->read_binary(pack('v', scalar(@fhlist)));
    for my $savefh (@fhlist) {
	$fh->read_filehandle($savefh);
    }
##print STDERR "Size after filehandles: ", &{$fh->{tell_code}}, "\n";

    # now go through the threads and read out pointers
    $fh->read_binary(pack('v', scalar(@{$object->{threads}[0]{stash}})));
    $fh->read_binary(pack('v', scalar(@{$object->{threads}})));
    for my $thread (@{$object->{threads}}) {
	my $s = $thread->{statements};
	my $sptr = $listptr{$s};
	$fh->read_binary(pack('v', $sptr));
	$s = $thread->{abstain};
	@k = keys %$s;
	$fh->read_binary(pack('v', scalar(@k)));
	for my $abs (@k) {
	    my $name = substr($abs, 0, 1);
	    my $num = substr($abs, 1);
	    $fh->read_binary(pack('Cvv', $name, $num, $abstainptr{$s->{$abs}}));
	}
	my $t = $thread->{registers};
	@k = keys %$t;
	$fh->read_binary(pack('v', scalar(@k)));
	for my $reg (@k) {
	    my $rptr = $ptr{$t->{$reg}};
	    $fh->read_binary(pack('Ca*v', length($reg), $reg, $rptr));
	}
	for my $t (@{$thread->{stash}}) {
	    @k = keys %$t;
	    $fh->read_binary(pack('v', scalar(@k)));
	    for my $reg (@k) {
		my $st = $t->{$reg};
		$fh->read_binary(pack('Ca*v', length($reg), $reg, scalar @$st));
		for my $se (@$st) {
		    $fh->read_binary(pack('v', $t->{$se}));
		}
	    }
	}
    }
##print STDERR "Size after threads: ", &{$fh->{tell_code}}, "\n";

    # find all the unique "compile" pointers
    my %cptr = ();
    for my $thread (@{$object->{threads}}) {
	my $compile = $thread->{compile};
	$cptr{$compile} = $compile;
    }

    # read out all the distinct values
    @k = keys %cptr;
    $fh->read_binary(pack('v', scalar(@k)));
    for (my $cnt = 0; $cnt < @k; $cnt++) {
	my $com = $k[$cnt];
	my $rptr = $cptr{$com};
	$fh->read_binary(pack("v", $$rptr));
	$cptr{$com} = $cnt;
    }
##print STDERR "Size after comptr: ", &{$fh->{tell_code}}, "\n";

    # read the compile value for each thread
    for my $thread (@{$object->{threads}}) {
	$fh->read_binary(pack("v", $cptr{$thread->{compile}}));
	$fh->read_binary(pack("v", $thread->{running}));
    }
##print STDERR "Size after compile: ", &{$fh->{tell_code}}, "\n";

    # now read the loop/event arrays
    for my $thread (@{$object->{threads}}) {
	$fh->read_binary(pack("v", scalar(@{$thread->{loops}})));
	for my $loop (@{$thread->{loops}}) {
	    my ($body, $cond) = @$loop;
	    $fh->read_binary(pack("va*v", length($body), $body,
					  scalar(@$cond)));
	    for my $c (@$cond) {
		$fh->read_binary(pack("va*", length($c), $c));
	    }
	}
    }
##print STDERR "Size after loops: ", &{$fh->{tell_code}}, "\n";

    @k = keys %{$object->{modules}};
    $fh->read_binary(pack('v', scalar @k));
    for my $k (@k) {
	$fh->read_binary(pack('v', $k));
	$object->{modules}{$k}->read_object($fh);
    }
##print STDERR "Size after modules: ", &{$fh->{tell_code}}, "\n";

    # read grammars out
    my $includesymbols = 1;
    $fh->read_binary(pack('v', scalar @{$object->{threads}[0]{grammar}}));
    for my $thread (@{$object->{threads}}) {
	for my $g (@{$thread->{grammar}}) {
	    $g->read_grammar($fh, $includesymbols);
	    $includesymbols = 0;
	}
    }
##print STDERR "Size after grammars: ", &{$fh->{tell_code}}, "\n";

    $object->{optimiser}->read_optimiser($fh);
##print STDERR "Size after optimiser: ", &{$fh->{tell_code}}, "\n";

    $object->{rs_fh} = $saversfh;
    $object;
}

sub _read_register {
    my ($fh, $r, $fhlist, $fhptr) = @_;
    my $flags = 0;
    $flags |= HAS_IGNORE    if exists $r->{ignore};
    $flags |= HAS_VALUE     if exists $r->{value};
    $flags |= HAS_DIMENSION if exists $r->{dimension};
    $flags |= HAS_OVERLOAD  if exists $r->{overload};
    $flags |= HAS_ENROL     if exists $r->{enrol};
    $flags |= HAS_HANDLE    if exists $r->{file} && ref $r->{file};
    $flags |= HAS_DEFAULT   if exists $r->{is_default};
    $fh->read_binary(pack('C', $flags));
    if ($flags & HAS_VALUE) {
	if ('HASH' eq ref $r->{value}) {
	    my @k = keys %{$r->{value}};
	    $fh->read_binary(pack('Cv', 0, scalar(@k)));
	    for my $k (@k) {
		my @s = split(/\s+/, $k);
		$fh->read_binary(pack('v*', scalar(@s), @s));
		_read_register($fh, $r->{value}{$k}, $fhlist, $fhptr);
	    }
	} else {
	    my $v = $r->{value}->pack;
	    $fh->read_binary(pack('Ca*', length($v), $v));
	}
    }
    if ($flags & HAS_DIMENSION) {
	my $d = $r->{dimension};
	$fh->read_binary(pack('v*', scalar(@$d), @$d));
    }
    if ($flags & HAS_OVERLOAD) {
	my $d = $r->{overload};
	$fh->read_binary(pack('va*', length($d), $d));
    }
    if ($flags & HAS_ENROL) {
	my @d = keys %{$r->{enrol}};
	$fh->read_binary(pack('v*', scalar(@d), @d));
    }
    if ($flags & HAS_HANDLE) {
	my $savefh = $r->{file};
	if (! exists $fhptr->{$savefh}) {
	    my $fhnum = @$fhlist;
	    $fhlist->[$fhnum] = $savefh;
	    $fhptr->{$savefh} = $fhnum;
	}
	$fh->read_binary(pack('v', $fhptr->{$savefh}));
    }
}

sub string2reg {
    @_ == 2 or croak "Usage: OBJECT->string2reg(DATA)";
    my ($object, $data) = @_;
    my @data = unpack('C*', $data);
    my $len = @data;
    my %data =
	map { ($_ =>
		{ value =>
		    new Language::INTERCAL::Numbers::Spot($data[$_ - 1]) }) }
	    (1..$len);
    my %reg = (
	dimension => [$len],
	value => \%data,
    );
    \%reg;
}

sub int2reg {
    @_ == 2 or croak "Usage: OBJECT->int2reg(DATA)";
    my ($object, $data) = @_;
    my %reg = (
	value => new Language::INTERCAL::Numbers::Spot($data),
    );
    \%reg;
}

sub write_object {
    @_ == 2 or croak
	"Usage: write_object Language::INTERCAL::Object(FILEHANDLE)";
##print  STDERR "Writing object\n";
    my ($class, $fh) = @_;
    my $object = bless {}, $class;
    my $line = $fh->write_text();
    $line =~ /^CLC-INTERCAL (\S+) Object File\n$/
	or croak("Invalid Object Format ($line)");
    my $perversion = $1;
    is_intercal_number($perversion)
	or croak("Invalid Object Perversion ($perversion)");
    require_version Language::INTERCAL::Object $perversion;
    $line = $fh->write_text();

##print STDERR "Size after headers: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";
    $object->{assign} = {};
    my $keys = unpack('v', $fh->write_binary(2));
    while ($keys-- > 0) {
	my ($k, $vlen) = unpack('vC', $fh->write_binary(3));
	my $v = Language::INTERCAL::Numbers->unpack($fh->write_binary($vlen));
	$object->{assign}{$k} = $v;
    }
##print STDERR "Size after assign: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    $object->{file} = [];
    $keys = unpack('v', $fh->write_binary(2));
    for (my $fn = 0; $fn < $keys; $fn++) {
	my $l = unpack('v', $fh->write_binary(2));
	my $v = $fh->write_binary($l);
	$l = unpack('v', $fh->write_binary(2));
	my $t = $fh->write_binary($l);
	push @{$object->{file}}, [$v, $t];
    }
##print STDERR "Size after files: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    $object->{abstime} = unpack('V', $fh->write_binary(4));
    my @abstainptr = ();
    my $abstainptr = unpack('v', $fh->write_binary(2));
    while ($abstainptr-- > 0) {
	my ($abstain, $time) = unpack('CV', $fh->write_binary(5));
	push @abstainptr, [$abstain, $time];
    }
##print STDERR "Size after abstain: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    my @stams = ();
    my $stams = unpack('v', $fh->write_binary(2));
    while ($stams-- > 0) {
	my @thisstam = ([-1, (0) x 11]);
	$keys = unpack('v', $fh->write_binary(2));
	while ($keys-- > 0) {
	    my @s = unpack('v5', $fh->write_binary(10));
	    $s[0] -= 65536 if $s[0] > 65533;
	    $s[3] = $fh->write_binary($s[3]);
	    push @s, _opcode($s[3]);
	    push @s, 0; # we are not saving parse trees just now
	    push @thisstam, \@s;
	}
	push @stams, \@thisstam;
    }
    my $stamptr = unpack('v', $fh->write_binary(2));
    $object->{statements} = $stams[$stamptr];
    $object->{codesize} = unpack('v', $fh->write_binary(2));
##print STDERR "Size after statements: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    my @regs = ();
    my @setfile = ();
    $keys = unpack('v', $fh->write_binary(2));
    while ($keys-- > 0) {
	push @regs, _write_register($fh, \@setfile);
    }
##print STDERR "Size after regptr: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    my @sethandle = ();
    for my $fhname (qw(read_fh write_fh splat_fh trace_fh rs_fh)) {
	push @sethandle, [$fhname, unpack('v', $fh->write_binary(2))];
    }

    my @fhlist = (0, $stdread, $stdwrite, $stdsplat, $devnull);
    $keys = unpack('v', $fh->write_binary(2));
    while ($keys-- > 0) {
	push @fhlist, $fh->write_filehandle();
    }
    for my $fhptr (@setfile) {
	$fhptr->[0]{file} = $fhlist[$fhptr->[1]];
    }
    for my $fhptr (@sethandle) {
	$object->{$fhptr->[0]} = $fhlist[$fhptr->[1]];
    }
##print STDERR "Size after filehandle: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    $object->{threads} = [];
    my $stashes = unpack('v', $fh->write_binary(2));
    $keys = unpack('v', $fh->write_binary(2));
    while ($keys-- > 0) {
	my %t = ();
	my $stamptr = unpack('v', $fh->write_binary(2));
	$t{statements} = $stams[$stamptr];
	my $abstain = unpack('v', $fh->write_binary(2));
	my %abstain = ();
	while ($abstain-- > 0) {
	    my ($type, $num, $val) = unpack('Cvv', $fh->write_binary(5));
	    $abstain{$type . $num} = $abstainptr[$val];
	}
	$t{abstain} = \%abstain;
	$t{registers} = {};
	my $names = unpack('v', $fh->write_binary(2));
	while ($names-- > 0) {
	    my $namelen = unpack('C', $fh->write_binary(1));
	    my $name = $fh->write_binary($namelen);
	    my $ptr = unpack('v', $fh->write_binary(2));
	    $t{registers}{$name} = $regs[$ptr];
	}
	$t{stash} = [];
	for (my $s = 0; $s < $stashes; $s++) {
	    my %s = ();
	    my $names = unpack('v', $fh->write_binary(2));
	    while ($names-- > 0) {
		my $namelen = unpack('C', $fh->write_binary(1));
		my $name = $fh->write_binary($namelen);
		my $depth = unpack('v', $fh->write_binary(2));
		my @stash = ();
		while ($depth-- > 0) {
		    my $ptr = unpack('v', $fh->write_binary(2));
		    push @stash, $regs[$ptr];
		}
		$s{$name} = \@stash;
	    }
	    push @{$t{stash}}, \%s;
	}
	push @{$object->{threads}}, \%t;
    }
##print STDERR "Size after threads: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    my @cptr = ();
    $keys = unpack('v', $fh->write_binary(2));
    while ($keys-- > 0) {
	my $val = unpack('v', $fh->write_binary(2));
	push @cptr, \$val;
    }
##print STDERR "Size after comptr: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    for my $thread (@{$object->{threads}}) {
	$thread->{compile} = $cptr[unpack('v', $fh->write_binary(2))];
	$thread->{running} = unpack('v', $fh->write_binary(2));
    }
##print STDERR "Size after compile: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    # now write the loop/event arrays
    for my $thread (@{$object->{threads}}) {
	my $loops = unpack('v', $fh->write_binary(2));
	my @loops = ();
	while ($loops-- > 0) {
	    my $len = unpack('v', $fh->write_binary(2));
	    my $body = $fh->write_binary($len);
	    my $conds = unpack('v', $fh->write_binary(2));
	    my @conds = ();
	    while ($conds-- > 0) {
		$len = unpack('v', $fh->write_binary(2));
		push @conds, $fh->write_binary($len);
	    }
	    push @loops, [$body, \@conds];
	}
	$thread->{loops} = \@loops;
    }
##print STDERR "Size after loops: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    my %mods = ();
    $keys = unpack('v', $fh->write_binary(2));
    while ($keys-- > 0) {
	my $mnum = unpack('v', $fh->write_binary(2));
	$mods{$mnum} = write_object Language::INTERCAL::Object($fh);
    }
    $object->{modules} = \%mods;
##print STDERR "Size after modules: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    # write grammars in
    my $usesymbols = undef;
    my $grammars = unpack('v', $fh->write_binary(2));
    for my $thread (@{$object->{threads}}) {
	$thread->{grammar} = [];
	my $g = $grammars;
	while ($g-- > 0) {
	    $usesymbols =
		Language::INTERCAL::Parser->write_grammar($fh, $usesymbols);
	    push @{$thread->{grammar}}, $usesymbols;
	}
    }
##print STDERR "Size after grammars: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    $object->{optimiser} = Language::INTERCAL::Optimiser->write_optimiser($fh);
##print STDERR "Size after optimiser: ",  &{$fh->{tell_code}}, "-", length($fh->{buffer}), " = ",&{$fh->{tell_code}} - length($fh->{buffer}), "\n";

    $object;
}

sub _write_register {
    my ($fh, $setfile) = @_;
    my %reg = ();
    my $flags = unpack('C', $fh->write_binary(1));
    $reg{ignore} = 0 if $flags & HAS_IGNORE;
    if ($flags & HAS_VALUE) {
	my $type = unpack('C', $fh->write_binary(1));
	if ($type) {
	    $reg{value} =
	    Language::INTERCAL::Numbers->unpack($fh->write_binary($type));
	} else {
	    $reg{value} = {};
	    my $keys = unpack('v', $fh->write_binary(2));
	    while ($keys-- > 0) {
		my $dim = unpack('v', $fh->write_binary(2));
		my @val = ();
		while ($dim-- > 0) {
		    push @val, unpack('v', $fh->write_binary(2));
		}
		my $idx = join(' ', @val);
		$reg{value}{$idx} = _write_register($fh, $setfile);
	    }
	}
    }
    if ($flags & HAS_DIMENSION) {
	my $dim = unpack('v', $fh->write_binary(2));
	my @val = unpack('v*', $fh->write_binary(2 * $dim));
	$reg{dimension} = \@val;
    }
    if ($flags & HAS_OVERLOAD) {
	my $len = unpack('v', $fh->write_binary(2));
	$reg{overload} = $fh->write_binary($len);
    }
    if ($flags & HAS_ENROL) {
	my $dim = unpack('v', $fh->write_binary(2));
	my @val = unpack('v*', $fh->write_binary(2 * $dim));
	my %val = map { ($_ => 1) } @val;
	$reg{enrol} = \%val;
    }
    if ($flags & HAS_HANDLE) {
	push @$setfile, [\%reg, unpack('v', $fh->write_binary(2))];
    }
    if ($flags & HAS_DEFAULT) {
	$reg{is_default} = 1;
    }
    \%reg;
}

sub reg2string {
    @_ == 2 or croak "Usage: OBJECT->reg2string(DATA)";
    my ($object, $reg) = @_;
    my $i = 0;
    my $c = 0;
    my $thread = { registers => {',1' => $reg} };
    my ($slice, $mask) =
	_get_slice({}, $thread, [',', 1], \$i, \$c, 0);
    return ${$slice} unless 'ARRAY' eq ref $slice;
    return pack('C*', map { $$_ } @$slice);
}

sub reg2int {
    @_ == 2 or croak "Usage: OBJECT->reg2int(DATA)";
    my ($object, $reg) = @_;
    my $i = 0;
    my $c = 0;
    my $thread = { registers => {'.1' => $reg} };
    my $value = _get({}, $thread, ['.', 1], \$i, \$c);
    return $$value;
}

sub _get_grammar_left {
    my ($object, $thread, $code, $ip, $cp, $hascount) = @_;
    my $count = ${_expression($object, $thread, $code, $ip, $cp, 0)};
    my @left = ();
    while ($count-- > 0) {
	my $cc = $hascount
	       ? ${_expression($object, $thread, $code, $ip, $cp, 0)}
	       : 0;
	my $t = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	$t = $t & 0x07;
	if ($t == 0) {
	    my $s = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	    $s = 1 if $s < 1;
	    push @left, ['s', $s, $cc];
	} elsif ($t < 0x04 || $t == 0x07) {
	    my $d = _expression($object, $thread, $code, $ip, $cp, 1);
	    $d = [$d] unless 'ARRAY' eq ref $d;
	    # need to transform the data into a string
	    my $th = {map {($_ => $thread->{registers}{$_})}
			  (IREG_CR, IREG_IO, IREG_AR)};
	    $th = {registers => $th};
	    my $r = [$t == 0x01 || $t == 0x03 ? ',' : ';', 1];
	    my $i = 0;
	    my $p = 0;
	    my $obc = $object->{trace_fh};
	    $object->{trace_fh} = 0;
	    _create_array($object, $th, $r, $d, \$i, \$p, undef);
	    # now get a string out of it
	    $d = uc(_convert_read($object, $th, $r, 0, \$i, \$p));
	    $object->{trace_fh} = $obc;
	    if ($t == 0x01 || $t == 0x02) {
		push @left, ['c', $d, $cc];
	    } else {
		push @left, ['r', $d, $cc];
	    }
	} else {
	    faint(SP_CREATION);
	}
    }
    \@left;
}

sub _get_grammar_right {
    my ($object, $thread, $code, $ip, $cp) = @_;
    my $count = ${_expression($object, $thread, $code, $ip, $cp, 0)};
    my @right = ();
    while ($count-- > 0) {
	my $t = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	$t = $t & 0x0f;
	if ($t == 0x04) {
	    my $d = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	    if ($$cp + $d > length($code)) {
		faint(SP_INVALID, "???? _expression");
	    }
	    my $v = substr($code, $$cp, $d);
	    _trace($object, $$ip, $$cp, '<', 2);
#__TRACE_START__
	    for (my $i = 0; $i < $d; $i++) {
		_trace($object, $$ip, $$cp + $i,
		       ord(substr($code, $$cp + $i, 1)), 0);
	    }
#__TRACE_END__
	    $$cp += $d;
	    _trace($object, $$ip, $$cp, '>', 2);
	    push @right, ['b', $v];
	} elsif ($t == 0x08) {
	    my $d = _expression($object, $thread, $code, $ip, $cp, 1);
	    my @d = map { $$_ & BC_MASK } 'ARRAY' eq ref $d ? @$d : $d;
	    push @right, ['b', pack('C*', @d)];
	} elsif ($t == 0x05) {
	    my $inner = _get_grammar_right($object, $thread, $code, $ip, $cp);
	    push @right, ['m', $inner];
	} elsif ($t == 0x00 || $t == 0x06) {
	    my $n = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	    my $s = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	    $s = 1 if $s < 1;
	    $t = $t eq 0x00 ? 's' : 'n';
	    push @right, [$t, $n, $s];
	} else {
	    my $n = ${_expression($object, $thread, $code, $ip, $cp, 0)};
	    my $d = _expression($object, $thread, $code, $ip, $cp, 1);
	    $d = [$d] unless 'ARRAY' eq ref $d;
	    # need to transform the data into a string
	    my $th = {map {($_ => $thread->{registers}{$_})}
			  (IREG_CR, IREG_IO, IREG_AR)};
	    $th = {registers => $th};
	    my $r = [$t == 0x01 || $t == 0x03 ? ',' : ';', 1];
	    my $i = 0;
	    my $p = 0;
	    my $obc = $object->{trace_fh};
	    $object->{trace_fh} = 0;
	    _create_array($object, $th, $r, $d, \$i, \$p, undef);
	    # now get a string out of it
	    $d = uc(_convert_read($object, $th, $r, 0, \$i, \$p));
	    $object->{trace_fh} = $obc;
	    $t = $t == 0x01 || $t == 0x02 ? 'c' : 'r';
	    push @right, [$t, $n, $d];
	}
    }
    \@right;
}

sub _revalidate {
    my ($object, $thread, $tsp, $ip) = @_;
    # check if we do really need to recompile!
    my $tree = $tsp->[$ip][12];
    my $gr = ${$thread->{registers}{&IREG_GR}{value}};
    $gr = $thread->{grammar}[$gr];
    if ($tree && $tree->validate($gr)) {
	# validates modifies the parse tree if the grammar has changed,
	# but we still need to update the "compile" counter
	$tsp->[$ip][4] = ${$thread->{compile}};
	return;
    }
    # we do need to recompile - compile this statement
    my ($removed, @removed) = splice(@$tsp, $ip);
    _compile($object, $thread, $ip, 1);
    # can we add these @removed ones again?
    my $last = $tsp->[-1];
    for (my $n = 0; $n < 3; $n++) {
	return if $removed->[$n] != $last->[$n];
    }
    push @$tsp, @removed;
}

sub _compile {
    my ($object, $thread, $st, $splats) = @_;
    my $fileno = 0;
    my $codepos = 0;
    # try to locate the source code to compile
##print STDERR "_compile(st=$st)\n";
    if ($st >= 2) {
	$fileno = $thread->{statements}[$st - 1][0];
	if ($fileno < 0) {
	    $fileno = 0;
	} else {
	    my $fp = $object->{file};
	    $codepos = $thread->{statements}[$st - 1][2];
	    while ($fileno < @$fp && $codepos >= length($fp->[$fileno][1])) {
		$fileno++;
		$codepos = 0;
	    }
	}
    }
    # Is there any source code to compile anyway?
    if ($fileno >= @{$object->{file}}) {
	# nope, return *633, FALLING OFF THE EDGE OF THE PROGRAM
	return 1 unless $splats;
	my $code = pack('C*', BC_CAR, BC_0, BREG_SV,
			      BC_COM, BC(SP_FALL_OFF), BREG_SV);
	_code($code, -2, 0, 0, 0, 0, $thread);
	return 1;
    }
    # Try to compile this source code
    my $grammar = ${$thread->{registers}{&IREG_GR}{value}};
    my $symbol = ${$thread->{registers}{&IREG_IS}{value}};
    my $source = $object->{file}[$fileno][1];
##print STDERR "_compile(grammar=$grammar symbol=$symbol pos=[$fileno, $codepos] text=", do { my $x = substr($source, $codepos, 50); $x =~ s/\s+/ /g; $x =~ s/^ //; $x =~ s/ $//; $x }, ")\n";
    my ($code, $endpos, $tree) =
	_generate_comment($object, $thread, $grammar, $symbol,
			  $source, $codepos, 0);
##print STDERR "_compile(codelen=", length($code), " endpos=$endpos)\n";
    $code = $object->{optimiser}->optimise($code);
    my $bug = ${$thread->{registers}{&IREG_CB}{value}};
    my $ubug = ${$thread->{registers}{&IREG_CU}{value}};
    if ($bug || $ubug) {
	my $spin = rand(65535);
	if (($bug || $ubug) > $spin) {
	    $code .= pack('C*', BC_BUG, BC($bug ? 1 : 0));
	}
    }
    _code($code, $fileno, $codepos, $endpos, $tree,
	  ${$thread->{compile}}, $thread);
    return 0;
}

# _generate_value compiles its argument into a value suitable for execution
# with BC_EVA.

sub _generate_value {
    my ($object, $thread, $grammar, $symbol, $source, $is_expr) = @_;
    my ($code, $end) = _generate_comment($object, $thread, $grammar, $symbol,
					 $source, 0, $is_expr);
    if ($end < length($source) && ! $is_expr) {
	$code .= (_string2comment($source, $end, 0))[0];
    }
    return [map { new Language::INTERCAL::Numbers::Spot $_ }
		unpack('C*', $code)];
}

# _generate_comment tries to generate code, and, if that fails, returns
# code for the appropriate splat

sub _generate_comment {
    my ($object, $thread, $grammar, $symbol, $source, $pos, $is_expr) = @_;
##print STDERR "generate_comment: $grammar $symbol $pos\n";
    if ($grammar <= @{$thread->{grammar}}) {
	my $pt = undef;
	my $end = $pos;
	my $code = '';
	eval {
	    $pt = $thread->{grammar}[$grammar]->compile($symbol, $source, $pos);
	    $end = $pt->end if ref $pt;
	    $code = $pt->code if ref $pt;
	};
##print STDERR "$pos => $end ", length($code), " ", do { my $s = substr($source, $pos, $end - $pos); $s =~ s/\s+/ /g; $s =~ s/^ //; $s =~ s/ $//; $s }, " ($@)\n";
	if ($@ ||
	    ! $pt ||
	    ! ref $pt ||
	    $end == $pos ||
	    ($is_expr && $end < length($source)))
	{
	    my $splat = $@;
	    my $num = 0;
	    if ($splat) {
		$source = $splat;
		$source =~ s/\s+$//;
		$end = 0;
		$num = $1 if $source =~ s/^(\d+)\s*//;
	    }
	    my ($c1, $p1) = _string2comment($source, $end, $num);
	    $p1 = length($source) if $splat;
##print STDERR "* ($num) $p1 ", length($c1), " <$splat>\n";
	    return ($code . $c1, $p1, 0) if ! $is_expr;
	    return (chr(BC_DIV) . $c1 . $code, $p1, 0);
	}
	return ($code, $end, $pt);
    }
    return _string2comment($source, $pos, 0);
}

sub _string2comment {
    my ($source, $pos, $num) = @_;
    $source = substr($source, $pos);
    $pos += length($&) if $source =~ s/^\s+//;
    $source = $` . $1 if $source =~ /(.)(?:\(\d+\)\s*)?(?:DO|PLEASE)/si;
    $pos += length($source);
    $source =~ s/\s+/ /g;
    $source =~ s/ $//;
    $source = ascii2baudot($source, 0);
    (pack("C*", BC_CAR, BC_MUL,
		(map { BC($_) } length($source), unpack('C*', $source)),
		BREG_SV, BC_COM, BC($num), BREG_SV),
     $pos, 0);
}

sub _create {
    my ($object, $thread, $grammar, $symbol, $left, $right, $clone) = @_;
    faint(SP_EVOLUTION, $grammar) if $grammar >= @{$thread->{grammar}};
    _separate_grammar($object, $thread, $clone, $grammar)
	if defined $clone && $clone;
    $thread->{grammar}[$grammar]->add($symbol, $left, $right);
    ${$thread->{compile}}++;
##print STDERR "compile => ${$thread->{compile}}\n";
}

sub _destroy {
    my ($object, $thread, $grammar, $symbol, $left, $clone) = @_;
    faint(SP_EVOLUTION, $grammar) if $grammar >= @{$thread->{grammar}};
    _separate_grammar($object, $thread, $clone, $grammar)
	if defined $clone && $clone;
    $thread->{grammar}[$grammar]->remove($symbol, $left)
	or faint(SP_EVOLUTION);
    ${$thread->{compile}}++;
##print STDERR "compile => ${$thread->{compile}}\n";
}

sub _destroy_all {
    my ($object, $thread, $grammar, $clone) = @_;
    faint(SP_EVOLUTION, $grammar) if $grammar >= @{$thread->{grammar}};
    _separate_grammar($object, $thread, $clone, $grammar)
	if defined $clone && $clone;
    $thread->{grammar}[$grammar] =
	Language::INTERCAL::Parser->new($thread->{grammar}[$grammar]);
    _garbage_collect($object);
    # we assume they know what they do with their grammars (ha!)
    # ${$thread->{compile}}++;
}

sub _convert {
    my ($object, $thread, $grammar, $symbol, $left1, $left2, $swap, $clone) =
	@_;
    faint(SP_EVOLUTION, $grammar) if $grammar >= @{$thread->{grammar}};
    _separate_grammar($object, $thread, $clone, $grammar)
	if defined $clone && $clone;
    my $right1 = $thread->{grammar}[$grammar]->remove($symbol, $left1)
	or faint(SP_EVOLUTION);
    my $right2 = $thread->{grammar}[$grammar]->remove($symbol, $left2)
	or do {
	    # restore production we've just removed, in case they unsplat
	    # and continue
	    $thread->{grammar}[$grammar]->add($symbol, $left1, $right1);
	    faint(SP_EVOLUTION);
    };
    $thread->{grammar}[$grammar]->add($symbol, $left1, $right2);
    my $right0 = $swap ? $right1 : $right2;
    $thread->{grammar}[$grammar]->add($symbol, $left2, $right0);
    ${$thread->{compile}}++;
##print STDERR "compile => ${$thread->{compile}}\n";
}

sub _force_compile {
    my ($object) = @_;
##print STDERR "FCO start\n";
    my %seen = ();
    for my $thread (@{$object->{threads}}) {
	my $stmt = $thread->{statements};
	next if exists $seen{$stmt};
	$seen{$stmt} = 1;
	my ($ip, $cp) = _ip($thread);
	_forall_statement($object, $thread, $ip, $cp, sub {});
    }
##print STDERR "FCO end\n";
}

sub remove_source {
    @_ == 2 or croak "Usage: OBJECT->remove_source(AND_COMMENTS)";
    my ($object, $rm_comments) = @_;
    faint(SP_SUBVERSION) if $rm_comments && @{$object->{threads}} > 1;

    # this would be your last chance of compiling anything on this object!
    my $thread  = $object->{threads}[0];
    my $stmt = $thread->{statements};
    my ($ip, $cp) = _ip($thread);
    _forall_statement($object, $thread, $ip, $cp, sub {});
    for (my $s = 1; $s < @$stmt; $s++) {
	my $stp = $stmt->[$s];
	if ($rm_comments && $stp->[11] && $stp->[7] == BC_COM) {
##print STDERR "Removing $s ip=$$ip/$$cp";
	    splice(@$stmt, $s, 1);
	    $$cp = 0 if $$ip == $s;
	    $$ip-- if $$ip > $s;
	    $s--;
##print STDERR " => $$ip/$$cp\n";
	} else {
	    $stp->[0] = -1; # fileno
	    $stp->[1] = 0;  # startpos
	    $stp->[2] = 0;  # endpos
	    $stp->[4] = 0;  # compile
	    $stp->[12] = 0; # parse tree
	}
    }

    $object->{file} = [];
    $object;
}

sub strip {
    @_ == 1 or croak "Usage: OBJECT->strip";
    my ($object) = @_;

##print STDERR "Threads = ", scalar @{$object->{threads}};
    # remove dead threads
    $object->{threads} = [ grep { $_->{running} } @{$object->{threads}} ];
##print STDERR " => ", scalar @{$object->{threads}}, "\n";

    # find the earliest IP on each separate array of compiled code
    my %minip = ();
    for my $thread (@{$object->{threads}}) {
	my ($ip, $cp) = _ip($thread);
	next if $$ip == 0;
	# if possible, advance program counters before doing this
	my $stp = $thread->{statements};
	$$ip++, $$cp = 0 while $$ip < @$stp && $$cp >= length($stp->[$$ip][3]);
	if (! exists $minip{$stp}) {
	    $minip{$stp} = [$$ip, $stp, []];
	} elsif ($minip{$stp}[0] > $$ip) {
	    $minip{$stp}[0] = $$ip;
	}
	push @{$minip{$stp}[2]}, $thread;
    }
##print STDERR "Minip => ", join(' ', map { $_->[0] } values %minip), "\n";

##print STDERR "Codesize = $object->{codesize}";
    # adjust codesize if necessary
    my $os = $object->{statements};
    if (exists $minip{$os}) {
	my $min = $minip{$os}[0] - 1;
	if ($min > $object->{codesize}) {
	    $object->{codesize} = 0;
	} else {
	    $object->{codesize} -= $min;
	}
    }
##print STDERR " => $object->{codesize}\n";

    # remove any no longer reachable code and find the earliest mentioned
    # source code file
    my $minfile = undef;
    my $minbyte = undef;
    for my $sp (keys %minip) {
	my $min = $minip{$sp}[0] - 1;
	$min = 0 if $min < 0;
	my $ls = @{$minip{$sp}[1]} > 1 ? $minip{$sp}[1][-1] : undef;
	splice @{$minip{$sp}[1]}, 1, $min;
	for my $thread (@{$minip{$sp}[2]}) {
	    my ($ip, $cp) = _ip($thread);
##print STDERR "<$thread> $$ip $min";
	    $$ip -= $min;
##print STDERR " => $$ip\n";
	}
	my ($firstfile, $firststmt);
	if (@{$minip{$sp}[1]} > 1) {
	    $firststmt = $minip{$sp}[1][1];
	    $firstfile = $firststmt->[0];
	    $firstfile = @{$object->{file}} if $firstfile < -1;
	} elsif (defined $ls) {
	    $firststmt = [$ls->[0], $ls->[2]];
	    $firstfile = $firststmt->[0];
	    $firstfile = @{$object->{file}} if $firstfile < -1;
	} else {
	    $firstfile = @{$object->{file}};
	    $firststmt = [0, undef];
	}
##print STDERR "firstfile=$firstfile\n";
	if ($firstfile >= 0) {
	    if (! defined $minfile or $minfile > $firstfile) {
		$minfile = $firstfile;
		if (! defined $minbyte or $minbyte > $firststmt->[1]) {
		    $minbyte = $firststmt->[1];
		}
	    }
	}
    }
##print STDERR "minfile=", defined $minfile ? $minfile : "undef", "; ";
##print STDERR "minbyte=", defined $minbyte ? $minbyte : "undef", "\n";

    # remove unused source code and adjust pointers in statements
    if (defined $minfile) {
	$minbyte = 0 if ! defined $minbyte;
	while ($minfile < @{$object->{file}}) {
	    last if $minbyte < length($object->{file}[0][1]);
	    $minbyte = 0;
	    $minfile++;
	}
	splice @{$object->{file}}, 0, $minfile;
	substr($object->{file}[0][1], 0, $minbyte) = '' if $minbyte;
	for my $sp (keys %minip) {
	    for my $s (@{$minip{$sp}[1]}) {
		$s->[0] -= $minfile if $s->[0] >= 0;
		$s->[1] -= $minbyte if $s->[0] == 0;
		$s->[2] -= $minbyte if $s->[0] == 0;
	    }
	}
    }

    # garbage collect grammars
    _garbage_collect($object);
    $object;
}

sub _garbage_collect {
    my ($object) = @_;
    my @all_grammars = map { @{$_->{grammar}} } @{$object->{threads}};
    my $grammar = shift @all_grammars;
    my @saveregs = ();
    for my $thread (@{$object->{threads}}) {
	my $saveregs = {};
	for my $r (IREG_IS, IREG_ES) {
	    my $n = ${$thread->{registers}{$r}{value}};
	    my $s = $grammar->symbol($n);
	    $saveregs->{$r} = $s;
##print STDERR "$r > $s > $n\n";
	}
	push @saveregs, $saveregs;
    }
    $grammar->garbage_collect(@all_grammars);
    for my $thread (@{$object->{threads}}) {
	my $saveregs = shift @saveregs;
	for my $r (keys %$saveregs) {
	    my $s = $saveregs->{$r};
	    my $n = $grammar->find_symbol($s);
	    $thread->{registers}{$r}{value} =
		new Language::INTERCAL::Numbers::Spot $n;
##print STDERR "$r < $s < $n\n";
	}
    }
}

sub _create_array {
    my ($object, $thread, $register, $value, $ip, $cp, $clone) = @_;
    $value = [$value] unless 'ARRAY' eq ref $value;
    my $size = new Language::INTERCAL::Numbers::Spot scalar(@$value);
    # optimise for common case - nonoverloaded store
    my $number = $register->[0] . $register->[1];
    if ($register->[0] ne '/' &&
	$register->[0] ne '\\' &&
	(! exists $thread->{registers}{$number} ||
	 ! exists $thread->{registers}{$number}{overload}))
    {
	$$size < 1 || $$size > 0xffff and faint(SP_SUBSCRIPT, $$size);
	faint(SP_ISCLASS, $number) if $register->[0] eq '@';
	faint(SP_NOARRAY, $number) if $register->[0] eq '.' ||
				      $register->[0] eq ':' ||
				      $register->[0] eq '%';
	_create_register($object, $number)
	    if ! exists $thread->{registers}{$number};
	_separate_register($object, $thread, $clone, $number)
	    if defined $clone && $clone;
	my $r = $thread->{registers}{$number};
	$r->{dimension} = [$size];
	$r->{value} = map { ($_ => {value => $value->[$_]}) } (0..$#$value);
	delete $r->{is_default};
	$thread->{registers}{&IREG_OS}{owner} = [$number];
    }
    my @reg = ($register->[0], $register->[1]);
    _store($object, $thread, $size, \@reg, $ip, $cp, $clone);
    push @reg, 1;
    for my $val (@$value) {
	_store($object, $thread, $val, \@reg, $ip, $cp, $clone);
	$reg[2]++;
    }
}

sub trace_fh {
    @_ == 1 or @_ == 2 or croak "Usage: OBJECT->trace_fh [(FILEHANDLE | 0)]";
#__TRACE_START__
    my $object = shift;
    if (@_) {
	my $t = shift;
	if ($t) {
	    ref $t && UNIVERSAL::isa($t, 'Language::INTERCAL::GenericIO')
		or croak "Invalid filehandle";
	    $object->{trace_fh} = $t;
	} else {
	    $object->{trace_fh} = 0;
	}
    } else {
	$object->{trace_fh};
    }
#__TRACE_END__
}

#__TRACE_START__
sub _trace_init {
    my ($object) = @_;
    $object->{trace} = [];
    $object->{last_traced} = '';
}

sub _trace_exit {
    my ($object, $thread) = @_;
    my $trace_fh = $object->{trace_fh};
    return unless $trace_fh;
    _set_read_charset($object, $thread, 'trace_fh');
    my $hex = '';
    my $asc = '';
    for my $trace (@{$object->{trace}}) {
	my ($h, $a);
	if ($trace->[1]) {
	    $h = $trace->[1] < 2 ? sprintf(" %02x", $trace->[0]) : '';
	    $a = ' ' . $trace->[0];
	} else {
	    $h = defined $trace->[0] ? sprintf(" %02x", $trace->[0]) : '';
	    $a = ' ' . (bytedecode($trace->[0]) || '???');
	}
	if (length($hex) + length($h) > 33 || length($asc) + length($a) > 46) {
	    $hex =~ s/^\s+//;
	    $trace_fh->read_text(sprintf("%-33s|%s\n", $hex, $asc));
	    $hex = $asc = '';
	}
	$hex .= $h;
	$asc .= $a;
    }
    $hex =~ s/^\s+//;
    $trace_fh->read_text(sprintf("%-33s|%s\n", $hex, $asc)) if $asc ne '';
    $object->{trace} = [];
    $object->{last_traced} = '';
}

sub _trace {
    my ($object, $ip, $cp, $byte, $special) = @_;
    return unless $object->{trace_fh};
    my $lt = "$ip $cp $byte";
    # confess($lt) if ! defined $ip || ! defined $cp || ! defined $byte;
    return if $object->{last_traced} eq $lt && $special != 2;
    push @{$object->{trace}}, [$byte, $special];
    $object->{last_traced} = $lt;
}
#__TRACE_END__

1;
