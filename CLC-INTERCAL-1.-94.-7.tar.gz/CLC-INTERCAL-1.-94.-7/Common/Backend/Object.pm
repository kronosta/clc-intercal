package Language::INTERCAL::Backend::Object;

# Back end to write object to a filehandle

# This file is part of CLC-INTERCAL

# Copyright (c) 2002 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. The principal points are:

# * No charge can be made for distributing CLC-INTERCAL under any conditions.
#   This condition does not apply to payment of copying/distribution expenses
#   provided that no handling or other charge is added to such expenses.

# * The author cannot accept any liability whatsoever for any damage caused
#   by the software, directly or indirectly. No warranty of any kind can be
#   offered. Using the software in a way which causes any form of damage is
#   expressely prohibited.

# * In addition, the author's details shall not be entered into any mailing
#   list or public directory, without the author's written permission.

# * CLC-INTERCAL can be redistributed only under an identical licence
#   agreement. Any modified or derived work must also be covered by the
#   same identical agreement as the original work.

# See the file "licence.iacc" in the software installation directory (or the
# distribution, if the software has not been installed) for a full licence
# agreement. Please note that, this being an INTERCAL licence agreement, you
# must submit a text file to "licence.iacc", which will agree to it only if
# the text file happened to contain the correct licence agreement. See the
# README file in the distribution for more details.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Backend/Object.pm 1.-94.-8";

use Carp;

use Language::INTERCAL::Exporter '1.-94.-8';

use constant default_suffix => 'io';
use constant default_mode => 0666; # objects are not (directly) executable

sub generate {
    @_ == 4 || @_ == 5
	or croak "Usage: BACKEND->generate(OBJECT, NAME, FILEHANDLE)";
    my ($class, $object, $name, $filehandle, $options) = @_;
    $object->read_object($filehandle);
}

1;
