package Language::INTERCAL::Backend::Perlmodule;

# Produce a Perl module

# This file is part of CLC-INTERCAL

# Copyright (c) 2002 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. The principal points are:

# * No charge can be made for distributing CLC-INTERCAL under any conditions.
#   This condition does not apply to payment of copying/distribution expenses
#   provided that no handling or other charge is added to such expenses.

# * The author cannot accept any liability whatsoever for any damage caused
#   by the software, directly or indirectly. No warranty of any kind can be
#   offered. Using the software in a way which causes any form of damage is
#   expressely prohibited.

# * In addition, the author's details shall not be entered into any mailing
#   list or public directory, without the author's written permission.

# * CLC-INTERCAL can be redistributed only under an identical licence
#   agreement. Any modified or derived work must also be covered by the
#   same identical agreement as the original work.

# See the file "licence.iacc" in the software installation directory (or the
# distribution, if the software has not been installed) for a full licence
# agreement. Please note that, this being an INTERCAL licence agreement, you
# must submit a text file to "licence.iacc", which will agree to it only if
# the text file happened to contain the correct licence agreement. See the
# README file in the distribution for more details.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Backend/Perlmodule.pm 1.-94.-8";

use Carp;
use Config '%Config';

use Language::INTERCAL::Exporter '1.-94.-8';

use constant default_suffix => 'pm';
use constant default_mode   => 0666;

my ($V) = $PERVERSION =~ /(\S+)$/;
my $O = 'Language::INTERCAL::Object';
my $G = 'Language::INTERCAL::GenericIO';
my $E = 'Language::INTERCAL::Exporter';

sub generate {
    @_ == 4 || @_ == 5
	or croak "Usage: BACKEND->generate(OBJECT, NAME, FILEHANDLE)";
    my ($class, $object, $name, $filehandle, $options) = @_;
    $name =~ s/\.[^.]*$//;
    my @name = grep {$_ ne ''} split(/[:\/]+/, $name);
    for my $n (@name) {
	$n =~ s/\W+/_/g;
	$n =~ s/^(\d)/_$1/;
    }
    my $func;
    if (@name > 1) {
	$func = pop @name;
	$name = join('::', @name);
    } elsif (@name > 0) {
	$func = $name = shift @name;
    } else {
	croak "Invalid empty name";
    }
    $filehandle->read_binary(<<EOF);
package $name;

# Module thrown up by CLC-INTERCAL $V: read/use at your own risk

use strict;
#use bondage;
use Carp;

use $E '$V', ();
use $G '$V';
use $O '$V';

use vars qw(\@EXPORT \@EXPORT_OK);
\@EXPORT = ();
\@EXPORT_OK = qw($func);

my \$data;
{ local \$/ = undef; \$data = <DATA> }

sub $func {
    \@_ % 2 == 0 or croak "Usage: $func(key => value...)";
    my \%args = \@_;
    my \$d = \$data;
    my \$ofh = $G\->new('STRING', 'w', \\\$data);
    my \$obj = $O\->write_object(\$ofh);
    \$obj->setargs(\$args{ARGV}) if exists \$args{ARGV};
    \$obj->setenv(\$args{ENVV}) if exists \$args{ENVV};
    \$obj->read_fh(\$args{read_fh}) if exists \$args{read_fh};
    \$obj->write_fh(\$args{write_fh}) if exists \$args{write_fh};
    \$obj->splat_fh(\$args{splat_fh}) if exists \$args{splat_fh};
    \$obj->run();
    \$obj;
}

__DATA__
EOF
    $object->read_object($filehandle);
}

1;
