package Language::INTERCAL::Parser;

# Parser/code generator/etc for the "Just-Too-Late" compiler

# This file is part of CLC-INTERCAL

# Copyright (c) 2002 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. The principal points are:

# * No charge can be made for distributing CLC-INTERCAL under any conditions.
#   This condition does not apply to payment of copying/distribution expenses
#   provided that no handling or other charge is added to such expenses.

# * The author cannot accept any liability whatsoever for any damage caused
#   by the software, directly or indirectly. No warranty of any kind can be
#   offered. Using the software in a way which causes any form of damage is
#   expressely prohibited.

# * In addition, the author's details shall not be entered into any mailing
#   list or public directory, without the author's written permission.

# * CLC-INTERCAL can be redistributed only under an identical licence
#   agreement. Any modified or derived work must also be covered by the
#   same identical agreement as the original work.

# See the file "licence.iacc" in the software installation directory (or the
# distribution, if the software has not been installed) for a full licence
# agreement. Please note that, this being an INTERCAL licence agreement, you
# must submit a text file to "licence.iacc", which will agree to it only if
# the text file happened to contain the correct licence agreement. See the
# README file in the distribution for more details.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Parser.pm 1.-94.-8";

use Carp;

use Language::INTERCAL::Exporter '1.-94.-8';
use Language::INTERCAL::Splats '1.-94.-8', qw(:SP);
use Language::INTERCAL::ByteCode '1.-94.-8', qw(:BC);
use Language::INTERCAL::Charset::Baudot '1.-94.-8', qw(ascii2baudot);

# PLEASE NOTE: @predefined_symbols MUST HAVE 8 OR LESS SYMBOLS
my @predefined_symbols = (
    # NAME       PARSE                  BAD GENCODE
    ["CONSTANT", qr/\G(\d+)/,           0,  \&_code_constant],
    ["SYMBOL",   qr/\G(\w+)/,           0,  \&_code_symbol],
    ["JUNK",     qr/\G.+?(?=(?:\(\d+\)\s*)?(?:DO|PLEASE))/si,
					1,  \&_code_junk],
);

sub _code_constant {
    my ($tree, $number) = @_;
    my @code = BC($number);
    (pack('C*', @code), scalar(@code));
}

sub _code_symbol {
    my ($tree, $string) = @_;
    $string = ascii2baudot($string, 0);
    my @code = map { BC($_) } unpack('C*', $string);
    (pack('C*', @code), scalar(@code));
}

sub _code_junk {
    my ($tree) = @_;
    my ($source, $grammar, $start, $end) = @$tree;
    my $string = substr($source, $start, $end - $start);
    $string =~ s/^\s+//;
    $string =~ s/\s+$//;
    $string = ascii2baudot($string, 0);
    my @code = map { BC($_) } unpack('C*', $string);
    (pack('C*', @code), scalar(@code));
}

sub new {
    @_ == 1 or @_ == 2
	or croak "Usage: new Language::INTERCAL::Parser [(SYMBOLTABLE)]";
    my ($class, $symboltable) = @_;
    my $grammar = bless {
	productions => [],
	converted => 1,
    }, $class;
    if ($symboltable) {
	$grammar->{symbols} = $symboltable->{symbols};
	$grammar->{symbolindex} = $symboltable->{symbolindex};
    } else {
	$grammar->{symbols} = [''];
	$grammar->{symbolindex} = {};
	for (my $idx = 1; $idx <= @predefined_symbols; $idx++) {
	    my $sym = $predefined_symbols[$idx - 1][0];
	    $grammar->{symbols}[$idx] = $sym;
	    $grammar->{symbolindex}{$sym} = $idx;
	}
    }
    $grammar;
}

sub append {
    @_ == 2 or croak "Usage: GRAMMAR->append(OTHER_GRAMMAR)";
    my ($grammar, $other) = @_;

    my $nprod = grep { $_ } @{$grammar->{productions}};

    my $op = $other->{productions};
    for (my $othersymbol = 1; $othersymbol < @$op; $othersymbol++) {
	my $prodlist = $op->[$othersymbol];
	next unless $prodlist;
	my $name = $other->{symbols}[$othersymbol];
	my $symbol = find_symbol($grammar, $name);
	for my $prod (@$prodlist) {
	    my ($left, $right, $init, $starts, $isempty, $regex) = @$prod;
	    # we don't need deep copies, however, symbols in @$left and
	    # %$starts need to be translated because the two symbol tables
	    # are (potentially) different
	    $left = _copyleft($grammar, $other, $left);
	    if (! exists $other->{converted}) {
		$init = '';
		$starts = '';
		$isempty = 0;
	    }
	    _remove($grammar, $symbol, $left);
	    _add($grammar, $symbol, $left, $right, $init,
		 $starts, $isempty, $regex);
	}
    }
    if ($nprod == 0 && exists $other->{converted}) {
	# we appended to an empty grammar so "converted" is valid
	$grammar->{converted} = 1;
    } else {
	# converted is no longer valid
	delete $grammar->{converted};
    }

    $grammar;
}

sub copy {
    @_ == 1 or @_ == 2 or croak "Usage: GRAMMAR->copy [(KEEPSYMB)]";
    my $grammar = shift;
    my $symb = @_ && $_[0] ? $grammar : undef;
    append(ref($grammar)->new($symb), $grammar);
}

# copies a "left" grammar (production), converting symbols as necessary if
# the objects have different symbol tables. Has nothing to do with the Free
# Software Foundation, despite the name. There is no corresponding
# _copyright() because the representation of "right" grammars (code)
# using BELONGS TO pointers makes it unnecessary.
sub _copyleft {
    my ($to, $from, $left) = @_;
    my @copy = ();
    for my $element (@$left) {
	my ($type, $e, @rest) = @$element;
	if ($type eq 's') {
	    my $name = $from->{symbols}[$e];
	    $e = find_symbol($to, $name);
	}
	push @copy, [$type, $e, @rest];
    }
    \@copy;
}

sub find_symbol {
    @_ == 2 or croak "Usage: GRAMMAR->find_symbol(STRING)";
    my ($grammar, $symbol) = @_;
    if (! exists $grammar->{symbolindex}{$symbol}) {
	my $idx = @{$grammar->{symbols}};
	push @{$grammar->{symbols}}, $symbol;
	$grammar->{symbolindex}{$symbol} = $idx;
    }
    $grammar->{symbolindex}{$symbol};
}

sub symbol {
    @_ == 2 or croak "Usage: GRAMMAR->symbol(NUMBER)";
    my ($grammar, $symbol) = @_;
    return '' if $symbol !~ /^\d+$/ || $symbol >= @{$grammar->{symbols}};
    $grammar->{symbols}[$symbol];
}

sub read_grammar {
    @_ == 2 or @_ == 3 or
	croak "Usage: GRAMMAR->read_grammar(FILEHANDLE [, INCLUDESYMBOLS])";
    my $grammar = shift;
    my $fh = shift;
    my $read_symbols = @_ && $_[0];

    # make it faster to run next time
    _convert_grammar($grammar);

    my $slist = $grammar->{symbols};
    $fh->read_binary(pack('Cv', $read_symbols, scalar @$slist));
    for (my $symbol = 1; $symbol < @$slist; $symbol++) {
	if ($read_symbols) {
	    my $sym = $slist->[$symbol];
	    $fh->read_binary(pack('va*', length($sym), $sym));
	}
	my $gp = $grammar->{productions}[$symbol] || [];
	$fh->read_binary(pack('v', scalar @$gp));
	for my $prod (@$gp) {
	    _read_left($fh, $prod->[0]);
	    _read_right($fh, $prod->[1]);
	    $fh->read_binary(pack('va*', length($prod->[2]), $prod->[2]));
	    my $p = $prod->[3] eq '' ? "\000" : substr($prod->[3], 0, 1);
	    $fh->read_binary(pack('aC', $p, $prod->[4]));
	}
    }

    $grammar;
}

sub _read_left {
    my ($fh, $left) = @_;
    $fh->read_binary(pack('v', scalar(@$left)));
    for my $element (@$left) {
	my ($type, $e, $c) = @$element;
	$fh->read_binary($type);
	if ($type eq 's') {
	    $fh->read_binary(pack('v', $e));
	} else {
	    $fh->read_binary(pack('va*', length($e), $e));
	}
	$fh->read_binary(pack('v', $c));
    }
}

sub _read_right {
    my ($fh, $right) = @_;
    $fh->read_binary(pack('v', scalar(@$right)));
    for my $element (@$right) {
	my $type = $element->[0];
	my $e = $element->[1];
	$fh->read_binary($type);
	if ($type eq 'm') {
	    _read_right($fh, $e);
	} elsif ($type eq 'b') {
	    $fh->read_binary(pack('va*', length($e), $e));
	} else {
	    $fh->read_binary(pack('v', $e));
	}
    }
}

sub write_grammar {
    @_ == 2 or @_ == 3 or croak "Usage: write_grammar " .
			  "Language::INTERCAL::Parser(FILEHANDLE [, SYMBOLS])";
    my ($class, $fh, $symboltable) = @_;
    my $grammar = bless {}, $class;

    my $has_symbols = unpack('C', $fh->write_binary(1));

    if ($has_symbols) {
	croak "Duplicate symbol table" if $symboltable;
	$grammar->{symbols} = [''];
	$grammar->{symbolindex} = {};
    } elsif ($symboltable) {
	$grammar->{symbols} = $symboltable->{symbols};
	$grammar->{symbolindex} = $symboltable->{symbolindex};
    } else {
	croak "Missing symbol table";
    }
    $grammar->{productions} = [];

    my $nsymbols = unpack('v', $fh->write_binary(2));
    for (my $symbol = 1; $symbol < $nsymbols; $symbol++) {
	if ($has_symbols) {
	    my $nlen = unpack('v', $fh->write_binary(2));
	    my $name = $fh->write_binary($nlen);
	    $grammar->{symbols}[$symbol] = $name;
	    $grammar->{symbolindex}{$name} = $symbol;
	}
	my $nprod = unpack('v', $fh->write_binary(2));
	my @prod = ();
	while ($nprod-- > 0) {
	    my $left = _write_left($fh);
	    my $right = _write_right($fh);
	    my $ninit = unpack('v', $fh->write_binary(2));
	    my $initial = $fh->write_binary($ninit);
	    my ($startmap, $empty) = unpack('aC', $fh->write_binary(2));
	    push @prod, [$left, $right, $initial, $startmap, $empty];
	}
	$grammar->{productions}[$symbol] = \@prod;
    }

    _make_regexs($grammar);
    $grammar->{converted} = 0;

    $grammar;
}

sub _write_left {
    my ($fh) = @_;
    my $elems = unpack('v', $fh->write_binary(2));
    my @left = ();
    while ($elems-- > 0) {
	my $type = $fh->write_binary(1);
	my $data = '';
	my @comp = ();
	if ($type eq 's') {
	    $data = unpack('v', $fh->write_binary(2));
	} elsif ($type eq 'r') {
	    my $size = unpack('v', $fh->write_binary(2));
	    $data = $fh->write_binary($size);
	    require Language::INTERCAL::Reggrim;
	    import Language::INTERCAL::Reggrim '1.-94', qw(rg_compile);
	    # try to compile reggrim
	    my $comp = rg_compile($data);
	    @comp = ($comp);
	} else {
	    my $size = unpack('v', $fh->write_binary(2));
	    $data = uc($fh->write_binary($size));
	    @comp = (length($data));
	}
	my $count = unpack('v', $fh->write_binary(2));
	push @left, [$type, $data, $count, @comp];
    }
    \@left;
}

sub _write_right {
    my ($fh) = @_;
    my $elems = unpack('v', $fh->write_binary(2));
    my @right = ();
    while ($elems-- > 0) {
	my $type = $fh->write_binary(1);
	my $data = '';
	if ($type eq 'm') {
	    $data = _write_right($fh);
	} elsif ($type eq 'b') {
	    my $len = unpack('v', $fh->write_binary(2));
	    $data = $fh->write_binary($len);
	} else {
	    $data = unpack('v', $fh->write_binary(2));
	}
	push @right, [$type, $data];
    }
    \@right;
}

sub _reggrim_compile {
    my ($rg) = @_;
    require Language::INTERCAL::Reggrim;
    import Language::INTERCAL::Reggrim '1.-94', qw(rg_compile);
    scalar rg_compile($rg);
}

sub _convert_left {
    my ($left) = @_;
    [map {
	$_->[0] eq 'r'
	    ? [$_->[0], $_->[1], $_->[2], _reggrim_compile($_->[1])]
	    : $_->[0] eq 'c' && $_->[1] eq ''
		? ()
		: $_->[0] eq 'c'
		    ? [$_->[0], uc($_->[1]), $_->[2], length($_->[1])]
		    : [$_->[0], $_->[1], $_->[2]];
    } @$left];
}

sub _find_right {
    my ($left, $type, $number, $data) = @_;
    for (my $lp = 0; $lp < @$left; $lp++) {
	my $l = $left->[$lp];
	next if $l->[0] ne $type;
	next if $l->[0] eq 's' && $l->[1] != $data;
	next if $l->[0] ne 's' && $l->[1] ne $data;
	$number--;
	return $lp if $number < 1;
    }
    faint(SP_CREATION);
}

sub _convert_right {
    my ($right, $left, $grammar) = @_;
    [map {
	$_->[0] eq 'c' && $_->[2] eq '' ? () :
	$_->[0] =~ /^[scr]$/ ?
	    [$_->[0], _find_right($left, $_->[0], $_->[1], $_->[2])] :
	$_->[0] eq 'n' ?
	    [$_->[0], _find_right($left, 's', $_->[1], $_->[2])] :
	$_->[0] eq 'm' ?
	    [$_->[0], _convert_right($_->[1], $left, $grammar)] :
	[$_->[0], $_->[1]];
    } @$right];
}

sub _count_left {
    my ($type, $number, $left) = @_;
    my $count = 0;
    my $data = $left->[$number][1];
    for (my $lp = 0; $lp <= $number; $lp++) {
	my $l = $left->[$lp];
	next if $l->[0] ne $type;
	next if $l->[0] eq 's' && $l->[1] != $data;
	next if $l->[0] ne 's' && $l->[1] ne $data;
	$count++;
    }
    $count;
}

sub _unconvert_right {
    my ($right, $left) = @_;
    [map {
	$_->[0] =~ /^[scrn]$/ ?
	    [$_->[0], _count_left($_->[0], $_->[1], $left)] :
	$_->[0] eq 'n' ?
	    [$_->[0], _count_left('s', $_->[1], $left)] :
	$_->[0] eq 'm' ?
	    [$_->[0], _unconvert_right($_->[1], $left)] :
	[$_->[0], $_->[1]];
    } @$right];
}

# compile attempts to generate code; it can return:
#    PARSETREE      if a prefix of the source can be parsed
#    1              if the source is a prefix of a parseable string
#    0              otherwise

sub compile {
    @_ == 4 or croak "Usage: GRAMMAR->compile(SYMBOL, SOURCE, POS)";
    my ($grammar, $symbol, $source, $position) = @_;
    my $productions = $grammar->{productions};
    $symbol = 1 if $symbol < 1;
    pos($source) = $position;
    $position = pos($source) if $source =~ /\G\s+/g;
    # special case out of the main loop (they should not normally do this)
    if ($symbol <= @predefined_symbols) {
	my @ok = $source =~ $predefined_symbols[$symbol - 1][1];
	return 0 unless @ok;
	my $end = pos($source);
	$end = pos($source) if $source =~ /\G\s+/g;
	return @ok
	    ? bless [$source, $grammar, $position, $end, [$symbol, 0, @ok]],
		    'Language::INTERCAL::ParseTree'
	    : 0;
    }
    # normal case, parsing on user-defined symbols
    return 0 if $symbol >= @$productions;
    my $prod = $productions->[$symbol];
    return 0 if !$prod || !@$prod;
    _convert_grammar($grammar);
    my @state = ();
    my $stack = [];
    my $start = $position;
    my $incomplete = 0;
    my $best_pos = 0;
    my $best_bad = 1_000_000_000;
    my $best_tree = 0;
    for (my $prodnum = @$prod - 1; $prodnum >= 0; $prodnum--) {
	pos($source) = $position;
	push @state, [$symbol, $prodnum, 0, $position, 0, [@$stack]]
	    if $source =~ $prod->[$prodnum][5];
    }
    STATE: while (@state) {
	my ($badness, $prodnum, $prodelem, @tree);
	($symbol, $prodnum, $prodelem, $position,
	 $badness, $stack, @tree) = @{pop @state};
	my $prod = $productions->[$symbol][$prodnum];
	my $left = $prod->[0];
	ELEM: while ($prodelem < @$left) {
	    my ($type, $data, $count, $aux) = @{$left->[$prodelem]};
	    $prodelem++;
	    if ($type eq 's') {
		if ($data <= @predefined_symbols) {
		    pos($source) = $position;
		    my $re = $predefined_symbols[$data - 1][1];
		    next STATE unless $source =~ /$re/g;
		    my $end = pos($source);
		    my $bad = $predefined_symbols[$data - 1][2]
			    ? $end - $position
			    : 0;
		    my @ok = defined $1 ? ($1) : ();
		    push @tree, [$data, $bad, @ok];
		    $badness = $bad if $badness < $bad;
		    $position = $end;
		    $position = pos($source) if $source =~ /\G\s+/g;
		    next ELEM;
		} else {
		    push @$stack,
			[$symbol, $prodnum, $prodelem, $badness, @tree];
		    $symbol = $data;
		    next STATE if $symbol >= @$productions;
		    my $prod = $productions->[$symbol];
		    next STATE if !$prod || !@$prod;
		    for (my $prodnum = @$prod - 1; $prodnum >= 0; $prodnum--) {
			pos($source) = $position;
			push @state, [$symbol, $prodnum, 0, $position, 0, [@$stack]]
			    if $source =~ $prod->[$prodnum][5];
		    }
		    next STATE;
		}
	    } elsif ($type eq 'c') {
		my $look = uc(substr($source, $position, $aux));
		if ($data eq $look) {
		    my $end = $position + $aux;
		    push @tree, [0, $position, $end];
		    pos($source) = $end;
		    $end = pos($source) if $source =~ /\G\s+/g;
		    $position = $end;
		    next ELEM;
		} elsif (length($look) < length($data) &&
			 substr($data, 0, length($look)) eq $look) {
		    $incomplete = 1;
		}
		next STATE;
	    } elsif ($type eq 'r') {
		my ($match, $inc) = $aux->match($source, $position);
		if ($match > 0) {
		    my $end = $position + $match;
		    push @tree, [$aux, $position, $end];
		    pos($source) = $end;
		    $end = pos($source) if $source =~ /\G\s+/g;
		    $position = $end;
		    next ELEM;
		} elsif ($inc) {
		    $incomplete = 1;
		}
		next STATE;
	    }
	}
	# end of production
	unshift @tree, $symbol, $prodnum, $prod;
	if (@$stack) {
	    # we were called by another nonterminal
	    my ($nsym, $nprd, $nelm, $nbad, @ntree) = @{pop @$stack};
	    $nbad = $badness if $nbad < $badness;
	    push @state, [$nsym, $nprd, $nelm, $position, $nbad,
			  $stack, @ntree, \@tree];
	} elsif ($badness < $best_bad) {
	    $best_bad = $badness;
	    $best_pos = $position;
	    $best_tree = \@tree;
	} elsif ($badness == $best_bad && $position > $best_pos) {
	    $best_pos = $position;
	    $best_tree = \@tree;
	}
	next STATE;
    }
    return $best_tree
	   ? bless [$source, $grammar, $start, $best_pos, $best_tree],
		   'Language::INTERCAL::ParseTree'
	   : $incomplete;
}

sub _find_starts {
    my ($grammar) = @_;

    # first find if any symbol can expand (directly) to empty strings
    # or (directly) to another symbol; since information about each of
    # these changes our idea of the other, we keep repeating until we
    # cannot make any more changes
    my $empty = '';

    my $found = 0;
    for (my $symb = 1; $symb < @{$grammar->{productions}}; $symb++) {
	my $plist = $grammar->{productions}[$symb];
	next unless $plist;
	for my $prod (@$plist) {
	    $prod->[2] = '';
	    $prod->[3] = '';
	    $prod->[4] = 0;
	}
	$found++;
    }
    return $empty unless $found;

    my $continue = 1;
    while ($continue) {
	$continue = 0;
	SYMB: for (my $symb = 1; $symb < @{$grammar->{productions}}; $symb++) {
	    my $plist = $grammar->{productions}[$symb];
	    next unless $plist;
	    PROD: for my $prod (@$plist) {
		# look at the first element of the production, if there's one
		ELEM: for my $p (@{$prod->[0]}) {
		    if ($p->[0] eq 's') {
			# that means we can access this particular symbol
			$continue = 1 if ! vec($prod->[3], $p->[1], 1);
			vec($prod->[3], $p->[1], 1) = 1;
			# if we know the symbol can parse the empty string,
			# we also need to check the next element
			next if vec($empty, $p->[1], 1);
		    }
		    next if ($p->[0] eq 'c' && $p->[1] eq '') ||
			    ($p->[0] eq 'r' && $p->[3]->can_empty());
		    next PROD;
		}
		# if we get here, all productions are empty, so...
		$continue = 1 if ! vec($empty, $symb, 1);
		vec($empty, $symb, 1) = 1;
		$prod->[4] = 1;
	    }
	}
    }

    for (my $symb = 1; $symb < @{$grammar->{productions}}; $symb++) {
	my $plist = $grammar->{productions}[$symb];
	next unless $plist;
	for my $prod (@$plist) {
	    faint(SP_CIRCULAR, $grammar->{symbols}[$symb])
		if vec($prod->[3], $symb, 1);
	}
    }

    return $empty;
}

sub _convert_grammar {
    my ($grammar) = @_;

    return if exists $grammar->{converted};
    my $empty = _find_starts($grammar);
    my @i_total = map { '' } @{$grammar->{productions}};

    # first find the "direct" initials;
    SYMB: for (my $symb = 1; $symb < @{$grammar->{productions}}; $symb++) {
	my $plist = $grammar->{productions}[$symb];
	next unless $plist;
	PROD: for my $prod (@$plist) {
	    next unless $prod;
	    $prod->[2] = '';
	    # look at the first element of the production, if there's one
	    ELEM: for my $p (@{$prod->[0]}) {
		if ($p->[0] eq 'c') {
		    next if $p->[1] eq '';
		    my $l = ord(uc(substr($p->[1], 0, 1)));
		    vec($i_total[$symb], $l, 1) = 1;
		    vec($prod->[2], $l, 1) = 1;
		    next PROD;
		}
		if ($p->[0] eq 'r') {
		    my @i = $p->[3]->can_start();
		    for my $s (@i) {
			vec($i_total[$symb], $s, 1) = 1;
			vec($prod->[2], $s, 1) = 1;
		    }
		    next if $p->[3]->can_empty();
		}
		next if ($p->[0] eq 's' && vec($empty, $p->[1], 1));
		next PROD;
	    }
	}
    }
    
    # now propagate %i_XXX using %starts
    my $continue = 1;
    while ($continue) {
	$continue = 0;
	for (my $symb = 1; $symb < @{$grammar->{productions}}; $symb++) {
	    my $plist = $grammar->{productions}[$symb];
	    next unless $plist;
	    for my $prod (@$plist) {
		for (my $other = 0; $other < 8 * length($prod->[3]); $other++) {
		    next unless vec($prod->[3], $other, 1);
		    my $init = $i_total[$other];
		    my $np = $prod->[2] | $init;
		    $continue = 1
			if $np ne substr($prod->[2], 0, length($np));
		    $prod->[2] |= $init;
		    $i_total[$symb] |= $init;
		}
	    }
	}
    }

    my $mask = 0;
    for (my $symb = 1; $symb <= @predefined_symbols; $symb++) {
	vec($mask, $symb, 1) = 1;
    }
    for (my $symb = 1; $symb < @{$grammar->{productions}}; $symb++) {
	my $plist = $grammar->{productions}[$symb];
	next unless $plist;
	for my $prod (@$plist) {
	    $prod->[3] = substr($prod->[3], 0, 1) & $mask;
	}
    }

    _make_regexs($grammar);

    $grammar->{converted} = 1;
}

sub _make_regexs {
    my ($grammar) = @_;

    for (my $symb = 1; $symb < @{$grammar->{productions}}; $symb++) {
	my $plist = $grammar->{productions}[$symb];
	next unless $plist;
	for my $prod (@$plist) {
	    if ($prod->[4]) {
		$prod->[5] = qr/\G/;
	    } else {
		my @starts = map { quotemeta(chr($_)) }
				 grep { vec($prod->[2], $_, 1) }
				      (0..(8 * length($prod->[2]) - 1));
		my $starts = join('', @starts);
		my @moves = map { $predefined_symbols[$_ - 1][1] }
				grep { vec($prod->[3], $_, 1) }
				     (1..scalar(@predefined_symbols));
		unshift @moves, "[$starts]" if @starts > 1;
		unshift @moves, $starts if @starts == 1;
		my $regex = join('|', @moves);
		$regex = "(?:$regex)" if @moves > 1;
		$prod->[5] = qr/\G$regex/i;
	    }
	}
    }
}

sub _add {
    my ($grammar, $symb, $left, $right, $init, $starts, $isempty, $regex) = @_;
    push @{$grammar->{productions}[$symb]},
	[$left, $right, $init, $starts, $isempty, $regex];
    delete $grammar->{converted};
}

sub _remove {
    my ($grammar, $symb, $left) = @_;
    return 0 if $symb >= @{$grammar->{productions}};
    my $prods = $grammar->{productions}[$symb];
    return 0 unless $prods;
    SYMB: for (my $pp = 0; $pp < @$prods; $pp++) {
	my $elems = $prods->[$pp][0];
	# see if this production is same as $left
	next SYMB if @$elems != @$left;
	for (my $ep = 0; $ep < @$elems; $ep++) {
	    my $a = $elems->[$ep];
	    my $b = $left->[$ep];
	    next SYMB if $a->[0] ne $b->[0];
	    if ($a->[0] eq 's') {
		next SYMB if $a->[1] != $b->[1];
	    } else {
		next SYMB if $a->[1] ne $b->[1];
	    }
	}
	# This symbol corresponds: remove it (and return old production)
	delete $grammar->{converted};
	return ${splice(@$prods, $pp, 1)}[1];
    }
    return 0;
}

sub add {
    @_ == 4 or croak "Usage: GRANMAR->add(SYMBOL, LEFT, RIGHT)";
    my ($grammar, $symb, $left, $right) = @_;
    $left = _convert_left($left);
    _remove($grammar, $symb, $left);
    $right = _convert_right($right, $left, $grammar);
    _add($grammar, $symb, $left, $right, '', '', 0, 0);
    $grammar;
}

sub remove {
    @_ == 3 or croak "Usage: GRANMAR->remove(SYMBOL, LEFT)";
    my ($grammar, $symb, $left) = @_;
    $left = _convert_left($left);
    my $right = _remove($grammar, $symb, $left);
    return if ! defined wantarray;
    return _unconvert_right($right, $left);
}

sub garbage_collect {
    @_ >= 1 or croak "Usage: GRAMMAR->garbage_collect [(SHARING...)]";
    my @grammars = @_;

    # find what symbols are in use
    my %seen_symbol = ();
    for my $grammar (@grammars) {
	for (my $symb = 1; $symb < @{$grammar->{productions}}; $symb++) {
	    my $plist = $grammar->{productions}[$symb];
	    next unless $plist;
	    next unless @$plist;
	    $seen_symbol{$symb} = $grammar->{symbols}[$symb];
	    for my $prod (@$plist) {
		for my $elem (@{$prod->[0]}) {
		    $seen_symbol{$elem->[1]} = $grammar->{symbols}[$elem->[1]]
			if $elem->[0] eq 's';
		}
	    }
	}
    }

    # generate the new list of symbol, new index, and old->new mapping
    my @newsymbols = ('');
    my %newindex = ();
    my @map = (0) x @{$grammars[0]->{symbols}};
    for (my $idx = 1; $idx <= @predefined_symbols; $idx++) {
	my $sym = $predefined_symbols[$idx - 1][0];
	delete $seen_symbol{$idx};
	$map[$idx] = $idx;
	$newsymbols[$idx] = $sym;
	$newindex{$sym} = $idx;
    }
    # keep order, so not just keys %seen_symbol
    for (my $idx = 1; $idx < @{$grammars[0]->{symbols}}; $idx++) {
	next if ! exists $seen_symbol{$idx};
	my $sym = $seen_symbol{$idx};
	my $newidx = @newsymbols;
	push @newsymbols, $sym;
	$newindex{$sym} = $newidx;
	$map[$idx] = $newidx;
    }
    undef %seen_symbol;

    # now go and translate all productions
    my %seen = ();
    for my $grammar (@grammars) {
	next if exists $seen{$grammar};
	$seen{$grammar} = 1;
	my @newprods = ();
	for (my $symb = 1; $symb < @{$grammar->{productions}}; $symb++) {
	    my $plist = $grammar->{productions}[$symb];
	    next unless $plist;
	    next unless @$plist;
	    for my $prod (@$plist) {
		for my $elem (@{$prod->[0]}) {
		    $elem->[1] = $map[$elem->[1]] if $elem->[0] eq 's';
		}
		if (! exists $grammar->{converted}) {
		    $prod->[2] = '';
		    $prod->[3] = '';
		    $prod->[4] = 0;
		}
	    }
	    my $news = $map[$symb];
	    $newprods[$news] = $plist;
	}
	$grammar->{productions} = \@newprods;
	$grammar->{symbols} = \@newsymbols;
	$grammar->{symbolindex} = \%newindex;
    }

    $grammars[0];
}

sub optimise {
    @_ == 3 or croak "Usage: GRAMMAR->optimise(left, right)";
    my ($grammar, $left, $right) = @_;
    # TODO
    $grammar;
}

package Language::INTERCAL::ParseTree;

use Carp;

use Language::INTERCAL::ByteCode '1.-94.-8', qw(:BC);

sub optimise {
    @_ == 1 or croak "Usage: PARSETREE->optimise";
    my ($tree) = @_;
    # TODO
    $tree;
}

sub start {
    @_ == 1 or croak "Usage: PARSETREE->start";
    my ($tree) = @_;
    $tree->[2];
}

sub end {
    @_ == 1 or croak "Usage: PARSETREE->end";
    my ($tree) = @_;
    $tree->[3];
}

sub code {
    @_ == 1 or croak "Usage: PARSETREE->code";
    my ($tree) = @_;
    my ($source, $grammar, $start, $end, $firstlevel) = @$tree;
    # special case for comments
#    if ($badness) {
#	my $junk = 0;
#	$junk++ while $junk < @predefined_symbols &&
#		      ! $predefined_symbols[$junk][2];
#	return &{$predefined_symbols[$junk][3]}($tree);
#    }

    #my $productions = $grammar->{productions};

    my ($gencode, $joincode);

    $gencode = sub {
	my ($level) = @_;
	my ($symbol, $prodnum, @data) = @$level;
	# sanity check - we should always have a proper nonterminal here
	return ('', 0) if ref $symbol || ! $symbol;
	# is this a predefined symbol?
	if ($symbol <= @predefined_symbols) {
	    return &{$predefined_symbols[$symbol - 1][3]}($tree, @data);
	}
	# it is user-defined - locate the production and join the RHS
	my $prod = shift @data;
	#$prod = $productions->[$symbol][$prodnum];
	my ($left, $right) = @$prod;
	return &$joincode($left, $right, \@data);
    };

    $joincode = sub {
	my ($left, $right, $subtree) = @_;
	my %done = ();
	my @ret;
	for my $exp (@$right) {
	    my ($type, $data) = @$exp;
	    if ($type eq 'b') {
		# constant bytecode
		push @ret, $data;
	    } elsif ($type eq 'm') {
		# sub-grammar
		my $v = (&$joincode($left, $data, $subtree))[0];
		push @ret, pack('C*', BC_MUL,
				map { BC($_) } length($v), unpack('C*', $v));
	    } elsif ($type eq 's') {
		# symbol - corresponds to a sub-tree in the production
		if (! exists $done{$data}) {
		    $done{$data} = [&$gencode($subtree->[$data])];
		}
		push @ret, $done{$data}[0];
	    } elsif ($type eq 'c' || $type eq 'r') {
		# constant or reggrim
		my ($type, $start, $end) = @{$subtree->[$data]};
		my $const = substr($source, $start, $end - $start);
		my @v = unpack('C*', ascii2baudot($const));
		$const = pack('C*', BC_MUL, map { BC($_) } scalar(@v), @v);
		push @ret, $const;
	    } elsif ($type eq 'n') {
		# count of symbol
		if (! exists $done{$data}) {
		    $done{$data} = [&$gencode($subtree->[$data])];
		}
		my $n = $done{$data}[1];
		push @ret, pack('C*', BC($n));
	    }
	}
	my $count = 0;
	for (my $np = 0; $np < @$left; $np++) {
	    my $lc = $left->[$np][2];
	    if ($lc == 0xffff) {
		if (! exists $done{$np}) {
		    $done{$np} = [&$gencode($subtree->[$np])];
		}
		$count += $done{$np}[1];
	    } else {
		$count += $lc;
	    }
	}
	return (join('', @ret), $count);
    };
    return (&$gencode($firstlevel))[0];
}

sub validate {
    @_ == 2 or croak "Usage: PARSETREE->validate(GRAMMAR)";
    my ($tree, $new_grammar) = @_;
    my ($source, $old_grammar, $start, $end, $prod) = @$tree;
    # if this is a predefined symbol, we haven't changed it!
    return 1 if $prod->[0] <= @predefined_symbols;
    # we can only work if they are using the same grammar, although they
    # might have modified it
    return 0 if $old_grammar != $new_grammar;
    # anything else is still valid if the corresponding production has
    # not been deleted and if it did not use "JUNK" (implicit comment)
    my @stack = ($prod);
    my $prods = $new_grammar->{productions};
    while (@stack) {
	my $top = pop @stack;
	my ($symbol, $prodnum, $prod, @subtree) = @$top;
	# the production might have moved, in which case we need to adjust
	# prodnum - or, if it has been removed, mark the tree as invalid
	if ($prod != $prods->[$symbol][$prodnum]) {
	    $prodnum = 0;
	    my $p = $prods->[$symbol];
	    $prodnum++ while $prodnum < @$p && $prod != $p->[$prodnum];
	    # did we find anything?
	    return 0 if $prodnum >= @$p || $prod != $p->[$prodnum];
	    $top->[1] = $prodnum;
	}
	# if we are here, we need to check any sub-production being invoked
	for my $elem (@subtree) {
	    # we only care about nonterminals
	    next if ref $elem->[0] || $elem->[0] == 0;
	    # if it's predefined, we only care about comments, and then
	    # only if there has been anything new...
	    if ($elem->[0] <= @predefined_symbols) {
		next if ! $elem->[1];
		# TODO - this is correct, but over-reacting; if we have NOT
		# TODO - added anything which might invalidate this, we
		# TODO - might as well do "next" instead of "return 0"
		return 0;
	    } else {
		push @stack, $elem;
	    }
	}
    }
    return 1;
}

1;

