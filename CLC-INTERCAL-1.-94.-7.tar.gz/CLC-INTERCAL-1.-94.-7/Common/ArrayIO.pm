package Language::INTERCAL::ArrayIO;

# Write/read arrays

# This file is part of CLC-INTERCAL

# Copyright (c) 2002 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. The principal points are:

# * No charge can be made for distributing CLC-INTERCAL under any conditions.
#   This condition does not apply to payment of copying/distribution expenses
#   provided that no handling or other charge is added to such expenses.

# * The author cannot accept any liability whatsoever for any damage caused
#   by the software, directly or indirectly. No warranty of any kind can be
#   offered. Using the software in a way which causes any form of damage is
#   expressely prohibited.

# * In addition, the author's details shall not be entered into any mailing
#   list or public directory, without the author's written permission.

# * CLC-INTERCAL can be redistributed only under an identical licence
#   agreement. Any modified or derived work must also be covered by the
#   same identical agreement as the original work.

# See the file "licence.iacc" in the software installation directory (or the
# distribution, if the software has not been installed) for a full licence
# agreement. Please note that, this being an INTERCAL licence agreement, you
# must submit a text file to "licence.iacc", which will agree to it only if
# the text file happened to contain the correct licence agreement. See the
# README file in the distribution for more details.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/ArrayIO.pm 1.-94.-8";

use Carp;

use constant MAX_STASH => 15;

use Language::INTERCAL::Exporter '1.-94.-8';

use Language::INTERCAL::Charset::Baudot '1.-94.-8',
	qw(baudot2ascii ascii2baudot);

use vars qw(@EXPORT @EXPORT_OK %EXPORT_TAGS);

@EXPORT = ();
@EXPORT_OK = qw(iotype_default iotype
		write_array_16 read_array_16
		write_array_32 read_array_32);
%EXPORT_TAGS = ();

my @iotypes;
my %iotypes;

BEGIN {
    @iotypes = (
	[CLC  => \&_ra_clc_16,  \&_ra_clc_32,  \&_wa_clc_16,  \&_wa_clc_32],
	[C    => \&_ra_c,       \&_ra_c,       \&_wa_c,       \&_wa_c],
    );
    %iotypes = map { ($iotypes[$_ - 1][0] => $_) } (1..@iotypes);
}

use constant iotype_default => $iotypes{CLC};

sub iotype {
    @_ == 1 or croak "Usage: iotype(IOTYPE)";
    my ($iotype) = @_;
    $iotype =~ s/\s+//g;
    if ($iotype =~ /^\d+$/) {
	return $iotypes{CLC} if $iotype == 0;
	return undef if $iotype < 1 || $iotype > @iotypes;
	return $iotype;
    } else {
	return undef if ! exists $iotypes{uc($iotype)};
	return $iotypes{uc($iotype)};
    }
}

sub read_array_16 {
    @_ == 5 or croak
	'Usage: read_array_16(IOTYPE, IOVALUE, FILEHANDLE, \@VALUES, NL';
    my ($iotype, $iovalue, $fh, $values, $nl) = @_;
    my $iocode = iotype($iotype) or croak "Unknown i/o type: $iotype";
    &{$iotypes[$iocode - 1][1]}($iovalue, $values, $fh, $nl);
}

sub read_array_32 {
    @_ == 5 or croak
	'Usage: read_array_32(IOTYPE, IOVALUE, FILEHANDLE, \@VALUES, NL';
    my ($iotype, $iovalue, $fh, $values, $nl) = @_;
    my $iocode = iotype($iotype) or croak "Unknown i/o type: $iotype";
    &{$iotypes[$iocode - 1][2]}($iovalue, $values, $fh, $nl);
}

sub _ra_c {
    my ($iovalue, $values, $fh, $nl) = @_;
    my $tape_pos = $$iovalue;
    my @v = ();
    for my $value (@$values) {
	$tape_pos = ($tape_pos + 256 - ($value & 0xff)) & 0xff;
	my $v = $tape_pos;
	$v = (($v & 0x0f) << 4) | (($v & 0xf0) >> 4);
	$v = (($v & 0x33) << 2) | (($v & 0xcc) >> 2);
	$v = (($v & 0x55) << 1) | (($v & 0xaa) >> 1);
	push @v, $v;
    }
    $$iovalue = $tape_pos;
    $fh->read_binary(pack("C*", @v));
}

sub _ra_clc_16 {
    my ($iovalue, $values, $fh, $nl) = @_;
    my $value = pack("C*", grep { $_ > 0 } @$values);
    $fh->read_text(baudot2ascii($value) . ($nl ? "\n" : ''));
}

sub _ra_clc_32 {
    my ($iovalue, $values, $fh, $nl) = @_;
    my $line = '';
    my $io = 172;
    for my $value (@$values) {
	next if ! $value;
	my $val0 = $value;
	my $bits0 = 0;
	my $bits1 = 0;
	my $i;
	for ($i = 0; $i < 8; $i++) {
	    $bits0 >>= 1;
	    $bits1 >>= 1;
	    $bits0 |= 0x80 if $val0 & 2;
	    $bits1 |= 0x80 if $val0 & 1;
	    $val0 >>= 2;
	}
	$val0 = 0;
	for ($i = 0; $i < 8; $i++) {
	    $val0 >>= 1;
	    if ($io & 1) {
		$val0 |= 0x80 if $bits0 & 1;
		$bits0 >>= 1;
	    } else {
		$val0 |= 0x80 if ! ($bits1 & 1);
		$bits1 >>= 1;
	    }
	    $io >>= 1;
	}
	$line .= chr($val0);
	$io = $val0;
    }
    $fh->read_binary($line);
}

sub write_array_16 {
    @_ == 4 or croak 'Usage: write_array_16(IOTYPE, IOVALUE, FILEHANDLE, SIZE';
    my ($iotype, $iovalue, $fh, $size) = @_;
    my $iocode = iotype($iotype) or croak "Unknown i/o type: $iotype";
    &{$iotypes[$iocode - 1][3]}($iovalue, $fh, $size);
}

sub write_array_32 {
    @_ == 4 or croak 'Usage: write_array_32(IOTYPE, IOVALUE, FILEHANDLE, SIZE';
    my ($iotype, $iovalue, $fh, $size) = @_;
    my $iocode = iotype($iotype) or croak "Unknown i/o type: $iotype";
    &{$iotypes[$iocode - 1][4]}($iovalue, $fh, $size);
}

sub _wa_c {
    my ($iovalue, $fh, $size) = @_;
    my $line = $fh->write_binary($size);
    my @values = unpack("C*", $line);
    my $tape_pos = $$iovalue;
    for my $chr (@values) {
	my $c = $chr;
	$chr = (256 + $chr - $tape_pos) & 0xff;
	$tape_pos = $c;
    }
    push @values, 256 while @values < $size;
    $$iovalue = $tape_pos;
    @values;
}

sub _wa_clc_16 {
    my ($iovalue, $fh, $buffered) = @_;
    my $line = $fh->write_text();
    $line = '' if ! defined $line;
    chomp $line;
    $line = ascii2baudot($line);
    unpack("C*", $line);
}

sub _wa_clc_32 {
    my ($iovalue, $fh, $size, $buffered) = @_;
    my $line = $fh->write_binary($size);
    my @values = unpack("C*", $line);
    my $ptr = 0;
    my @val = ();
    my $io = 172;
    for my $datum (@values) {
	my $chr = $datum;
	my $chr0 = $chr;
	my $bits0 = 0;
	my $bits1 = 0;
	for (my $i = 0; $i < 8; $i++) {
	    if ($io & 0x80) {
		$bits0 <<= 1;
		$bits0 |= 1 if $chr & 0x80;
	    } else {
		$bits1 <<= 1;
		$bits1 |= 1 if ! ($chr & 0x80);
	    }
	    $chr <<= 1;
	    $io <<= 1;
	}
	$chr = int(rand 0xffff) + 1;
	for (my $i = 0; $i < 8; $i++) {
	    $chr <<= 2;
	    $chr |= 2 if $bits0 & 0x80;
	    $chr |= 1 if $bits1 & 0x80;
	    $bits0 <<= 1;
	    $bits1 <<= 1;
	}
	$datum = $chr;
	$io = $chr0;
    }
    @values;
}

1;
