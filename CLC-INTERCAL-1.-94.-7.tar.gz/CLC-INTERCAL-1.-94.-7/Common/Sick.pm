package Language::INTERCAL::Sick;

# Compiler/user interface/whatnot for CLC-INTERCAL

# This file is part of CLC-INTERCAL 1.-94.-8

# Copyright (c) 2002 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. The principal points are:

# * No charge can be made for distributing CLC-INTERCAL under any conditions.
#   This condition does not apply to payment of copying/distribution expenses
#   provided that no handling or other charge is added to such expenses.

# * The author cannot accept any liability whatsoever for any damage caused
#   by the software, directly or indirectly. No warranty of any kind can be
#   offered. Using the software in a way which causes any form of damage is
#   expressely prohibited.

# * In addition, the author's details shall not be entered into any mailing
#   list or public directory, without the author's written permission.

# * CLC-INTERCAL can be redistributed only under an identical licence
#   agreement. Any modified or derived work must also be covered by the
#   same identical agreement as the original work.

# See the file "licence.iacc" in the software installation directory (or the
# distribution, if the software has not been installed) for a full licence
# agreement. Please note that, this being an INTERCAL licence agreement, you
# must submit a text file to "licence.iacc", which will agree to it only if
# the text file happened to contain the correct licence agreement. See the
# README file in the distribution for more details.

require 5.005;

use strict;
use Carp;
use File::Basename;
use File::Spec;

use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Sick.pm 1.-94.-8";

use Language::INTERCAL::Exporter '1.-94.-8';
use Language::INTERCAL::Charset '1.-94.-8', qw(toascii charset);
use Language::INTERCAL::GenericIO '1.-94.-8';
use Language::INTERCAL::Object '1.-94.-8', ':BREG';
use Language::INTERCAL::ByteCode '1.-94.-8', ':BC';
use Language::INTERCAL::Charset '1.-94.-8', qw(charset_name);
use Language::INTERCAL::Charset::Baudot '1.-94.-8', qw(ascii2baudot);

my @tempfiles = ();
my $tmpfile_base = ($ENV{TMPDIR} || "/tmp") . "/sick.$$.";
my $tmpfile_count = 0;
END { unlink @tempfiles }

sub new {
    @_ == 1 or croak "Usage: new Language::INTERCAL::Sick";
    my ($class) = @_;
    my @include =
	reverse grep {-d $_} map {"$_/Language/INTERCAL/Include"} @INC;
    bless {
	object_option => {
	    include            => \@include,
	    preload            => [],
	    postload           => [],
	    suffix             => '',
	    charset            => '',
	    optimise           => 0,
	    backend            => '',
	    bug                => 655,
	    ubug               => 6,
	    output             => '%p.%s',
	    name               => '%o',
	    verbose            => 0,
	    trace              => 0,
	},
	shared_option => {
	    default_charset    => [],
	    default_suffix     => {},
	    default_backend    => 'Object',
	},
	sources => [],
	filepath => {},
	shared_filepath => {},
	object_cache => {},
	loaded => 0,
    }, $class;
}

my %checkoption = (
    include         => \&_check_path,
    preload         => \&_check_object,
    postload        => \&_check_object,
    charset         => \&_load_charset,
#   backend         => \&_load_backend,
    optimise        => \&_check_bool,
    bug             => \&_check_spot,
    ubug            => \&_check_spot,
    verbose         => \&_check_filehandle,
    default_charset => \&_load_charset,
    default_suffix  => \&_check_suffix,
#   default_backend => \&_load_backend,
);

sub option {
    @_ == 2 or @_ == 3 or croak "Usage: SICK->option(NAME [, VALUE])";
    @_ == 2 ? shift->getoption(@_) : shift->setoption(@_);
}

sub getoption {
    @_ == 2 or croak "Usage: SICK->getoption(NAME)";
    my ($sick, $name) = @_;
    my $value = exists $sick->{object_option}{$name}
	? $sick->{object_option}{$name}
	: exists $sick->{shared_option}{$name}
	    ? $sick->{shared_option}{$name}
	    : die "Unknown option $name\n";
    return $value unless ref $value;
    return $value if UNIVERSAL::isa($value, 'Language::INTERCAL::GenericIO');
    return @$value if 'ARRAY' eq ref $value;
    return map { ($_ => [@{$value->{$_}}]) } keys %$value
	if 'HASH' eq ref $value;
    return (); # should never get here
}

sub setoption {
    @_ == 3 or croak "Usage: SICK->setoption(NAME, VALUE)";
    my ($sick, $name, $value) = @_;
    my $hash = exists $sick->{object_option}{$name}
	? $sick->{object_option}
	: exists $sick->{shared_option}{$name}
	    ? $sick->{shared_option}
	    : die "Unknown option $name\n";
    if (exists $checkoption{$name}) {
	$value = $checkoption{$name}->($sick, $value);
    }
    if (! ref $hash->{$name}) {
	$hash->{$name} = $value;
    } elsif (UNIVERSAL::isa($value, 'Language::INTERCAL::GenericIO')) {
	$hash->{$name} = $value;
    } elsif ('ARRAY' eq ref $hash->{$name}) {
	push @{$hash->{$name}}, $value;
    } elsif ('HASH' eq ref $hash->{$name}) {
	my ($key, $as, @add) = @$value;
	if (exists $hash->{$name}{$key}) {
	    $hash->{$name}{$key}[0] = $as;
	} else {
	    $hash->{$name}{$key} = [$as];
	}
	push @{$hash->{$name}{$key}}, @add;
    } else {
	# WTF?
    }
    $sick;
}

sub clearoption {
    @_ == 2 or croak "Usage: SICK->clearoption(NAME)";
    my ($sick, $name) = @_;
    my $hash = exists $sick->{object_option}{$name}
	? $sick->{object_option}
	: exists $sick->{shared_option}{$name}
	    ? $sick->{shared_option}
	    : die "Unknown option $name\n";
    if (UNIVERSAL::isa($hash->{$name}, 'Language::INTERCAL::GenericIO')) {
	$hash->{$name} = 0;
    } elsif ('ARRAY' eq ref $hash->{$name}) {
	$hash->{$name} = [];
    } elsif ('HASH' eq ref $hash->{$name}) {
	$hash->{$name} = {};
    } else {
	die "Cannot clear option $name\n";
    }
    $sick;
}

sub alloptions {
    @_ == 1 or @_ == 2 or croak "Usage: SICK->alloptions [(shared)]";
    my ($sick, $shared) = @_;
    my %vals = ();
    my @hash = ();
    push @hash, 'object_option' if ! defined $shared || ! $shared;
    push @hash, 'shared_option' if ! defined $shared || ! $shared;
    for my $hash (@hash) {
	while (my ($name, $value) = each %{$sick->{$hash}}) {
	    if (UNIVERSAL::isa($value, 'Language::INTERCAL::GenericIO')) {
		# nothing, but we don't want to be caught in next cases
	    } elsif ('ARRAY' eq ref $value) {
		# a shallow copy will do -- we know values are strings
		$value = [ @$value ];
	    } elsif ('HASH' eq ref $value) {
		# two level deep copy: the values are arrays of strings
		my %v = ();
		while (my ($key, $val) = each %$value) {
		    $v{$key} = [ @$val ];
		}
		$value = \%v;
	    } elsif (ref $value) {
		# WTF?
		$value = undef;
	    }
	    $vals{$name} = $value;
	}
    }
    %vals;
}

sub source {
    @_ == 2 or croak "Usage: SICK->source(FILENAME)";
    my ($sick, $file) = @_;
    $file = _check_file($sick, $file);
    push @{$sick->{sources}}, {
	'source' => $file,
	'option' => { $sick->alloptions(0) }, # don't copy shared options
	'filepath' => $sick->{filepath},
    };
    $sick->{filepath} = {}; # because they might change "include"
    $sick->{loaded} = 0;
    $sick;
}

sub load_objects {
    @_ == 1 or croak "Usage: SICK->load_objects()";
    my ($sick) = @_;
    return $sick if $sick->{loaded};
    for my $object (@{$sick->{sources}}) {
	next if exists $object->{object};
	my $o = $object->{option};
	my ($obj, $fn, $base, $is_src) = _load_source($sick, $object, $o);
	$object->{is_src} = $is_src;
	$object->{base} = $base;
	$object->{object} = $obj;
	$object->{filename} = $fn;
    }
    $sick->{loaded} = 1;
    $sick;
}

sub save_objects {
    @_ == 2 or croak "Usage: SICK->save_objects(AND_KEEP?)";
    my ($sick, $keep) = @_;
    $sick->load_objects();
    for my $object (reverse @{$sick->{sources}}) {
	my $o = $object->{option};
	next unless $object->{is_src} || $o->{backend} ne 'Object';
	my $out = $o->{output};
	next if $out eq '';
	my $backend = $o->{backend};
	$backend = $sick->{shared_option}{default_backend}
	    if $backend eq '';
	my $v = $o->{verbose} ? sub {
	    my ($name) = @_;
	    if ($name eq '') {
		$o->{verbose}->read_text("Running... ");
	    } else {
		$o->{verbose}->read_text("Saving $name... ");
	    }
	} : '';
	my $orig = $object->{source};
	$orig =~ s/\.[^.]*$//;
	my %op = (
	    verbose => $v,
	    trace => $o->{trace},
	);
	$object->{object}->generate_code($backend, $o->{name},
					 $object->{base}, $out, $orig, \%op);
	$o->{verbose}->read_text("OK\n") if $o->{verbose};
	undef $object unless $keep;
    }
    $sick;
}

# private methods follow

sub _check_bool {
    my ($sick, $value) = @_;
    return $value if $value =~ /^\d+$/;
    return 1 if $value =~ /^t(?:rue)?$/i;
    return 1 if $value =~ /^y(?:es)?$/i;
    return 0 if $value =~ /^f(?:alse)?$/i;
    return 0 if $value =~ /^n(?:o)?$/i;
    die "Invalid boolean value '$value'\n";
}

sub _check_filehandle {
    my ($sick, $value) = @_;
    return $value if ref $value &&
		     UNIVERSAL::isa($value, 'Language::INTERCAL::GenericIO');
    return 0 if $value =~ /^\d+$/ && $value == 0;
    return 0 if $value =~ /^n(?:one)?$/i;
    die "Invalid filehandle value '$value'\n";
}

sub _check_path {
    my ($sick, $value) = @_;
    return $value if -d $value;
    die "Invalid path '$value'\n";
}

sub _check_spot {
    my ($sick, $value) = @_;
    die "Value '$value' is not a number\n" if $value !~ /^\d+$/;
    return $value if $value <= 0xffff;
    die "Value '$value' has too many spots\n";
}

sub _check_suffix {
    my ($sick, $value) = @_;
    my ($suffix, $as, @add) = @_;
    if (ref $value eq 'ARRAY') {
	die "Invalid value for $value (requires at least two elements)\n"
	    if @$value < 2;
	($suffix, $as, @add) = @$value;
    } else {
	die "Invalid value for $value (must be a array ref)\n";
    }
    # don't worry if they don't exist, they might not need them anyway
    [$suffix, $as, @add];
}

sub _find_file {
    my ($sick, $value, $ftype, $cache, $path) = @_;
    return $cache->{$value} if exists $cache->{$value};
    # try opening file from current directory
    if (-f $value) {
	$cache->{$value} = $value;
	return $value;
    }
    if (! File::Spec->file_name_is_absolute($value)) {
	my ($file, $dir) = fileparse($value);
	$path = $sick->{object_option}{include} if ! defined $path;
	for my $search (reverse @$path) {
	    my $n = File::Spec->catfile($search, $dir, $file);
	    $n = File::Spec->canonpath($n);
	    if (-f $n) {
		$cache->{$value} = $n;
		return $n;
	    }
	}
    }
    die "Cannot find $ftype \"$value\"\n";
}

sub _check_file {
    my ($sick, $value) = @_;
    _find_file($sick, $value, 'file',
	       $sick->{filecache},
	       $sick->{object_option}{include});
    $value;
}

sub _find_object {
    my ($sick, $value, $cache, $path) = @_;
    if ($value !~ /\.io$/) {
	# try adding suffix first
	my $v = eval {
	    _find_file($sick, $value . '.io', 'object', $cache, $path);
	};
	return $v if ! $@;
    }
    _find_file($sick, $value, 'object', $cache, $path);
}

sub _check_object {
    my ($sick, $value) = @_;
    _find_object($sick, $value,
		 $sick->{filecache},
		 $sick->{object_option}{include});
    $value;
}

sub _open_file {
    my ($sick, $source, $cache, $path) = @_;
    my $fn = _find_file($sick, $source, 'file', $cache, $path);
    my $fh = Language::INTERCAL::GenericIO->new('FILE', 'w', $fn);
    ($fn, $fh);
}

sub _load_charset {
    my ($sick, $value) = @_;
    charset_name($value);
}

sub _load_source {
    my ($sick, $source, $o) = @_;
    my ($fn, $fh) = _open_file($sick, $source->{source},
			       $source->{filepath}, $o->{include});
    $o->{verbose}->read_text("$fn... ") if $o->{verbose};
    my $base = $fn;
    my $suffix = '';
    if ($o->{suffix}) {
	$suffix = $o->{suffix};
	$suffix = '.' . $suffix if $suffix !~ /^\./;
	$base =~ s/(\.[^.]*)$//; # remove and ignore suffix
    } elsif ($base =~ s/(\.[^.]*)$//) {
	$suffix = lc($1);
    }
    # first see if it is a real object (you never know)
    my $obj = eval {
	Language::INTERCAL::Object->write_object($fh);
    };
    if (defined $obj && ref $obj) {
	$o->{verbose}->read_text("[COMPILER OBJECT]\n") if $o->{verbose};
	return ($obj, $fn, $base, 0);
    }
    # failed for whatever reason, we'll try loading as a source
    $fh->reset();
    my @preload = @{$o->{preload}};
    if (@preload) {
	# see if we need to add the optimiser
	push @preload, 'optimise'
	    if $o->{optimise} && ! grep { $_ eq 'optimise' } @preload;
    } else {
	@preload = _guess_preloads($sick, $suffix, $o);
    }
    $obj = Language::INTERCAL::Object->new();
    # preload all the required things
    for my $p (@preload) {
	next if $p eq '';
	_append_object($sick, $p, $source->{filepath}, $o, $obj);
    }
    # do we need to guess character set?
    my $chr = $o->{charset};
    if ($chr eq '') {
	$chr = _guess_charset($sick, $source->{source}, $fh);
    }
    $fh->write_charset($chr);
    $fh->reset();
    # now read file
    my $line = 1;
    my $col = 1;
    my $scount = 0;
    my $iscompiler = $obj->is_compiler();
    my $text = $fh->write_text('');
    $obj->file($fn, $text);
    $o->{verbose}->read_text("\n    " . length($text) .
			     " bytes [source object size " .
			     _object_size($obj) . " bytes] ")
	if $o->{verbose};
    for my $p (@{$o->{postload}}) {
	next if $p eq '';
	_append_object($sick, $p, $source->{filepath}, $o, $obj);
    }
    if ($o->{optimise} || $iscompiler) {
	# the optimiser works by producing a "optimised" copy of itself
	# onto its "aux" filehandle; we run it, then write the new object
	# back in
	if ($o->{verbose}) {
	    $o->{verbose}->read_text("\n    running compiler compiler... ")
		if $iscompiler;
	    $o->{verbose}->read_text("\n    running (alleged) optimiser... ")
		if ! $iscompiler;
	}
	my $tf = _create_tempfile();
	open(SAVESTDOUT, '>&STDOUT');
	open(STDOUT, "> $tf") or die "$tf: $!\n";
	$obj->trace_fh($o->{trace});
	$obj->run();
	open(STDOUT, '>&SAVESTDOUT');
	close SAVESTDOUT;
	my $th = Language::INTERCAL::GenericIO->new('FILE', 'w', $tf);
	$obj = Language::INTERCAL::Object->write_object($th);
	undef $th;
	_remove_tempfile($tf) if $tf ne '';
	$o->{verbose}->read_text("object size " .
				 _object_size($obj) .
				 " bytes ")
	    if $o->{verbose};
    }
    $o->{verbose}->read_text("\n") if $o->{verbose};
    return ($obj, $fn, $base, 1);
}

sub _append_object {
    my ($sick, $file, $cache, $o, $obj) = @_;
    my $fn = _find_object($sick, $file, $cache, $o->{include});
    $o->{verbose}->read_text("\n    [$file: $fn") if $o->{verbose};
    my ($pobj, $psize);
    if (exists $sick->{object_cache}{$fn}) {
	($pobj, $psize) = @{$sick->{object_cache}{$fn}};
	if ($o->{verbose} && ! $psize) {
	    $sick->{object_cache}{$fn}[1] = $psize = _object_size($pobj);
	}
    } else {
	my $fh = Language::INTERCAL::GenericIO->new('FILE', 'w', $fn);
	$pobj = Language::INTERCAL::Object->write_object($fh);
	$psize = $o->{verbose} ? _object_size($pobj) : 0;
	$sick->{object_cache}{$fn} = [$pobj, $psize];
    }
    $obj->append($pobj);
    $o->{verbose}->read_text(": $psize bytes] ") if $o->{verbose};
    $o->{verbose}->read_text("[COMPILER COMPILER] ")
	if $o->{verbose} && $pobj->is_compiler();
}

sub _guess_preloads {
    my ($sick, $suffix, $o) = @_;;
    # must guess preloads from suffix
    my $sd = $sick->{shared_option}{default_suffix};
    for my $try (keys %$sd) {
	my ($as, @with) = @{$sd->{$try}};
	my $regex = '';
	my $has_base = 0;
	my $name = $try;
	while ($name =~ s/^(.*?)%//) {
	    $regex .= quotemeta($1) . '([234567])?';
	    $has_base = 1;
	}
	$regex .= quotemeta($name);
	next unless $suffix =~ /^$regex$/i;
	my $base = $has_base && defined $1 ? $1 : '';
	my @preload = ();
	for my $w (@with) {
	    my $wi = $w;
	    $wi =~ s/\%/$base/g if $has_base;
	    if ($wi =~ /^\?/) {
		push @preload, substr($wi, 1)
		    if $o->{optimise};
	    } else {
		push @preload, $wi if $wi ne '';
	    }
	}
	$o->{verbose}->read_text("[" . $as . "] ") if $o->{verbose};
	return @preload;
    }
    die "Cannot guess file type\n";
}

sub _guess_charset {
    my ($sick, $source, $fh) = @_;
    my %counts = ();
    for my $name (@{$sick->{shared_option}{default_charset}}) {
	eval {
	    my $cnv = toascii($name);
	    my $count = 0;
	    while ((my $line = $fh->write_binary(4096)) ne '') {
		    my $cl = &$cnv($line);
		    $count++ while $line =~ /DO|PLEASE/ig;
	    }
	    $counts{$name} = $count;
	};
	$fh->reset();
    }
    my @counts =
	sort {$counts{$b} <=> $counts{$a}} grep {$counts{$_}} keys %counts;
    if (@counts == 0 && $fh->write_binary(1) eq '') {
	$fh->reset();
	@counts = qw(ASCII);
	$counts{ASCII} = 1;
    }
    if (! @counts || $counts{$counts[0]} < 1) {
	my $cr = $sick->{object_option}{verbose} ? "\n" : "";
	die "${cr}File \"$source\": cannot guess character set\n";
    }
    $counts[0];
}

sub _object_size {
    my ($obj) = @_;
    my $size = 0;
    my $fh = new Language::INTERCAL::GenericIO 'COUNT', 'r', \$size;
    $obj->read_object($fh);
    $size;
}

sub _create_tempfile {
    my $tf = $tmpfile_base . ++$tmpfile_count;
    push @tempfiles, $tf;
    $tf;
}

sub _remove_tempfile {
    my ($tf) = @_;
    return unless unlink $tf;
    @tempfiles = grep { $_ ne $tf } @tempfiles;
}

1
