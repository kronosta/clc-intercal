package Language::INTERCAL::Interface::None;

# pseudo user interface which never enters interactive mode

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Interface/None.pm 1.-94.-6";

use Carp;

use Language::INTERCAL::Exporter '1.-94.-6';

sub new {
    @_ == 1 or croak "Usage: Language::INTERCAL::Interface::None->new";
    my ($class) = @_;
    # I bet you never say an object implemented as blessed regular expression
    bless qr/^/, $class;
}

sub is_interactive { 0 }

sub run {
    croak "Non interactive interface should never enter run()";
}

1;
