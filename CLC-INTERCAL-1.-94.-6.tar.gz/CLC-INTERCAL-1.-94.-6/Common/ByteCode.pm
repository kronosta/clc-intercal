package Language::INTERCAL::ByteCode;

# Definitions of bytecode symbols etc

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/ByteCode.pm 1.-94.-6";

use Carp;

use Language::INTERCAL::Exporter '1.-94.-6';
use Language::INTERCAL::Splats '1.-94.-6', qw(:SP);
use Language::INTERCAL::Numbers '1.-94.-6';

use vars qw(@EXPORT @EXPORT_OK %EXPORT_TAGS);

use constant BYTE_SIZE     => 8;      # number of bits per byte (must be >= 6)
use constant NUM_OPCODES   => 0x40;   # number of virtual opcodes
use constant OPCODE_RANGE  => 1 << BYTE_SIZE;
use constant BC_MASK       => OPCODE_RANGE - 1;
use constant BIGNUM_SHIFT  => BYTE_SIZE - 1;
use constant BIGNUM_RANGE  => 1 << BIGNUM_SHIFT;
use constant BIGNUM_MASK   => (BIGNUM_RANGE - 1) << 1;
use constant BYTE_SHIFT    => OPCODE_RANGE - NUM_OPCODES;

use vars qw(%special_registers %bytecodes %bytedecode %bytedesc);

BEGIN {
    @EXPORT = ();
    @EXPORT_OK = qw(bytecode bytedecode bc_list BC unBC
		    BC_MASK BC_constants is_constant is_multibyte);
    %EXPORT_TAGS = (BC => [qw(BC unBC BC_MASK)]);

    my @bytecodes = (
	SPO => 0x00, 'SPOt',
	TSP => 0x01, 'Two SPot',
	TAI => 0x02, 'TAIl',
	HYB => 0x03, 'HYBrid',
	WHP => 0x04, 'WHirlPool',
	DOS => 0x05, 'Double-Oh-Seven',
	SHF => 0x06, 'SHark Fin',
	HCF => 0x07, 'Halt and Catch Fire',
	INT => 0x08, 'INTerleave',
	SEL => 0x09, 'SELect',
	CFR => 0x0a, 'Come FRom',
	ROU => 0x0b, 'Read OUt',
	ENC => 0x0c, 'ENCode',
	BUT => 0x0d, 'unary BUT',
	AWC => 0x0e, 'unary Add Without Carry',
	SWB => 0x0f, 'unary Subtract Without Borrow',
	STO => 0x10, 'STOre',
	WIN => 0x11, 'Write IN',
	SPL => 0x12, 'SPLat',
	SUB => 0x13, 'SUBscript',
	MUL => 0x14, 'MULtiple number (e.g. #1 BY #2 BY #3)',
	COM => 0x15, 'COMment',
	IGN => 0x16, 'IGNore register',
	ENS => 0x17, 'ENSlave',
	LAB => 0x18, 'LABel',
	CLO => 0x19, 'CLOne',
	SKI => 0x1a, 'SKIp',
	ABS => 0x1b, 'ABStain',
	FRE => 0x1c, 'FREe',
	RET => 0x1d, 'RETrieve',
	CTY => 0x1e, 'Compare TYpe',
	IND => 0x1f, 'INDirect register',
	OWN => 0x20, 'OWNer',
	TYP => 0x21, 'register TYPe',
	OVR => 0x22, 'OVerload Register',
	RAF => 0x23, 'RAndom Fire',
	OVM => 0x24, 'OVereload Many',
	DIV => 0x25, 'DIVersion',
	AST => 0x26, 'Alter and STash',
	FLA => 0x27, 'Find LAbel',
	CLA => 0x28, 'CLAss',
	LEC => 0x29, 'LECture',
	ENR => 0x2a, 'ENRol',
	GRA => 0x2b, 'GRAduate',
	LCL => 0x2c, 'Lecture\'s CLass',
	CAR => 0x2d, 'Create ARray',
	SCH => 0x2e, 'SCHedule',
	GCO => 0x2f, 'Generate COde',
	EVA => 0x30, 'Extra Vehicular Activity',
	CRE => 0x31, 'CREate',
	FIG => 0x32, 'FInd Grammar',
	DES => 0x33, 'DEStroy',
	SIN => 0x34, 'SIN against sanity',
	CON => 0x35, 'CONfess yous sins',
	BME => 0x36, 'Byte ME',
	BIG => 0x37, 'BIGnum',
	GCE => 0x38, 'Generate Code for Expression',
	XXX => 0x39, 'RESERVED OPCODE',
	CFS => 0x3a, 'ConFesS',
	FCO => 0x3b, 'Force COmpilation',
	BUG => 0x3c, 'compiler BUG',
	RSA => 0x3d, 'Like DES, only more so',
	GER => 0x3e, 'GERund',
	OPT => 0x3f, 'OPTimise',
	(map { ("#$_", $_ + NUM_OPCODES, "#$_") } (0..BYTE_SHIFT-1)),
    );

    %bytecodes = ();
    %bytedecode = ();
    %bytedesc = ();
    my @bc_list = ();
    while (@bytecodes > 2) {
	my $bc = shift @bytecodes;
	my $value = shift @bytecodes;
	my $desc = shift @bytecodes;
	$bc = uc($bc);
	die "Duplicate bytecode value ($value)" if exists $bytedecode{$value};
	$bytedecode{$value} = $bc;
	$bytedesc{$value} = $desc;
	die "Duplicate bytecode name ($bc)" if exists $bytecodes{$bc};
	$bytecodes{$bc} = $value;
	if ($bc =~ s/#//g) {
	    die "Duplicate bytecode name ($bc)" if exists $bytecodes{$bc};
	    $bytecodes{$bc} = $value;
	}
	push @bc_list, $bc;
	my $name = "BC_$bc";
	push @{$EXPORT_TAGS{BC}}, $name;
	push @EXPORT_OK, $name;
	no strict 'refs';
	*{$name} = sub () { $value };
    }
    die "Internal error" if @bytecodes;
    *bc_list = sub () { @bc_list };
}

sub bytecode ($) {
    $bytecodes{$_[0]} || 0;
}

sub bytedecode ($) {
    my ($b) = @_;
    wantarray ? ($bytedecode{$b} || 0, $bytedesc{$b} || '???')
	      : $bytedecode{$b} || 0;
}

sub BC {
    @_ == 1 || @_ == 2 || croak "Usage: BC(value [, large])";
    my ($val, $large) = (@_, 0);
    croak "Invalid undefined value" unless defined $val;
    if ($val < BYTE_SHIFT && ! $large) {
	return $val + NUM_OPCODES;
    }
    my @code = ($val < 0x10000 && ! $large ? BC_BME : BC_BIG);
    $val -= BYTE_SHIFT;
    while ($val >= BIGNUM_RANGE) {
	push @code, (($val << 1) & BIGNUM_MASK) | 1;
	$val >>= BIGNUM_SHIFT;
    }
    push @code, $val << 1;
    @code;
}

sub unBC {
    my ($code, $cp) = @_;
    if ($$cp >= length($code)) {
	faint(SP_INVALID, "???? unBC");
    }
    my $byte = ord(substr($code, $$cp, 1));
    $$cp++;
    if ($byte >= NUM_OPCODES) {
	return new Language::INTERCAL::Numbers $byte - NUM_OPCODES, 16;
    } elsif ($byte == BC_BIG || $byte == BC_BME) {
	my $val = BYTE_SHIFT;
	my $shift = 0;
	my ($numbits, $nummask, $faint, $splat) =
	    $byte == BC_BME ? (16, 0xffff, 'byte_me', SP_TWOSPOT)
			    : (32, 0xffffffff, 'bignum', SP_TOOMANYSPOTS);
	while (1) {
	    if ($$cp >= length($code)) {
		faint(SP_INVALID, "???? unBC/$faint");
	    }
	    my $v = ord(substr($code, $$cp, 1));
	    $$cp++;
	    my $go = $v & 0x01;
	    $v &= BIGNUM_MASK;
	    $v >>= 1;
	    faint($splat, $faint, "$v<<$shift") if $shift >= $numbits;
	    my $w = ($v << $shift) & $nummask;
	    faint($splat, $faint, "$v<<$shift") if ($w >> $shift) != $v;
	    $val += $w;
	    return new Language::INTERCAL::Numbers $val, $numbits if $go == 0;
	    $shift += BIGNUM_SHIFT;
	}
    } else {
	faint(SP_INVALID, sprintf("0x%02x", $byte), "unBC");
    }
}

sub BC_constants () {
    (NUM_OPCODES..BC_MASK);
}

sub is_constant ($) {
    my ($byte) = @_;
    $byte == BC_BME || $byte == BC_BIG || $byte >= NUM_OPCODES;
}

sub is_multibyte ($) {
    my ($byte) = @_;
    $byte == BC_BME || $byte == BC_BIG;
}

1;
__END__

=pod

=head1 TITLE

Language::INTERCAL::Bytecode - definitions for the ICBM

=head1 DESCRIPTION

The ICBM (B<I>NTERCAL B<C>ommon B<B>ytecode B<M>angler) is the part of
CLC-INTERCAL which defines the INTERCAL virtual machine, that is the
execution environment for INTERCAL programs.

The ICBM consists of a just-too-late compiler and a bytecode interpreter.
The actual compiler is largely user-specified in the form of a compiler
compiler, which runs to translate user programs to executable bytecode.
To compile a compiler compiler into bytecode, you use a compiler compiler
compiler, which would need to be compiled by a compiler compiler compiler
compiler and so on to infinity. To simplify the programmer's life (eh?),
the compiler compiler is able to compile itself, and is therefore identical
to the compiler compiler compiler (and also to the compiler compiler compiler
compiler and so on to infinity).

What the above means, is that you have been provided with a suite of
compilers, all written in executable bytecode. A compiler compiler is
able to compile itself and all the other compiler, so it is possible to
distribute all compilers in source form except for the one needed to
compile the rest. After this step, it also recompiles itself just to
prove that it can do it.

This document describes the bytecode used by all user programs, compilers,
and the compiler compiler. Other documentation, if and when it will be
written, describes the compilation process in more detail.

A program, in its executable form, consists of a list of statements. Each
statement can contain source code, executable bytecode, or both. If executable
bytecode is not present, an exception is generated which causes the compiler
to step in and attempt to compile the source code. This document assumes that
this step has been performed, and therefore a program (or a compiler) is a
list of statements, each one consisting of executable bytecode.

Each byte in the bytecode can be part of a statement, an expression or a
register. In addition, a subset of expressions can be assigned to: these
are called assignable expressions. For example, a constant is an assignable
expression. WHen assigned to, it changes the value of the constant. This
is necessary to implement overloading and you probably will carefully avoid
to to that.

The rest of this document uses the three-letter abbreviations for bytes in
the bytecode. To see the corresponding numeric code, use:

    perl -lMLanguage::INTERCAL::ByteCode=:BC -e 'print BC_xxx'

where I<xxx> is the three letter abbreviation used in the text. To see the
one-line description type (in one line - we have separated it for clarity):

    perl -lMLanguage::INTERCAL::ByteCode=:BC,bytedecode -e 
    'print ((bytedecode(BC_xxx))[1])'

If you see the number anywhere and want to have the three-letter abbreviation
type (again, in one line):

    perl -lMLanguage::INTERCAL::ByteCode=:bytedecode -e 
    'print ((bytedecode(nnn))[1])'

or, to see both the abbreviation and the description:

    perl -lMLanguage::INTERCAL::ByteCode=:bytedecode -e 
    'print join(" - ", bytedecode(nnn))'

Your shell or command interpreter might have its own idea about the above
commands and the use of quotes, as usual.

=head2 CONSTANTS

Constants can be specified in four ways:

=over 4

=item Undecoded byte

Any byte with value greather than the maximum opcode is interpreted as a
16 bit (spot) constant by subtracting the number of opcodes from the byte.
For example, since there are 64 opcodes, byte 67 is equivalent to #3

=item Spot Constant

This is the byte I<BME> followed by other bytes. Each byte which has the low
bit set will be followed by other bytes; otherwise it will be the last
byte. The remaining seven bits are data: the first byte after I<BME> contains
the lowest seven bits, the second byte the next seven (if present), and the
third byte the remaining two, if necessary. After the number has been decoded
this way, it is added to the number of constants directly representable as
undecoded bytes, which is 192. For example, I<BME> I<42> means 213 - 42 is the
seven bit constant 21 shifted left by one bit and 21+192 is 213. Another
example: I<BME> I<15> I<255> is 16455 - the two seven bit constants are 7
and 127 and 192 + 7 + 128 * 127 is 16455.

=item Two Spot Constant

This is encoded previsely like a Spot Constant, but represents a 32 bit
value: it uses the opcode I<BIG> instead of I<BME>. and can be followed by
up to five bytes of data.

=item Register number

The opcode I<IND> followed by a register represents the register's number.
This is not always as obvious as you might think, for example, the register
can be specified using ``owner'' or other forms of indirection.

=back

The exportable function I<BC> converts a number into bytecode, returning
a list of numbers: use C<pack('C*', BC($n)> to convert a number to a
bytecode string. A second argument to I<BC> is an optional boolean which,
if present and true, specifies that the constant must be a 32 bit constant,
and will be encoded using I<BIG>. Unfortunately, doing this for values
less than 192 produces unpredictable results.

The exportable function I<unBC> converts a bytecode string to a number.
The function takes two parameters: a string and a scalar reference. The
second argument is a pointer into the string, in the sense that the
first byte to be used is C<substr($_[0], ${$_[1]}, 1)>. The index will
be updated to point to the first byte following the constant.

=head2 REGISTERS

Registers can be any number of register prefixes, followed by a type and
a constant. There are limitations in the useful combination of prefixes.

The register types are:

=over 4

=item SPO

Spot register (e.g. I<.4>)

=item TSP

Two spot register (e.g. I<:7>)

=item TAI

Tail register (e.g. I<,2>). This represents the whole array. See below for
subscripting.

=item HYB

Hybrid register (e.g. I<;9>). This represents the whole array. See below for
subscripting.

=item WHP

Whirlpool (I<@9>). This represents CLC-INTERCAL's class registers. When
used for I/O, it represents the filehandle associated with the class.

=item DOS

A special internal spot register used by the compilers (e.g. I<%2>, the
second component of the program counter).

=item SHF

A special internal tail register used by the compilers (e.g. I<^1>, the
arguments given to the program on startup)

=item TYP

Followed by any register, returns its type (one of the above types). For
example, I<TYP> I<SPO> I<136> is equivalent to I<SPO>. It can be useful
to find out the type of an indirect register, and is used to translate
CLC-INTERCAL's intersection-worm.

=item CTY

Followed by two register types, it checks that they are the same type, and
then represents that type. This is used for safe access to indirect
registers. For example, you have been given a register in I<$.1> and you need
to make sure it's an array: I<CTY> I<TAI> I<OWN> I<65> I<SPO> I<65>
I<IND> I<OWN> I<65> I<SPO> I<65>. Here I<OWN> I<65> is the first owner of
the following register, so the sequence means: get the type of I<$.1>,
make sure it's tail, and then combine it with the number of I<$.1>.

=back

In addition, a register type can be preceded by a I<DIV> and a statement
to indicate a diversion. The sequence I<DIV> B<statement> B<regtype> is
equivalent to B<regtype>, except that the B<statement> is also executed.

The prefixes which can applied to registers are:

=over 4

=item OVR

Accesses the overload register. This is a special tail register associated
with every register (incliding specials). The elements will be interpreted
as bytes in a bytecode whenever the register is used. To remove overloading,
assign 0 to the overload register.

=item OWN

Followed by an expression and a register, accesses one of the register's
owners. For example, I<OWN> I<65> I<SPO> I<66> is I<$.2> and
I<OWN> I<67> I<TSP> I<68> is I<3:4>

=item SUB

Followed by an expression and a subscriptable register (array or overload
register), it accesses the given subscript. For multidimensional arrays,
repeat as in I<SUB> I<67> I<SUB> I<68> I<TAI> I<69> for I<:5 SUB #4 SUB #3>.
Overload registers are always unidimensional, and class registers can also
be subscripted to access the subjects directly. Storing a value to a
subscripted class register will indicate the label at which the subject
is taught: it will be an error to assign a number below 1000, or
corresponding to a label which does not exist.

=back

A set of special overload registers is specified with I<OWM> followed by
one 32 bit expression. This represents the "overload many" expression and
we currently abstain from describing this.

=head2 ASSIGNABLE EXPRESSIONS

Assignable expressions are sequences of bytecode which can be stored in
an overload register if the register is going to be assigned to. Any
register is an assignable expression, provided it does not contain
diversions (this restriction might be removed in a future release).
All constants are also assignable, which makes then really variables.
Instead of describing the assignable expressions separately, we describe
normal expressions and mention which ones are assignable. Assigning to
an expression means assigning appropriate values to its subexpressions such
that the expression, if evaluated, would result in the value being assigned.
This is not always possible, so it can generate runtime errors.

=head2 EXPRESSIONS

In addition to registers and constants, the following are valid expressions:

=over 4

=item INT

FOllowed by two assignable expressions, interleaves them. Assignable

=item SEL

Followed by two expressions, it selects them. Assignable.

=item BUT

Followed by two expressions, computes the unary I<BUT> of the second
expression, preferring the value of the first - so this can also be used
for unary I<3BUT> etc. The special prevference value 7, which is invalid
for unary I<BUT>, is used to indicate unary I<AND>. Assignable.

=item AWC

Followed by one expression, it computes the unary Add without carry (or,
if the current base is 2, the exclusive or). Assignable.

=item SWB

Followed by one expression, it computes the unary subtract without borrow.
It is invalid in base 2. Assignable.

=item SPL

Returns the code of the last splat. This is only useful if the program is
quantum or threaded, otherwise it won't be executing after a splat. If
there was no splat, generates one. Assignable, but in this case it
unconditionally splats for obvioud reasons.

=item ENC

Followed by two expressions, performs an internal conversion. This is
currently undocumented. Assignable.

=item FLA

Followed by an expression, looks for a label with the given number and
returns the statement index (the value of I<%1> corresponding to the label).
Not assignable.

=item CLA

Followed by a list of subjects, finds a class teaching all them, and returns
the class number. Use I<WHP> I<CLA> I<...> to get a class register. Can
produce many errors, depending on what is currently being taught. Not
assignable.

=item LEC

Followed by a register (the student) and an expression (the subject), looks
for a lecture teaching the subject amongst the classes taken by the student.
Returns the statement index at which the lecture starts. Not assignable.

=item LCL

Like I<LEC>, except it returns the class number. Not assignable.

=item MUL

Followed by an expression (the count) and then a number of expressions,
represents a ``multiple number''. This can be used to assign to an array,
to dimension it (e.g. translating the statement C<,2 <- #3 BY #5> the
value to be assigned would be I<MUL> I<66> I<67> I<69>) or to provide a
list of subject to I<CLA>. Not assignable.

=item EVA

Followed by an array register (including overloads), it interprets the
contents as bytecode and executes them. Not assignable: to assign to
overloads you use normal assignment to the register being overloaded.

=item FIG

Followed by an array register, it looks up in the compiler's symbol table
the string represented by the register, and returns the symbol table index.
To obtain a string from the register, the ICBM executes a READ OUT of that
register redirecting the standard read file handle to an internal buffer.
Depending on the I/O mode in force, this might have side effects on subsequent
reads. If the symbol is not found, it is added to the table. Not assignable.

=item GCO

Followed two expressions and a register, it attempts to compile the string
in the register (see I<FIG> for information on how this is done) using the
grammar represented by the first expression (see I<CRE> under STATEMENTS,
below) and the symbol represented by the second (usually the result of I<FIG>).
Returns the code generated, as a multiple number, in a format suitable for
execution as statement. Not assignable.

=item GCE

Like I<GCO>, except that the code returned is suitable for execution as
expression. Not assignable.

=back

=head2 STATEMENTS

The following opcodes are valid statements:

=over 4

=item HCF

Terminates execution. Library modules will use this after their initialisation
to automatically proceed to the next library module or, after the last one,
to start the main program. Libraries which do not use initialisation will
insert this as first statement.

=item ABS

Signals that this statement is initially abstained from. A statement might
be abstained from without containing a I<ABS>, or might contain one and not
be abstained from, depending on the I<SKI> statements executed since the
start of the program.

=item GER

Followed by an expression, indicates this statement's gerund number. It
is used to abstain/reinstate by gerund. See I<SKI> below. A future version
of the ICBM will also allow COME FROM gerunds. If COME FROM GERUNDs are
enabled, it will also be used for that case.

=item LAB

Followed by an expression, indicates this statement's label. If the
expression is nonzero, after this statement the ICBM will go looking for
corresponding I<CFR> statements (COME FROMs and NEXT FROMs). It is also
used to abstain/reinstate by label.

=item CFR

Followed by four expressions (a label, a gerund, a stash and a count) and
I<count> registers, it specifies a COME FROM or a NEXT FROM. For a COME FROM,
I<count> must be zero. For a NEXT FROM, I<count> will be 2 and the two
registers will be I<%1> and I<%2>: the stash will be the normal NEXT stash.
However, other combinations are possible (for example, to implement a LECTURE
FROM, something which even the author has resisted doing).

After a statement with the given label is executed all the registers specified
are stashed in the stash indicated, then the program jumps to the location
of the COME FROM.

If the special register I<%12> (COME FROM style) selected with 1 is nonzero,
it is acceptable to have more than one I<CFR> pointing at the same place.
If it is zero, it is a runtime error if that happens.

If the special register I<%12> selected with 2 is zero, the I<gerund> is
ignored. If if is nonzero, as selected for example by preloading
F<come-from-gerund.io>, or using the suffix I<.gi>, COME FROM GERUNDs are
enabled. The program will incur a performance penalty, but it will be
so much more elegant.

=item ROU

Followed by an expression (a count) and I<count> registers, reads them out.

=item WIN

Followed by an expression (a count) and I<count> registers, writes them in.

=item STO

Followed by an expression and a register, assigns the expression to the
register. Assigning to arrays will dimension them.

=item CAR

Followed by an expression and a register, assigns the expression to the
register. Assigning to arrays will dimension and fill them in one go.
The dimension will be set to the number of elements of the expression
(1 if the expression is not multiple).

=item COM

Followed by an expression and a register, it executes a comment, that is,
produces a splat. The expression is the splat number, and the register is
read out to produce the error message.

=item IGN

Followed by two expressions (the first one, zero to ignore or nonzero to
remember, the second a count) and I<count> registers, ignores or remembers
the registers.

=item SKI

Followed by three expressions (the first one, zero to abstain or nonzero
to reinstate, the second a gerund, the third a label), abstains from or
reinstated all the corresponding statements. The label or the gerund can
be zero to indicate that it is not used. The gerund can be a multiple
number to use many gerunds at once.

=item AST

A statement implementing lectures, NEXT and STASH, as well as many unrelated
things. Followed by two expressions (the stash number and a count) and
I<count> modifications, it modifies the registers as indicated.

Each modification starts with an expression and ends with a register. Between
them, there might be other elements, depending on the value of the expression.
All register listed are stashed before modification.

If the expression selected with 1 is nonzero, the register is assigned to.
In this case, a second expression will specify the new value.

If the expression selected with 2 is nonzero, the register is enslaved.
In this case, another register is specified to indicate the owner.

The order of elements in each modification is: expression, optional
new value, optional owner, register.

=item RET

Implementing RETRIEVE, RESUME, FORGET and FINISH LECTURE, it is the
opposite of I<AST>. It is followed by four expressions and many registers.
The expressions are: the stash number, the number of registers, the
number of stash elements to retrieve, and a flag indicating whether the
registers are to be assigned to or now.

To implement RETRIEVE, leave the number of stash elements to 1. To
implement RESUME, use this to specify the resume depth, and set the
assignment flag to nonzero. To implement FORGET, set the flag to zero.

=item ENS

Follower by two registers, enslaves the first to the second.

=item FRE

Follower by two registers, frees the first from the second. It is an error
to free a register from another register it was not enslaved to.

=item DIV

Diverts execution via an expression. Used to execute expressions for their
side effects, discarding the results. Not used by any of the current
compilers, but the opcode was there and is used for expressions, so why not?

=item EVA

Followed by an array register, interprets the contents as bytecode and
executes them.

=item CLO

Clones the current thread, modifying the following statement to generate
quantum bits where appropriate. For example, I<CLO> I<SKI> would
implement ABSTAIN FROM ... WHILE REINSTATING, or the equivalent
REINSTATE ... WHILE ABSTAINING. In the current version of CLC-INTERCAL,
most statements can be cloned except I<DIV>, I<RAF> and I<CLO>. Cloning
I<FCO> will not actually clone or create any quantum bits.

=item RAF

Followed by an expression (which should have value between 0 and 100), it
executes the statement with a probability indicated by the expression,
between 0% (never) and 100% (always).

=item ENR

Followed by a register and an expression, enrols the register (student) in
a class where the expression (subject) is taught.

=item GRA

Followed by a register (a student) it causes the student to graduate, that
is to drop all classes.

=item SCH

Implements loops and conditionals. It is always followed by a type (an
expression) and some more expressions. The I<type> is interpreted as
a flag (bit 0) and a count (the rest).

If I<type> is zero, it deschedules the current loop.

If I<type> is one, it is followed by two expressions: the first one is
a statement (or the code for one) and the second one a condition. The
statement is executed if and only if the condition is different from 1.

If I<count> is one or more, then it is followed by I<count> expressions
and a loop is scheduled involving I<count>-1 conditions and one body.
However, the scheduling is only done if the I<flag> is zero.

If I<count> is two, it schedules a DO STATEMENT WHILE STATEMENT loop:
the "body" is represented by the expression and the "condition" follows.
To terminate the loop, use a I<SCH> with I<count> of zero.

If I<count> is three, it schedules a DO STATEMENT WHILE EXPRESSION loop.
Here, the first expression following the I<count> is the "condition" and
the other expression is the "body". The "body" will likely unschedule
itself by using I<SCH> with a I<count> of zero when it gets triggered:
this is the normal way such loops are implemented in CLC-INTERCAL.

Other values for I<count> are possible, indicating loops which cannot
be expressed in INTERCAL.

=item SIN

We are abstaining from documenting this statement at the present time.

=item CFS

We are abstaining from documenting this statement at the present time.

=item CON

We are abstaining from documenting this statement at the present time.

=item CRE

Followed by two expressions and a grammar production, modifies the compiler.
The first expression indicates which compiler to modify. Usually, compiler
#1 is the one used to compile user programs, and compiler #2 is the one
used to compile itself and compiler #1, but this can be changed at runtime.

The second expression is a symbol (which can involve the expressioin I<FIG>
to use symbol names instead of numbers).

The grammar is specified in a currently undocumented format.

=item DES

The opposite of I<CRE>. Takes two expression and just the left half of the
grammar production. Removes the corresponding bit of the compiler.

=item RSA

Destroys entire compilers. Followed by a count, a number of expressions,
anotehr count, and more expressions. The first list of expressions will
be twice as many as indicated by the first count, and will be intended
as pairs: from, to. All the compilers indicated by ``to'' are eliminated,
and replaced with the ones indicated by the corresponding ``from''.
The second list of expressions indicates compilers which are eliminated
without replacing them. It can be used by the optimiser to eliminate the
compiler compiler. It is also used by the compiler compiler to recompile
itself and then replace itself with the new compiler compiler just built.

=item OPT

Followed by three expressions, adds a rule to the one of theoptimisers.
None of the optimisers is currently implemented, so this has really no effect.
The first expression represents which optimiser to extend, and the next two
are optimiser-dependent, and still undefined, ways of extending it.

=item FCO

Forces compilation of the program. This does not change the semantics, and
won't make it execute faster. In fact, it will compile statements which
would not be executed, so it normally takes longer. However, it is possible
to confess after executing an I<FCO> to create a new object which is likely
to start up fater, and execute in less time, at the cost of a longer
execution this time.

=back

=head1 SEE ALSO

A qualified psychiatrist

=head1 AUTHOR

Claudio Calvelli (author's address: PO Box 666 Edinburgh EH7 RYW Scotland)

