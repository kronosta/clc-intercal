package Language::INTERCAL::GenericIO;

# Write/read data

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/GenericIO.pm 1.-94.-6";

use Carp;
use Cwd;
use File::Spec;
use IO::Handle;
use IO::File;

use constant MAX_STASH => 15;

use Language::INTERCAL::Exporter '1.-94.-6';
use Language::INTERCAL::Charset '1.-94.-6', qw(toascii fromascii);

use vars qw(@EXPORT @EXPORT_OK @EXPORT_TAGS
	    $stdread $stdwrite $stdsplat $devnull);

@EXPORT = ();
@EXPORT_OK = qw($stdread $stdwrite $stdsplat $devnull);
@EXPORT_TAGS = (files => [qw($stdread $stdwrite $stdsplat $devnull)]);

$stdread = new Language::INTERCAL::GenericIO('FILE', 'r', '-');
$stdwrite = new Language::INTERCAL::GenericIO('FILE', 'w', '-');
$stdsplat = new Language::INTERCAL::GenericIO('FILE', 'r', '-2');
$devnull = new Language::INTERCAL::GenericIO('TEE', 'r', []);

sub new {
    @_ == 4 or croak
	"Usage: new Language::INTERCAL::GenericIO(TYPE, MODE, DATA)";
    my ($class, $type, $mode, $data) = @_;
    $mode =~ /^[rwa]\+?$/ or croak "Invalid mode \"$mode\"";
    $type = uc($type);
    my $filemode = $mode;
    $filemode =~ tr/rw/wr/;
    my %object = (
	type => $type,
	mode => $mode,
	data => $data,
	buffer => '',
	read_convert => sub { shift },
	write_convert => sub { shift },
	write_charset => 'ASCII',
	text_newline => "\n",
    );
    if ($type eq 'FILE' || $type eq 'UFILE') {
	my $fh;
	if ($data eq '-' || $data eq '-1') {
	    $fh = $mode =~ /r/ ? \*STDOUT : \*STDIN;
	} elsif ($data eq '-2') {
	    $fh = \*STDERR;
	} else {
	    # need absolute paths for use with checkpoint/restart; if
	    # File::Spec is too old and can't do it, tough
	    if (File::Spec->can('rel2abs')) {
		$data = File::Spec->rel2abs($data);
	    }
	    $fh = new IO::File($data, $filemode) or die "$data: $!\n";
	    # $fh->autoflush(1);
	    $object{close_code} = sub { close $fh };
	}
	croak "Cannot open $data: $!" if ! defined $fh;
	if ($type eq 'FILE') {
	    $object{read_code} = sub { print $fh $_[0] };
	    $object{write_code} = sub {
		my $b = '';
		read $fh, $b, $_[0];
		$b;
	    };
	    $object{tell_code} = sub { tell $fh };
	    $object{seek_code} = sub { seek $fh, $_[0], 0 };
	} else {
	    $object{read_code} = sub {
		my ($line) = @_;
		syswrite $fh, $line, length($line);
	    };
	    $object{write_code} = sub {
		my ($size) = @_;
		my $b = '';
		sysread $fh, $b, $size;
		$b;
	    };
	    $object{tell_code} = sub { sysseek $fh, 0, 1 };
	    $object{seek_code} = sub { sysseek $fh, $_[0], 0 };
	}
    } elsif ($type eq 'TEE') {
	$mode =~ /[ar]/ or croak "MODE must be \"read\" when TYPE is TEE";
	ref $data && 'ARRAY' eq ref $data or croak "DATA must be a array ref";
	$object{read_code} = sub {
	    my ($line) = @_;
	    for (@$data) { $_->read_binary($line) }
	};
    } elsif ($type eq 'ARRAY') {
	ref $data && 'ARRAY' eq ref $data or croak "DATA must be a array ref";
	my @read = ();
	$object{read_data} = \@read;
	$object{read_code} = sub {
	    my ($line) = @_;
	    push @read, $line;
	};
	$object{write_code} = sub {
	    my ($size) = @_;
	    return '' unless @$data;
	    my $line = shift @$data;
	    while (@$data && length($line) < $size) {
		$line .= shift @$data;
	    }
	    if (length($line) > $size) {
		unshift @$data, substr($line, $size);
		$line = substr($line, 0, $size);
	    }
	    $line;
	};
    } elsif ($type eq 'STRING') {
	ref $data && 'SCALAR' eq ref $data or croak "DATA must be a scalar ref";
	my $read = '';
	$object{read_data} = \$read;
	$object{read_code} = sub {
	    my ($line) = @_;
	    $read .= $line;
	};
	$object{write_code} = sub {
	    my ($size) = @_;
	    substr($$data, 0, $size, '');
	};
    } elsif ($type eq 'OBJECT') {
	my ($object, $module);
	ref $data or croak "DATA must be a reference";
	if (ref($data) =~ /^Language::INTERCAL::/) {
	    $object = $data;
	    $module = undef;
	} elsif (ref $data eq 'ARRAY' && @$data == 2) {
	    ($module, $object) = @$data;
	    $module =~ /^\d+$/ or croak "DATA[0] must be a number";
	    ref $object && ref $object =~ /^Language::INTERCAL::/
		or croak "DATA[1] must be an INTERCAL object";
	} else {
	    croak "DATA must be an INTERCAL object, or a (number, object)";
	}
	my @read = ();
	$object{read_code} = sub {
	    my ($line) = @_;
	    my $reg = $object->string2reg($line);
	    $object->call($module, 3, {',3' => $reg});
	};
	$object{write_code} = sub {
	    my ($size) = @_;
	    my $str = $object->string2reg('');
	    my $int = $object->int2reg($size);
	    my $line = $object->call($module, 2, {'.2' => $int, ',2' => $str});
	    $object->reg2string($str);
	};
	$object->{module} = $module;
    } elsif ($type eq 'COUNT') {
	$mode =~ /[ar]/ or croak "MODE must be \"read\" when TYPE is COUNT";
	ref $data && 'SCALAR' eq ref $data or croak "DATA must be a scalar ref";
	$object{read_code} = sub { $$data += length($_[0]) };
	$object{read_data} = $data;
    } else {
	# TODO (1.-90) - $type eq 'LECTURE'
	croak "Invalid type \"$type\"";
    }
    bless \%object, $class;
}

sub DESTROY {
    my ($fh) = @_;
    &{$fh->{close_code}} if exists $fh->{close_code};
}

sub reset {
    @_ == 1 or croak "Usage: IO->reset";
    my ($fh) = @_;
    croak "Non seekable" unless exists $fh->{seek_code};
    &{$fh->{seek_code}}(0);
    $fh->{buffer} = '';
    $fh;
}

sub can_read {
    @_ == 1 or croak "Usage: IO->can_read";
    my ($fh) = @_;
    return exists $fh->{read_code};
}

sub read_binary {
    @_ == 2 or croak "Usage: IO->read_binary(DATA)";
    my ($fh, $string) = @_;
    croak "Filehandle not open for reading" if ! exists $fh->{read_code};
    &{$fh->{read_code}}($string);
    $fh;
}

sub read_text {
    @_ == 2 or croak "Usage: IO->read_text(DATA)";
    my ($fh, $string) = @_;
    croak "Filehandle not open for reading" if ! exists $fh->{read_code};
    $string = &{$fh->{read_convert}}($string);
    &{$fh->{read_code}}($string);
    $fh;
}

sub read_charset {
    @_ == 2 or croak "Usage: IO->read_charset(CHARSET)";
    my ($fh, $charset) = @_;
    $fh->{read_convert} = fromascii($charset);
    $fh;
}

sub read_data {
    @_ == 1 or croak "Usage: IO->read_data";
    my ($fh) = @_;
    exists $fh->{read_data} or croak "Filehandle not open for local reading";
    $fh->{read_data};
}

sub read_filehandle {
    @_ == 2 or croak "Usage: IO->read_filehandle(FILEHANDLE)";
    my ($fh, $read) = @_;
    my $type = $read->{type};
    my $mode = $read->{mode};
    my $data = $read->{data};
    $fh->read_binary(pack("va*va*", length($type), $type,
				    length($mode), $mode));
    if ($type eq 'FILE' || $type eq 'UFILE') {
	$fh->read_binary(pack("va*", length($data), $data));
	if ($type eq 'UFILE') {
	    my $b = $read->{buffer};
	    $fh->read_binary(pack("va*", length($b), $b));
	}
	$fh->read_binary(pack('V', &{$read->{tell_code}}));
    } elsif ($type eq 'TEE') {
	$fh->read_binary(pack('v', scalar(@$data)));
	for my $d (@$data) {
	    $fh->read_filehandle($d);
	}
    } elsif ($type eq 'ARRAY') {
	my $rdata = $read->{read_data};
	$fh->read_binary(pack('v', scalar(@$rdata)));
	for my $d (@$rdata) {
	    $fh->read_binary(pack('va*', length($d), $d));
	}
	$fh->read_binary(pack('v', scalar(@$data)));
	for my $d (@$data) {
	    $fh->read_binary(pack('va*', length($d), $d));
	}
    } elsif ($type eq 'STRING') {
	my $rdata = $read->{read_data};
	$fh->read_binary(pack('va*', length($rdata), $rdata));
	$fh->read_binary(pack('va*', length($data), $data));
    } elsif ($type eq 'OBJECT') {
	if (defined $fh->{module}) {
	    $fh->read_binary(pack('Cv', 1, $fh->{module}));
	} else {
	    $fh->read_binary(pack('C', 0));
	}
    } elsif ($type eq 'COUNT') {
	$fh->read_binary(pack('v', $$data));
    }
    # TODO (1.-90) - $type eq 'LECTURE'
    $fh;
}

sub describe {
    @_ == 1 or croak "Usage: IO->describe";
    my ($fh) = @_;
    my $type = $fh->{type};
    my $mode = $fh->{mode};
    my $data = $fh->{data};
    if ($type eq 'FILE' || $type eq 'UFILE') {
	return "FILE($mode, $data)";
    } elsif ($type eq 'TEE') {
	return "TEE(" . join(',', map { describe($_) } @$data) . ")";
    } elsif ($type eq 'ARRAY' || $type eq 'STRING' || $type eq 'OBJECT') {
	return $type;
    } elsif ($type eq 'COUNT') {
	return "COUNT($$data)";
    }
    # TODO (1.-90) - $type eq 'LECTURE'
    $fh;
}

sub can_write {
    @_ == 1 or croak "Usage: IO->can_write";
    my ($fh) = @_;
    return exists $fh->{write_code};
}

sub write_binary {
    @_ == 2 or croak "Usage: IO->write_binary(SIZE)";
    my ($fh, $size) = @_;
    croak "Filehandle not open for writing"
	if ! exists $fh->{write_code};
    if (length($fh->{buffer}) >= $size) {
	return substr($fh->{buffer}, 0, $size, '');
    }
    my $data = '';
    if ($fh->{buffer} ne '') {
	$data = $fh->{buffer};
	$fh->{buffer} = '';
    }
    $data . &{$fh->{write_code}}($size - length($data));
}

sub write_text {
    @_ == 1 or @_ == 2 or croak "Usage: IO->write_text [(NEWLINE)]";
    my ($fh, $newline) = @_;
    croak "Filehandle not open for writing"
	if ! exists $fh->{write_code};
    if (defined $newline) {
	if ($newline ne '') {
	    eval { $newline = &{ fromascii($fh->{write_charset}) }($newline) };
	    $newline = "\n" if $@;
	}
    } else {
	$newline = $fh->{text_newline};
    }
    my $nlpos = $newline eq '' ? -1 : index $fh->{buffer}, $newline;
    while ($nlpos < 0) {
	my $data = &{$fh->{write_code}}(1024);
	last if $data eq '';
	$fh->{buffer} .= $data;
	$nlpos = $newline eq '' ? -1 : index $fh->{buffer}, $newline;
    }
    if ($nlpos < 0) {
	$nlpos = length($fh->{buffer});
    } else {
	$nlpos += length($newline);
    }
    my $line = substr($fh->{buffer}, 0, $nlpos, '');
    &{$fh->{write_convert}}($line);
}

sub write_charset {
    @_ == 2 or croak "Usage: IO->write_charset(CHARSET)";
    my ($fh, $charset) = @_;
    $fh->{write_charset} = $charset;
    $fh->{write_convert} = toascii($charset);
    eval { $fh->{text_newline} = &{ fromascii($charset) }("\n") };
    $fh->{text_newline} = "\n" if $@;
    $fh;
}

sub write_filehandle {
    @_ == 1 or @_ == 2 or croak "Usage: IO->write_filehandle [(object)]";
    my ($fh, $object) = @_;
    my $len = unpack('v', $fh->write_binary(2));
    my $type = $fh->write_binary($len);
    $len = unpack('v', $fh->write_binary(2));
    my $mode = $fh->write_binary($len);
    my $nfh;
    if ($type eq 'FILE' || $type eq 'UFILE') {
	my $nmode = $mode;
	if ($mode =~ /^r/) {
	    # avoid truncating file when we reopen it
	    $nmode = 'w+';
	}
	$len = unpack('v', $fh->write_binary(2));
	my $data = $fh->write_binary($len);
	$nfh = new Language::INTERCAL::GenericIO($type, $nmode, $data);
	if ($type eq 'UFILE') {
	    my $len = unpack('v', $fh->write_binary(2));
	    $nfh->{buffer} = $fh->write_binary($len);
	}
	&{$nfh->{seek_code}}(unpack('V', $fh->write_binary(4)));
	$nfh->{mode} = $mode if defined $nfh;
    } elsif ($type eq 'TEE') {
	my $keys = unpack('v', $fh->write_binary(2));
	my @data = ();
	while ($keys-- > 0) {
	    push @data, $fh->write_filehandle($object);
	}
	$nfh = new Language::INTERCAL::GenericIO($type, $mode, \@data);
    } elsif ($type eq 'ARRAY') {
	my $keys = unpack('v', $fh->write_binary(2));
	my @rdata = ();
	while ($keys-- > 0) {
	    my $len = unpack('v', $fh->write_binary(2));
	    push @rdata, $fh->write_binary($len);
	}
	$keys = unpack('v', $fh->write_binary(2));
	my @data = ();
	while ($keys-- > 0) {
	    my $len = unpack('v', $fh->write_binary(2));
	    push @data, $fh->write_binary($len);
	}
	$nfh = new Language::INTERCAL::GenericIO($type, $mode, \@data);
	@{$nfh->{read_data}} = @rdata;
    } elsif ($type eq 'STRING') {
	my $len = unpack('v', $fh->write_binary(2));
	my $rdata = $fh->write_binary($len);
	$len = unpack('v', $fh->write_binary(2));
	my $data = $fh->write_binary($len);
	$nfh = new Language::INTERCAL::GenericIO($type, $mode, \$data);
	${$nfh->{read_data}} = $rdata;
    } elsif ($type eq 'OBJECT') {
	die("AARGH\n") if ! defined $object;
	my $data = $object;
	if (unpack('C', $fh->write_binary(1))) {
	    my $mnum = unpack('C', $fh->write_binary(2));
	    $data = [$mnum, $object];
	}
	$nfh = new Language::INTERCAL::GenericIO($type, $mode, $data);
    } elsif ($type eq 'COUNT') {
	my $data = unpack('v', $fh->write_binary(2));
	$nfh = new Language::INTERCAL::GenericIO($type, $mode, \$data);
    }
    # TODO (1.-90) - $type eq 'LECTURE'
    return $nfh;
}

1;
