package Language::INTERCAL::Splats;

# Splats and error messages

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Splats.pm 1.-94.-6";

use Carp;

use Language::INTERCAL::Exporter '1.-94.-6';

use vars qw(@EXPORT @EXPORT_OK %EXPORT_TAGS);

my %splats;
my %splatbyname;

BEGIN {
    @EXPORT = ();
    @EXPORT_OK = qw(splatnumber splatname splatdescription faint);
    %EXPORT_TAGS = ();

    %splats = (
	  0 => ['COMMENT',      '%'],
	  1 => ['TODO',         'Not implemented (%)'],
	  4 => ['ROMAN',        'Unknown read type for Roman numerals: %'],
	  5 => ['SPOT',         '% must be a one spot value (got %)'],
	  8 => ['BASE',         'Base must be between 2 and 7 (got %)'],
	  9 => ['IOTYPE',       'Invalid I/O Type: %'],
	 10 => ['CHARSET',      'Invalid character set: %'],
	 15 => ['ENCODE',       'Cannot encode %'],
	 57 => ['GARBAGE',      'Extra garbage at end of %'],
	 69 => ['INVALID',      'Invalid bytecode (%) for %'],
	109 => ['NOSUCHCHAR',   'Invalid character (%) for %'],
	128 => ['JUNK',         'Cannot use JUNK in this grammar'],
	129 => ['NOSUCHLABEL',  'Could not find label %'],
	241 => ['NODIM',        'Array % not dimensioned'],
	243 => ['ISARRAY',      'Array register % used as value'],
	244 => ['ISCLASS',      'Class register % used as value'],
	245 => ['NOARRAY',      'Non-array register % used as array'],
	246 => ['NOSPACE',      'Data written in (% elements) does not ' .
			        'fit in array % (% elements)'],
	247 => ['SPECIAL',      'Attempt to modify special register %'],
	248 => ['OVERLOAD',     'Cannot % overload code'],
	249 => ['DIVERSION',    'Cannot take a diversion here'],
	250 => ['NOCLASS',      'Class register required'],
	274 => ['ONESPOT',      'Number % too large for % spot%'],
	275 => ['TWOSPOT',      'Register % cannot hold two spot value %'],
	276 => ['SUBSCRIPT',    'Invalid subscript: %'],
	277 => ['ASSIGN',       'Impossible assignment (base %): cannot find ' .
			        '#X such that %#X is #%'],
	278 => ['CONFUSION',    'Cannot share % and %'],
	315 => ['SUBVERSION',   'Program trying to subvert natural order'],
	316 => ['INDECISION',   'Cannot decide between your threads'],
	436 => ['HIDDEN',       'Register % stashed away too well'],
	456 => ['SPLAT',        'No splat'],
	458 => ['REPEATLABEL',  'Found % statements with label %'],
	511 => ['FREE',         'Register % is not a slave'],
	512 => ['NOBELONG',     'Register % does not belong to register %'],
	513 => ['NOOWNER',      'Slave % does not have % owners (just %)'],
	514 => ['OWNER',        'Invalid owner number: %'],
	533 => ['INTERLEAVE',   'Cannot interleave % and %: too many spots'],
	534 => ['DIGITS',       'Wrong number of digits for base %: %'],
	555 => ['COMEFROM',     'Multiple "COME FROM" %'],
	576 => ['NOOPTIMISER',  'No such optimiser %'],
	577 => ['OPTIMISE',     'Invalid optimisation %'],
	603 => ['CLASSWAR',     'Class war between % and %'],
	621 => ['FORGET',       'Pointless "FORGET"'],
	633 => ['FALL_OFF',     'Falling off the edge of the program'],
	634 => ['SCHEDULE',     'Internal error: loop stash corrupted'],
	664 => ['INDIGESTION',  'Program is too large'],
	665 => ['WALTZ',        'No waltzing in the streets ' .
				'(particularly diversions)'],
	666 => ['MAGIC',        'Problems with black magic: %'],
	701 => ['NONUMBER',     'Value written in is not a number: %'],
	702 => ['THREESPOT',    'Value written in is larger than two spots'],
	703 => ['TOOMANYSPOTS', 'Value % assigned to % larger than two spots'],
	774 => ['BUG',          'Compiler error'],
	775 => ['UNEXPLAINABLE','Unexplainable compiler error'],
	797 => ['CLASSIO',      'Class @% cannot be used for %ing'],
	798 => ['IGNORANCE',    'Cannot find class @%'],
	799 => ['HOLIDAY',      'No class teaches subjects %'],
	815 => ['EVOLUTION',    'Creation not allowed: % too large'],
	816 => ['CREATION',     'CREATE statement misconfiguration'],
	817 => ['NOCREATE',     'Syntax error'],
	818 => ['CIRCULAR',     'Circular reasoning in %'],
	822 => ['NOSTUDENT',    'Register % is not a student'],
	823 => ['NOCURRICULUM', 'Subject % is not in %\'s curriculum'],
	942 => ['PURE',         'No such sin (%)'],
	997 => ['ILLEGAL',      'Illegal operator % for base %'],
	999 => ['EARLY',        'Subject #% of class % at % before 1000'],
    );

    %splatbyname = map { ( $splats{$_}[0] => $_ ) } keys %splats;

    $EXPORT_TAGS{SP} = [qw(faint)];
    for my $sp (keys %splatbyname) {
	next if $sp !~ /^\w+$/ or $sp ne uc($sp);
	my $name = "SP_$sp";
	push @{$EXPORT_TAGS{SP}}, $name;
	push @EXPORT_OK, $name;
	my $value = $splatbyname{$sp};
	no strict;
	*{$name} = sub () { $value };
    }
}

sub faint {
    @_ >= 1 or croak "Usage: faint(NUM, ARGS)";
    my $s = shift(@_) % 1000;
    my $nargs = 0;
    if (exists $splats{$s}) {
	my $desc = $splats{$s}[1];
	$nargs =  $desc =~ tr/%/%/;
    }
    die(join(' ', $s, @_) . "\n");
}

sub splatnumber {
    @_ == 1 or croak "Usage: splatnumber(SPLATNAME)";
    my $s = shift;
    exists $splatbyname{$s} ? $splatbyname{$s} : -1;
}

sub splatname {
    @_ == 1 or croak "Usage: splatname(SPLAT)";
    my $s = shift;
    exists $splats{$s} ? $splats{$s}[0] : 'UNKNOWN';
}

sub splatdescription {
    @_ == 2 or croak "Usage: splatdescription(SPLAT, CAUSE)";
    my ($s, $cause) = @_;
    return 'Unknown splat code' if ! exists $splats{$s};
    my $desc = $splats{$s}[1];
    my $places =  $desc =~ tr/%/%/;
    $cause =~ s/\s+$//;
    my @data = split(/\s+/, $cause, $places);
    push @data, '?' while @data < $places;
    $desc =~ s(%){shift @data}ge;
    $desc;
}

1;
