package Language::INTERCAL::Backend::Object;

# Back end to write object to a filehandle

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Backend/Object.pm 1.-94.-6";

use Carp;

use Language::INTERCAL::Exporter '1.-94.-6';

use constant default_suffix => 'io';
use constant default_mode => 0666; # objects are not (directly) executable

sub generate {
    @_ == 4 || @_ == 5
	or croak "Usage: BACKEND->generate(OBJECT, NAME, FILEHANDLE)";
    my ($class, $object, $name, $filehandle, $options) = @_;
    $object->read_object($filehandle);
}

1;
