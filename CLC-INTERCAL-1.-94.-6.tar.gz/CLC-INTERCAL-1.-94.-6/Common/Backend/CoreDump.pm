package Language::INTERCAL::Backend::CoreDump;

# Back end to run the object until it dumps core, then save the dump

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Backend/CoreDump.pm 1.-94.-6";

use Carp;

use Language::INTERCAL::Exporter '1.-94.-6';

use constant default_suffix => 'io';
use constant default_mode => 0666; # objects are not (directly) executable

sub generate {
    @_ == 4 || @_ == 5
	or croak "Usage: BACKEND->generate(OBJECT, NAME, FILEHANDLE)";
    my ($class, $object, $name, $filehandle, $options) = @_;
    my $savers = $object->rs_fh();
    $object->rs_fh($filehandle);
    $object->run();
    $object->rs_fh($savers);
}

1;
