package Language::INTERCAL::Backend::Perl;

# Produce a Perl executable

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Backend/Perl.pm 1.-94.-6";

use Carp;
use Config '%Config';

use Language::INTERCAL::Exporter '1.-94.-6';

use constant default_suffix => 'pl';
use constant default_mode   => 0777;

my ($V) = $PERVERSION =~ /(\S+)$/;
my $O = 'Language::INTERCAL::Object';
my $G = 'Language::INTERCAL::GenericIO';

sub generate {
    @_ == 4 || @_ == 5
	or croak "Usage: BACKEND->generate(OBJECT, NAME, FILEHANDLE)";
    my ($class, $object, $name, $filehandle, $options) = @_;
    $filehandle->read_binary(<<EOF);
$Config{startperl} -w

# Program thrown up by CLC-INTERCAL $V: read/use at your own risk

use strict;
#use bondage;
use $G '$V';
use $O '$V';

my \$data;
{ local \$/ = undef; \$data = <DATA> }
my \$ofh = $G\->new('STRING', 'w', \\\$data);
my \$obj = $O\->write_object(\$ofh);
\$obj->setargs(\\\@ARGV);
\$obj->setenv([map {"\$_=\$ENV{\$_}"} keys \%ENV]);
\$obj->run();

__DATA__
EOF
    $object->read_object($filehandle);
}

1;
