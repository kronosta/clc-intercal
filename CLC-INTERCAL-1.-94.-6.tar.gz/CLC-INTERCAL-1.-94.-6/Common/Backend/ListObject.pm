package Language::INTERCAL::Backend::ListObject;

# Produce a (non-executable) listing of an object

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Backend/ListObject.pm 1.-94.-6";

use Carp;

use Language::INTERCAL::Exporter '1.-94.-6';
use Language::INTERCAL::ByteCode '1.-94.-6',
	qw(bytedecode unBC is_constant is_multibyte);
use Language::INTERCAL::Object '1.-94.-6',
	qw(:IREG reg_list);
use Language::INTERCAL::ByteCode '1.-94.-6',
	qw(:BC);

use constant default_suffix => 'iasm';
use constant default_mode   => 0666;

my %regname = ();
for my $rname (reg_list) {
    my $rnumb = do { no strict 'refs'; &{"IREG_$rname"} };
    my $rtype = substr($rnumb, 0, 1);
    next if $rtype eq '@';
    $regname{$rnumb} = $rtype . $rname;
}

sub generate {
    @_ == 4 || @_ == 5
	or croak "Usage: BACKEND->generate(OBJECT, NAME, FILEHANDLE)";
    my ($class, $object, $name, $fh, $options) = @_;
    _generate($object, $fh, '');
}

sub _generate {
    my ($object, $fh, $indent) = @_;
    my $iplus = $indent . '    ';
    my $iplusplus = $iplus . '    ';

    my ($perversion) = $PERVERSION =~ /(\S+)$/;

    $fh->read_text("${indent}CLC-INTERCAL $perversion Object List\n\n");

    # generate a thread by thread listing of all parts of the object
    my $t = $object->{threads};
    my $f = $object->{file};
    for (my $tp = 0; $tp < @$t; $tp++) {
	my $thread = $t->[$tp];
	my $tip = ${$thread->{registers}{&IREG_IP}{value}};
	my $tcp = ${$thread->{registers}{&IREG_CP}{value}};
	$fh->read_text("${indent}THREAD $tp");
	$fh->read_text("OF " . scalar(@$t)) if @$t > 1;
	$fh->read_text(" [COMPILE=${$thread->{compile}}]");
	$fh->read_text(" [RUNNING=$thread->{running}]:\n");
	my $s = $thread->{statements};
	my $lastfile = -1;
	my $lastfptr = '';
	my $lastfpos = 0;
	for (my $sp = 1; $sp < @$s; $sp++) {
	    my $st = $s->[$sp];
	    if ($lastfile != $st->[0]) {
		$lastfile = $st->[0];
		$lastfptr = $f->[$lastfile];
		$fh->read_text("\n${iplus}FILE: $lastfptr->[0]\n");
	    }
	    if ($lastfile >= 0) {
		my $pos = $st->[1];
		$lastfpos = $st->[2];
		my $s = substr($lastfptr->[1], $pos, $lastfpos - $pos);
		$s =~ s/\s+$//;
		if ($s ne '') {
		    my $title = $iplus . 'SOURCE: ';
		    while ($s =~ s/^(.*?)\n//) {
			my $c = $1;
			1 while $c =~ s/^\t/' ' x (8 - (length($`) % 8))/e;
			$fh->read_text("$title$c\n");
			$title = ' ' x length($title);
		    }
		    if ($s ne '') {
			1 while $s =~ s/^\t/' ' x (8 - (length($`) % 8))/e;
			$fh->read_text("$title$s\n");
		    }
		}
	    }
	    if ($st->[0] >= 0 && exists $thread->{skips}[$st->[0]]{$st->[1]}) {
		$fh->read_text("${iplus}ABSTAINED FROM\n");
	    }
	    if ($st->[0] == -1 && exists $thread->{cskips}{$tip}) {
		$fh->read_text("${iplus}ABSTAINED FROM\n");
	    }
	    if ($st->[3] ne '') {
		$fh->read_text("${iplus}CODE($st->[4]) AT $sp:\n");
		_list_code($st->[3], $fh, $iplusplus . $sp . '/');
	    }
	    if ($tip == $sp) {
		$fh->read_text("${iplus}IP=$tip/$tcp\n");
	    }
	}
	# now see if there is any uncompiled source code
	if ($lastfile < 0) {
	    $lastfile = $lastfpos = 0;
	}
	while ($lastfile < @$f) {
	    if ($lastfpos >= length($f->[$lastfile][1])) {
		$lastfile++;
		$lastfpos = 0;
		next;
	    }
	    my $s = substr($f->[$lastfile][1], $lastfpos);
	    while ($s =~ s/^(.*?)\n//) {
		my $c = $1;
		$fh->read_text("${iplus}LSOURCE($lastfpos): $c\n");
		$lastfpos += length($c);
	    }
	    if ($s ne '') {
		$fh->read_text("${iplus}NSOURCE($lastfpos): $s\n");
		$lastfpos += length($s);
	    }
	    $lastfile++;
	    $lastfpos = 0;
	}
	my $r = $thread->{registers};
	my @r = sort {
	    $regname{$a} cmp $regname{$b};
	} grep { exists $regname{$_} } keys %$r;
	push @r, sort {
	    substr($a, 0, 1) cmp substr($b, 0, 1) ||
	    substr($a, 1) <=> substr($b, 1);
	} grep { ! exists $regname{$_} } keys %$r;
	my $title = "\n${iplus}REGISTERS:\n";
	for my $rname (@r) {
#	    next if exists $r->{$rname}{is_default} &&
#		    0 == (grep { exists $_->{$rname} } @{$thread->{stash}}) &&
#		    (! exists $r->{$rname}{file} || ! $r->{$rname}{file});
	    my $rn = exists $regname{$rname} ? $regname{$rname} : $rname;
	    $rn .= (' ' x (8 - length($rn))) . '=';
	    $fh->read_text($title);
	    $title = '';
	    _list_register($thread->{stash}, $rn, $rname, $r->{$rname},
			   $fh, $iplusplus);
	}
	$title = "\n${iplus}EVENTS:\n";
	for my $event (@{$thread->{loops}}) {
	    my ($body, $cond) = @$event;
	    next if @$cond == 0; # a loop, not an event
	    $fh->read_text($title);
	    $title = "\n";
	    _list_code($body, $fh, $iplusplus);
	}
	$title = "\n${iplus}LOOPS:\n";
	for my $loop (@{$thread->{loops}}) {
	    my ($body, $cond) = @$loop;
	    next if @$cond != 0; # an event, not a loop
	    $fh->read_text($title);
	    $title = "\n";
	    for my $c (@$cond) {
		$fh->read_text("${iplusplus}WHEN:\n");
		_list_code($body, $fh, $iplusplus . '    ');
	    }
	    $fh->read_text("${iplusplus}DO:\n");
	    _list_code($body, $fh, $iplusplus . '    ');
	}
	my $done_symbols = 0;
	for (my $g = 0; $g < @{$thread->{grammar}}; $g++) {
	    my $grammar = $thread->{grammar}[$g];
	    my $p = $grammar->{productions};
	    my @p = grep { $p->[$_] && @{$p->[$_]} } (1..$#$p);
	    next if @p == 0;
	    my $s = $grammar->{symbols};
	    unless ($done_symbols) {
		$done_symbols = 1;
		$fh->read_text("\n${iplus}SYMBOL TABLE:\n\n");
		for (my $sym = 1; $sym < @$s; $sym++) {
		    $fh->read_text(sprintf("%s%5d %s\n",
					   $iplusplus, $sym, $s->[$sym]));
		}
	    }
	    $fh->read_text("\n${iplus}GRAMMAR #$g:\n");
	    my @s = map {
		my $x = $_;
		$x =~ s/(\d+)/sprintf "%10d", $1/ge;
		$x;
	    } @$s;
	    @p = sort { $s[$a] cmp $s[$b] } @p;
	    for my $sym (@p) {
		my $symname = $s->[$sym];
		my $pnum = 0;
		for my $prod (@{$p->[$sym]}) {
		    $fh->read_text("${iplusplus}$symname\[$pnum] ::=");
		    my $map = $prod->[2];
		    $fh->read_text(" [" .
				   join('', sort
					    map { chr($_) }
						grep { vec($map, $_, 1) }
						     (0..(8 * length($map) - 1))) .
				   "]");
		    $map = $prod->[3];
		    $fh->read_text(" {" .
				   join(' ', sort
					     map {$s->[$_]}
						 grep { vec($map, $_, 1) }
						      (1..@$s)) .
				   "}");
		    $fh->read_text(" (can_empty)") if $prod->[4];
		    for my $elem (@{$prod->[0]}) {
			my ($type, $value, $count) = @$elem;
			if ($type eq 's') {
			    $fh->read_text(' ' . $s->[$value]);
			} elsif ($type eq 'r') {
			    my $v = $value;
			    $v =~ s/([\\\@])/\\$1/g;
			    $v =~ s/\n/\\n/g;
			    $v =~ s/\t/\\t/g;
			    $v =~ s/([\000-\037\177-\377])/
				    sprintf "\\%03o", ord($1)/ge;
			    $fh->read_text(" \@$v\@");
			} else {
			    my $v = $value;
			    $v =~ s/([\\"])/\\$1/g;
			    $v =~ s/\n/\\n/g;
			    $v =~ s/\t/\\t/g;
			    $v =~ s/([\000-\037\177-\377])/
				    sprintf "\\%03o", ord($1)/ge;
			    $fh->read_text(" \"$v\"");
			}
			if ($count == 0xffff) {
			    $fh->read_text("=*");
			} elsif ($count) {
			    $fh->read_text("=$count");
			}
		    }
		    $fh->read_text("\n");
		    _list_right($iplusplus . '    ',
				$prod->[0], $prod->[1], $s, $fh);
		    $pnum++;
		}
	    }
	}
	$fh->read_text("\n");
    }

    # now list a few object-wide things

    my $as = $object->{assign};
    my $title = "${indent}ALTERED CONSTANTS:\n\n";
    for my $k (keys %$as) {
	my $v = ${$as->{$k}};
	$fh->read_text("${title}${iplus}$k ==> $v\n");
	$title = '';
    }

    my $m = $object->{modules};
    my @m = sort { $a <=> $b } keys %$m;
    for my $mn (@m) {
	$fh->read_text("\n${indent}MODULE #$mn:\n\n");
	_generate($m->{$mn}, $fh, $iplus);
    }

    # TODO - list optimiser
}

sub _list_code {
    my ($code, $fh, $indent) = @_;
    my $cp = 0;
    BYTE: while ($cp < length($code)) {
	my $fc = ord(substr($code, $cp, 1));
	if (is_multibyte($fc) && $cp + 1 < length($code)) {
	    my $ocp = $cp;
	    my $val = unBC($code, \$cp);
	    my $typ = $val->bits > 16 ? '##' : '#';
	    $typ .= $$val;
	    $fh->read_text(sprintf("%s%d: %s\n",
				    $indent, $ocp, $typ));
	} elsif (is_constant($fc) && ! is_multibyte($fc)) {
	    my ($bn, $bd) = bytedecode($fc);
	    $fh->read_text(sprintf("%s%d: %s\n", $indent, $cp, $bn));
	    $cp++;
	} else {
	    my ($bn, $bd) = bytedecode($fc);
	    $fh->read_text(sprintf("%s%d: %-8s; %s\n", $indent, $cp, $bn, $bd));
	    $cp++;
	    next BYTE if $fc != BC_MUL || $cp >= length($code);
	    # see if they are all constants
	    $fc = ord(substr($code, $cp, 1));
	    next BYTE unless is_constant($fc);
	    my $ncp = $cp;
	    my $i = ' ' x length($indent . '  ' . $ncp);
	    my $val = ${unBC($code, \$ncp)};
	    my @fc = ();
	    while (@fc < $val && $cp < length($code)) {
		$fc = ord(substr($code, $ncp, 1));
		next BYTE unless is_constant($fc);
		push @fc, ${unBC($code, \$ncp)};
	    }
	    my $title = "#$val(";
	    while (@fc > 15) {
		my $val = join(' ', map {"#$_"} splice(@fc, 0, 15));
		$fh->read_text(sprintf("%s%s%s\n", $i, $title, $val));
		$title = ' ' x length($title);
	    }
	    $val = join(' ', map {"#$_"} @fc);
	    $fh->read_text(sprintf("%s%s%s)\n", $i, $title, $val));
	    $cp = $ncp;
	}
    }
}

sub _list_register {
    my ($stash, $rn, $rname, $r, $fh, $indent) = @_;
    my $value = '';
    $value .= ' [' . join(' BY ', @{$r->{dimension}}) . ']'
	if exists $r->{dimension} && substr($rname, 0, 1) ne '@';
    $value .= ' #' . ${$r->{value}}
	if exists $r->{value} && 'HASH' ne ref $r->{value};
    $value .= ' IGNORED' if exists $r->{ignore};
    $value .= ' DEFAULT' if exists $r->{is_default};
    $fh->read_text("${indent}$rn$value\n");
    if (exists $r->{value} && 'HASH' eq ref $r->{value}) {
	my $v = $r->{value};
	my @k = keys %$v;
	my %k = map {
	    my $x = $_;
	    $x =~ s/(\d+)/sprintf "%10d", $1/ge;
	    ($_ => $x);
	} @k;
	@k = sort { $k{$a} cmp $k{$b} } @k;
	for my $idx (@k) {
	    next if ! exists $v->{$idx}{value};
	    my $s = join(' ', map { "SUB #$_" } split(/ +/, $idx));
	    my $value = ${$v->{$idx}{value}};
	    $fh->read_text("${indent}    $s = #$value\n");
	}
    }
    if (exists $r->{overload}) {
	$fh->read_text("${indent}OVERLOADED:\n");
	_list_code($r->{overload}, $fh, $indent . '    ');
    }
    if (exists $r->{enrol}) {
	$fh->read_text("${indent}ENROLLED:\n");
	for my $c (sort { $a <=> $b } keys %{$r->{enrol}}) {
	    $fh->read_text("${indent}    \@$c\n");
	}
    }
    if (exists $r->{file} && $r->{file}) {
	$fh->read_text("${indent}FILEHANDLE: " . $r->{file}->describe() . "\n");
    }
    for (my $st = 0; $st < @$stash; $st++) {
	next if ! exists $stash->[$st]{$rname};
	for my $stashed (@{$stash->[$st]{$rname}}) {
	    my $n = "STASHED#$st";
	    _list_register([], $n, $rname, $r->{$rname}, $fh, $indent . '    ');
	}
    }
}

sub _list_right {
    my ($indent, $left, $right, $s, $fh) = @_;
    my $i = $indent;
    for (my $ep = 0; $ep < @$right; $ep++) {
	my ($type, $value) = @{$right->[$ep]};
	if ($type eq 's' || $type eq 'n') {
	    my $w = $value + 1;
	    my $bang = $type eq 'n' ? '!' : '';
	    $fh->read_text("$i$bang$s->[$left->[$value][1]]($w)");
	} elsif ($type eq 'r') {
	    my $v = $left->[$value][1];
	    $v =~ s/([\\\@])/\\$1/g;
	    $v =~ s/\n/\\n/g;
	    $v =~ s/\t/\\t/g;
	    $v =~ s/([\000-\037\177-\377])/
		    sprintf "\\%03o", ord($1)/ge;
	    my $w = $value + 1;
	    $fh->read_text("$i\@$v\@($w)");
	} elsif ($type eq 'c') {
	    my $v = $left->[$value][1];
	    $v =~ s/([\\"])/\\$1/g;
	    $v =~ s/\n/\\n/g;
	    $v =~ s/\t/\\t/g;
	    $v =~ s/([\000-\037\177-\377])/
		    sprintf "\\%03o", ord($1)/ge;
	    my $w = $value + 1;
	    $fh->read_text("$i\"$v\"($w)");
	} elsif ($type eq 'b') {
	    $fh->read_text("$i\{\n");
	    $ep++;
	    while ($ep < @$right && $right->[$ep][0] eq 'b') {
		$value .= $right->[$ep][1];
		$ep++;
	    }
	    $ep--;
	    _list_code($value, $fh, $indent . '    ');
	    $fh->read_text("$indent}");
	} elsif ($type eq 'm') {
	    $fh->read_text("$i\{{\n");
	    _list_right($indent . '    ', $left, $value, $s, $fh);
	    $fh->read_text("$indent}}");
	}
	$i = ' ' ;
    }
    $fh->read_text("\n");
}

1;
