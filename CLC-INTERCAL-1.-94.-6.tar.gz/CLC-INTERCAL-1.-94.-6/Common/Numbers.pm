package Language::INTERCAL::Numbers;

# Numbers which never drop bits, no matter how hard you shake them

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Numbers.pm 1.-94.-6";

use Carp;

use Language::INTERCAL::Exporter '1.-94.-6';
use Language::INTERCAL::Splats '1.-94.-6', qw(:SP);

my @twospotbits = qw(32 20 16 12 12 10);
my @spotbits = qw(16 10 8 6 6 5);

sub new {
    @_ == 3 or croak "Usage: new Language::INTERCAL::Number VALUE, BITS";
    my ($class, $value, $bits) = @_;
    $bits <= 17 && $value > 0xffff and faint(SP_ONESPOT, $value, 'one', '.');
    $value > 0xffffffff and faint(SP_ONESPOT, $value, 'two', 's');
    $bits = $bits <= 16 ? 'Spot' : 'Twospot';
    bless \$value, "Language::INTERCAL::Numbers::$bits";
}

sub unpack {
    @_ == 2 or croak "Usage: Language::INTERCAL::Number->unpack(STRING)";
    my ($class, $value) = @_;
    my $bits;
    if (length($value) > 2) {
	$bits = 'Twospot';
	$value = unpack('V', $value);
    } else {
	$bits = 'Spot';
	$value = unpack('v', $value);
    }
    bless \$value, "Language::INTERCAL::Numbers::$bits";
}

sub from_digits {
    my ($class, $base, @values) = @_;
    my $mask;
    if (@values == $spotbits[$base - 2]) {
	$mask = 'Language::INTERCAL::Numbers::Spot';
    } elsif (@values == $twospotbits[$base - 2]) {
	$mask = 'Language::INTERCAL::Numbers::Twospot';
    } else {
	faint(SP_DIGITS, $base, scalar(@values))
    }
    my $value = 0;
    for my $n (@values) {
	$value = $value * $base + $n % $base;
    }
    bless \$value, $mask;
}

package Language::INTERCAL::Numbers::Spot;

use Carp;
use Language::INTERCAL::Splats '1.-94.-6', qw(:SP);

use vars qw(@ISA);
@ISA = qw(Language::INTERCAL::Numbers);

sub bits { 16 }
sub spot { shift }
sub twospot { bless shift, "Language::INTERCAL::Numbers::Twospot" }
sub pack { pack('v', ${+shift}) }
sub copy { new Language::INTERCAL::Numbers::Spot ${+shift} }

sub new {
    @_ == 2 or croak "Usage: new Language::INTERCAL::Number::Spot VALUE";
    my ($class, $value) = @_;
    $value > 0xffff and faint(SP_ONESPOT, $value, 'one', '.');
    bless \$value, "Language::INTERCAL::Numbers::Spot";
}

sub digits {
    @_ == 2 or croak "Usage: NUMBER->digits(BASE)";
    my ($value, $base) = @_;
    if ($base < 2) { $base = 2 } elsif ($base > 7) { $base = 7 }
    my $bits = $spotbits[$base - 2];
    $value = $$value;
    my $orig = $value;
    my @result = ();
    for (my $n = 0; $n < $bits; $n++) {
	unshift @result, $value % $base;
	$value = int($value / $base);
    }
    $value and faint(SP_THREESPOT);
    @result;
}

package Language::INTERCAL::Numbers::Twospot;

use Carp;
use Language::INTERCAL::Splats '1.-94.-6', qw(:SP);

use vars qw(@ISA);
@ISA = qw(Language::INTERCAL::Numbers);

sub bits { 32 }
sub spot {
    my $x = shift;
    $$x > 0xffff and faint(SP_ONESPOT, $$x, 'one', '.');
    bless $x, "Language::INTERCAL::Numbers::Spot";
}
sub twospot { shift }
sub pack { pack('V', ${+shift}) }
sub copy { new Language::INTERCAL::Numbers::Twospot ${+shift} }

sub new {
    @_ == 2 or croak "Usage: new Language::INTERCAL::Number::Twospot VALUE";
    my ($class, $value) = @_;
    $value > 0xffffffff and faint(SP_ONESPOT, $value, 'two', 's');
    bless \$value, "Language::INTERCAL::Numbers::Twospot";
}

sub digits {
    @_ == 2 or croak "Usage: NUMBER->digits(BASE)";
    my ($value, $base) = @_;
    if ($base < 2) { $base = 2 } elsif ($base > 7) { $base = 7 }
    my $bits = $twospotbits[$base - 2];
    $value = $$value;
    my $orig = $value;
    my @result = ();
    for (my $n = 0; $n < $bits; $n++) {
	unshift @result, $value % $base;
	$value = int($value / $base);
    }
    $value and faint(SP_THREESPOT);
    @result;
}

1;

