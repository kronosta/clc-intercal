package Language::INTERCAL::Exporter;

# Like the standard Exporter, but understand INTERCAL (per)version numbers

# This file is part of CLC-INTERCAL

# Copyright (c) 2006 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($PERVERSION);
$PERVERSION = "CLC-INTERCAL Common/Exporter.pm 1.-94.-6";

use Carp;
require Exporter;

use vars qw(@EXPORT @EXPORT_OK);
@EXPORT = @EXPORT_OK = qw(is_intercal_number import require_version);

sub is_intercal_number {
    @_ == 1 or croak "Usage: is_intercal_number(STRING)";
    my ($s) = @_;
    $s =~ /^-?\d+(?:\.-?\d+)*$/;
}

sub import {
    my $package = shift;
    if (@_ && is_intercal_number($_[0])) {
	require_version($package, shift);
    }
    unshift @_, $package;
    goto &Exporter::import;
}

sub require_version {
    my ($package, $required) = @_;
    $package = caller if ! defined $package;
    my @required = split(/\./, $required);
    no strict 'refs';
    my @provided = split(/\./, my
	$provided = ((${"${package}::PERVERSION"} || '0') =~ /(\S+$)/)[0]);
    while (@required || @provided) {
	my $r = @required ? shift @required : 0;
	my $p = @provided ? shift @provided : 0;
	last if $r < $p;
	next if $r == $p;
	croak "$package perversion $provided is too old (required $required)";
    }
}

1;
