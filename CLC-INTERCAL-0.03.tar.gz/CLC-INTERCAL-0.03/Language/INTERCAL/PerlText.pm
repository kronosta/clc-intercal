package Language::INTERCAL::PerlText;

use Language::INTERCAL::PerlRuntime;

use vars qw($VERSION);
$VERSION = '0.03';

use Fcntl;
use Config;

sub backend {
    my ($baz, $foo, $fubar, $fubaz, $fufoo, @foo) = @_;
    @foo == 1 or die
	'SYNTAX IS "backend PARSE_TREE \'PerlText\', <program_name>" '
      . " at $fubaz line $fufoo\n";
    my $bar = shift @foo;
    open(BAR, '> ' . $bar) or die "12 $bar\: $!\n";
    (my $boo = $bar) =~ s/\.[^\.]*$//;
    $boo =~ s!^.*/!!;
    $boo =~ s/\W|^\d/_/g;
    my $intercal = 'CLC-INTERCAL ' . $VERSION;
    print BAR _default_init($boo, $intercal, @$foo > 4 ? ($foo->[4]) : ());
    print BAR "sub $boo ";
    print BAR _generate_perl(@$foo);
    print BAR _default_pod($boo, $intercal);
    close BAR;
    chmod 0777 & ~ umask, $bar;
}

sub suffix { '.pl' }

*_roman = \&Language::INTERCAL::PerlRuntime::_roman;

my $labcount = 'AAA';

sub _generate_perl {
    my ($baz, $boz, $ppf, $fof) = @_;
    my $biz;
    my %biz = ();
    my @bez = ();
    my @boz = ();
    my %buz = ();
    my %bbz = ();
    my %bfz = ();
    my %bez = ();
    for ($biz = 0; $biz < @$baz; $biz++) {
	$baz->[$biz][2] eq 'NEXT' and do {
	    push @bez, $biz + 1;
	    if (exists $fof->{$baz->[$biz][3]}) {
		$bez{$fof->{$baz->[$biz][3]}} = 1;
	    }
	};
	push @boz, $biz + 1 if $baz->[$biz][2] eq 'LEARN';
	$baz->[$biz][2] eq 'STUDY' and do {
	    my $bbz = $baz->[$biz][3];
	    my $bcz = $baz->[$biz][4];
	    $bbz{$bbz} = [] if ! exists $bbz{$bbz};
	    push @{$bbz{$bbz}}, $bcz;
	    if (exists $fof->{$bcz}) {
		$bez{$fof->{$bcz}} = 1;
	    }
	};
	($baz->[$biz][2] eq 'ABSTAIN' or $baz->[$biz][2] eq 'REINSTATE') and do {
	    if (exists $fof->{$baz->[$biz][3]}) {
		$buz{$fof->{$baz->[$biz][3]}} = 1;
	    }
	};
	($baz->[$biz][2] eq 'GABSTAIN' or $baz->[$biz][2] eq 'GREINSTATE') and do {
	    my @baz = @{$baz->[$biz]};
	    splice @baz, 0, 3;
	    my @zaz = map { exists $boz->{$_} ? @{$boz->{$_}} : () } @baz;
	    my $zuz;
	    for $zuz (@zaz) {
	    	$buz{$zuz} = 1;
	    }
	};
    }

    my @buz = sort { $a <=> $b } (keys %buz);
    my $buz;
    for ($buz = 0; $buz < @buz; $buz++) {
    	$buz{$buz[$buz]} = $buz;
	$buz[$buz] = $baz->[$buz[$buz]][1][0];
    }
    my %buz1 = %buz;

    for ($biz = 0; $biz < @$baz; $biz++) {
	next if $baz->[$biz][2] ne 'COME' and $baz->[$biz][2] ne 'CCOME';

	my $jmp = $baz->[$biz][2] eq 'COME'
		? $baz->[$biz][3]
		: "(" . _flax($baz->[$biz][3]) . ")[1]";

	$jmp .= " && \$buz[$buz{$biz}] > 0" if exists $buz{$biz};
	$jmp .= " && $baz->[$biz][1][1] > rand(100)" if $baz->[$biz][1][1] < 100;

	$baz->[$biz][1][0] = 1;
	$baz->[$biz][1][1] = 100;
	delete $buz1{$biz};

	$biz{$biz} = $jmp;
    }

    my @biz = sort {$a <=> $b} (keys %biz);
    my @bjz = grep($biz{$_} =~ /^\d+$/, @biz);
    my @bkz = grep($biz{$_} !~ /^\d+$/, @biz);

    my $foo = "{\n"
	    . "    my (\$fubar, \$fubaz, \$fufoo) = caller;\n"
	    . "    \@_ > 2 and die \"3 TOO MANY COMMAND-LINE ARGUMENTS at \$fubaz line \$fufoo\\n\";\n"
	    . "    use Language::INTERCAL::PerlRuntime;\n"
	    . "    package Language::INTERCAL::PerlRuntime;\n"
	    . "    my \$buz = \@_ ? shift(\@_) : \\*STDIN;\n"
	    . "    my \$bez = \@_ ? shift(\@_) : \\*STDOUT;\n"
	    . "DECLARATIONS\n";
    $foo .= "    my \@buz = (" . join(', ', @buz) . ");\n" if @buz;
    my %decl = ();
    my %brz = ();
    my $bqz;
    my $bwz = 1;
    my $bug = 1;
    for ($bqz = 0; $bqz < @$baz; $bqz++) {
	$bwz = 1;
	my $biz = $baz->[$bqz];
	my $s = '';
	# $foo .= "# SOURCE LINE " . _roman($bug + $bqz) . " $biz->[2]\n"; # @@@@
	if (exists $bez{$bqz} ||
	    $biz->[2] eq 'COME' || $biz->[2] eq 'CCOME' ||
	    grep($_ == $bqz, @$ppf))
	{
	    $foo .= "    0;\n"
	    	if $foo =~ /\nINTERCAL_${labcount}_\d+_*:\n(?:# SOURCE LINE .*\n)?$/;
	    $foo .= "INTERCAL_${labcount}_${bqz}:\n";
	    %brz = ();
	}
	my $bjz = 1;
	if (exists $buz1{$bqz}) {
	    if ($biz->[1][1] < 100) {
		$foo .= "    if (\$buz[$buz{$bqz}] > 0 && $biz->[1][1] > rand(100)) {\n";
	    } else {
		$foo .= "    if (\$buz[$buz{$bqz}] > 0) {\n";
	    }
	    $s = '    ';
	} elsif ($biz->[1][1] < 100) {
	    $foo .= "    if ($biz->[1][1] > rand(100)) {\n";
	    $s = '    ';
	} elsif (! $biz->[1][0]) {
	    $bjz = 0;
	}
	my $buz = 0;
	if ($bjz) {
	    $biz->[2] eq 'ASSIGN' and do {
		my $fee = $biz->[3];
		my @boz = ();
		my $boz;
		for ($boz = 4; $boz < @$biz; $boz++) {
		    push @boz, _flax($biz->[$boz]);
		}
		$boz = join(', ', @boz);
		if ($fee =~ /^[\d\$]/) {
		    $fee = "_baz('$fee', \\\%fpp)";
		} else {
		    $fee = "'$fee'";
		}
		$decl{'%fop'} = $decl{'%pof'} = 1;
		$foo .= "$s    _assign($fee, \\\%fop, \\\%pof, $boz);\n";
	    };
	    $biz->[2] eq 'SASSIGN' and do {
		my $fee = $biz->[3];
		my @boz = ();
		my $boz;
		for ($boz = 4; $boz < @$biz; $boz++) {
		    push @boz, _flax($biz->[$boz]);
		}
		$boz = join(', ', @boz);
		if ($fee =~ /^[\d\$]/) {
		    $decl{'%fpp'} = 1;
		    $fee = "_baz('$fee', \\\%fpp)";
		} else {
		    $fee = "'$fee'";
		}
		$decl{'%fop'} = $decl{'%pof'} = 1;
		$foo .= "$s    _sassign($fee, \\\%fop, \\\%pof, $boz);\n";
	    };
	    ($biz->[2] eq 'COME' or $biz->[2] eq 'CCOME') and do {
	    };
	    $biz->[2] eq 'BUG' and do {
		$bug = 0;
		$foo .= "$s    die \"774 COMPILER ERROR\\n\";\n";
	    };
	    $biz->[2] eq 'UBUG' and do {
		$bug = 0;
		$foo .= "$s    die \"778 UNEXPLAINABLE COMPILER ERROR\\n\";";
	    };
	    $biz->[2] eq 'READ' and do {
		my $fee = $biz->[3];
		if ($fee =~ /^[\d\$]/) {
		    $decl{'%fpp'} = 1;
		    $fee = "_baz('$fee', \\\%fpp)";
		} else {
		    $fee = "'$fee'";
		}
		$decl{'%fop'} = 1;
		$foo .= "$s    _read_out($fee, \\\%fop, \$bez);\n";
	    };
	    $biz->[2] eq 'WRITE' and do {
		my $fee = $biz->[3];
		if ($fee =~ /^[\d\$]/) {
		    $decl{'%fpp'} = 1;
		    $fee = "_baz('$fee', \\\%fpp)";
		} else {
		    $fee = "'$fee'";
		}
		$decl{'%fop'} = $decl{'%pof'} = 1;
		$foo .= "$s    _write_in($fee, \\\%fop, \\\%pof, \$buz);\n";
	    };
	    $biz->[2] eq 'ILLEGAL' and do {
		my $biz = sprintf "%03d %s", $biz->[3], $biz->[4];
		$biz =~ s/[\\"\$\@]/\\$&/g;
		$biz =~ s/\n/\\n/g;
		$foo .= "$s    die \"$biz\\n\";\n";
		$bwz = 0;
	    };
	    $biz->[2] eq 'STOP' and do {
		my @ppp = grep($_ > $bqz && $_ < @$baz, @$ppf);
		if (@ppp) {
		    $foo .= "$s    goto INTERCAL_${labcount}_$ppp[0];\n"
		} else {
		    $foo .= "$s    return;\n";
		}
		$bwz = 0;
	    };
	    ($biz->[2] eq 'GABSTAIN' or $biz->[2] eq 'GREINSTATE') and do {
		my $zaz = $biz->[2] eq 'GABSTAIN' ? 0 : 1;
		my @baz = @$biz;
		splice @baz, 0, 3;
		my @zaz = map { exists $boz->{$_} ? @{$boz->{$_}} : () } @baz;
		@zaz = map { $buz{$_} } @zaz;
		if (@zaz == 0) {
		} elsif (@zaz == 1) {
		    $foo .= "$s    \$buz[@zaz] = $zaz;\n";
		} else {
		    my $zuz = join(', ', @zaz);
		    my $zoz = scalar @zaz;
		    $foo .= "$s    \@buz[$zuz] = ($zaz) x $zoz;\n";
		}
	    };
	    ($biz->[2] eq 'ABSTAIN' or $biz->[2] eq 'REINSTATE') and do {
		my $zaz = $biz->[2] eq 'ABSTAIN' ? 0 : 1;
		if (exists $fof->{$biz->[3]}) {
		    $foo .= "$s    \$buz[$buz{$fof->{$biz->[3]}}] = $zaz;\n";
		}
	    };
	    ($biz->[2] eq 'IGNORE' or $biz->[2] eq 'REMEMBER') and do {
		my $zaz = $biz->[2] eq 'IGNORE' ? 1 : 0;
		my @baz = ();
		my $baz;
		for ($baz = 3; $baz < @$biz; $baz++) {
		    push @baz, $biz->[$baz];
		}
		if (@baz == 1) {
		    $decl{'%pof'} = 1;
		    $foo .= "$s    \$pof{'@baz'} = $zaz;\n";
		} elsif (@baz) {
		    my $baz = join(', ', map {"'$_'"} @baz);
		    my $zuz = scalar @baz;
		    $decl{'%pof'} = 1;
		    $foo .= "$s    \@pof{$baz} = ($zaz) x $zuz;\n";
		}
	    };
	    $biz->[2] eq 'STASH' and do {
		my @baz = ();
		my $baz;
		for ($baz = 3; $baz < @$biz; $baz++) {
		    push @baz, $biz->[$baz];
		}
		for $baz (@baz) {
		    my $fee;
		    if ($baz =~ /^[\d\$]/) {
			$decl{'%fpp'} = 1;
			$fee = "_baz('$baz', \\\%fpp)";
		    } else {
			$fee = "'$baz'";
		    }
		    $decl{'$baz'} = $decl{'%fpp'} = $decl{'%ffp'} = $decl{'%pop'} = $decl{'%fop'} = 1;
		    $foo .= "$s    \$baz = $fee;\n"
			  . "$s    \$fpp{\$baz} = {} if ! exists \$fpp{\$baz};\n"
			  . "$s    \$ffp{\$baz} = [] if ! exists \$ffp{\$baz};\n"
			  . "$s    push \@{\$pop{\$baz}}, [\$fop{\$baz}, \$fpp{\$baz}, \$ffp{\$baz}];\n";
		}
	    };
	    $biz->[2] eq 'RETRIEVE' and do {
		my @baz = ();
		my $baz;
		for ($baz = 3; $baz < @$biz; $baz++) {
		    push @baz, $biz->[$baz];
		}
		for $baz (reverse @baz) {
		    my $fee;
		    if ($baz =~ /^[\d\$]/) {
			$decl{'%fpp'} = 1;
			$fee = "_baz('$baz', \\\%fpp)";
		    } else {
			$fee = "'$baz'";
		    }
		    $decl{'$baz'} = $decl{'$pop'} = $decl{'%pof'} =$decl{'%fpp'} = $decl{'%ffp'} = $decl{'%pop'} = $decl{'%fop'} = 1;
		    $foo .= "$s    \$baz = $fee;\n"
			  . "$s    die \"436 THROW STICK BEFORE RETRIEVING\\n\" if ! \@{\$pop{\$baz}};\n"
			  . "$s    \$pop = pop \@{\$pop{\$baz}};\n"
			  . "$s    if (! exists \$pof{\$baz} || ! \$pof{\$baz}) {\n"
			  . "$s        (\$fop{\$baz}, \$fpp{\$baz}, \$ffp{\$baz}) = \@\$pop;\n"
			  . "$s    }\n";
		}
	    };
	    $biz->[2] eq 'NEXT' and do {
		my $baz = $biz->[3];
		my $Baz = _roman($baz);
		die "129 LABEL ($Baz) NOT DEFINED\n" if ! exists $fof->{$baz};
		$decl{'@fop'} = 1;
		$foo .= "$s    die \"401 YOUR PROGRAM IS OBSOLETE\\n\" if ! \$Language::INTERCAL::fcc;\n"
		      . "$s    unshift \@fop, " . (1 + $bqz) . ";\n"
		      . "$s    goto INTERCAL_${labcount}_$fof->{$baz};\n";
		$buz = 1;
	    };
	    ($biz->[2] eq 'RESUME' or $biz->[2] eq 'FORGET') and do {
		my $boz = _flax($biz->[3]);
		my $zaz = $biz->[2] eq 'RESUME' ? 'RESUMING' : 'FORGETTING';
		$decl{'$baz'} = $decl{'$biz'} = $decl{'@fop'} = 1;
		$foo .= "$s    die \"401 YOUR PROGRAM IS OBSOLETE\\n\" if ! \$Language::INTERCAL::fcc;\n"
		      . "$s    (\$biz, \$baz) = $boz;\n"
		      . "$s    die \"621 POINTLESSS $biz->[2]\\n\" if ! \$baz;\n"
		      . "$s    die \"632 $zaz OUTSIDE THE MEMORY\\n\" if \$baz > \@fop;\n"
		      . "$s    \$biz = (splice \@fop, 0, \$baz)[\$baz - 1];\n";
		$biz->[2] eq 'RESUME' and do {
		    my $bez;
		    for $bez (@bez) {
			$foo .= "$s    goto INTERCAL_${labcount}_${bez}_ if $bez == \$biz;\n";
		    }
		};
	    };
	    $biz->[2] eq 'ENSLAVE' and do {
		my $fee = $biz->[3];
		my $fuu = $biz->[4];
		if ($fee =~ /^[\d\$]/) {
		    $decl{'%fpp'} = 1;
		    $fee = "_baz('$fee', \\\%fpp)";
		} else {
		    $fee = "'$fee'";
		}
		if ($fuu =~ /^[\d\$]/) {
		    $decl{'%fpp'} = 1;
		    $fuu = "_baz('$fuu', \\\%fpp)";
		} else {
		    $fuu = "'$fuu'";
		}
		$decl{'$fee'} = $decl{'$foo'} = $decl{'%pof'} = $decl{'%fpp'} = 1;
		$foo .= "$s    \$fee = $fee;\n"
		      . "$s    \$foo = $fuu;\n"
		      . "$s    if (! exists \$pof{\$fee} || ! \$pof{\$fee}) {\n"
		      . "$s        \$fpp{\$fee} = [] if ! exists \$fpp{\$fee};\n"
		      . "$s        unshift \@{\$fpp{\$fee}}, \$foo;\n"
		      . "$s    }\n";
	    };
	    $biz->[2] eq 'FREE' and do {
		my $fee = $biz->[3];
		my $fuu = $biz->[4];
		if ($fee =~ /^[\d\$]/) {
		    $decl{'%fpp'} = 1;
		    $fee = "_baz('$fee', \\\%fpp)";
		} else {
		    $fee = "'$fee'";
		}
		if ($fuu =~ /^[\d\$]/) {
		    $decl{'%fpp'} = 1;
		    $fuu = "_baz('$fuu', \\\%fpp)";
		} else {
		    $fuu = "'$fuu'";
		}
		$decl{'$fee'} = $decl{'$foo'} = $decl{'$fuu'} = $decl{'%pof'} = $decl{'%fpp'} = $decl{'@baz'} = 1;
		$foo .= "$s    \$fee = $fee;\n"
		      . "$s    \$foo = $fuu;\n"
		      . "$s    \$fuu = 0;\n"
		      . "$s    if (exists \$fpp{\$fee}) {\n"
		      . "$s        \@baz = grep { \$_ ne \$foo } \@{\$fpp{\$fee}};\n"
		      . "$s        if (\@baz < \@{\$fpp{\$fee}}) {\n"
		      . "$s            \$fuu = 1;\n"
		      . "$s            if (! exists \$pof{\$fee} || ! \$pof{\$fee}) {\n"
		      . "$s                \$fpp{\$fee} = [\@baz];\n"
		      . "$s            }\n"
		      . "$s        }\n"
		      . "$s    }\n"
		      . "$s    die \"512 \$fee DOES NOT BELONG TO \$foo\\n\" if ! \$fuu;\n";
	    };
	    $biz->[2] eq 'STUDY' and do {
		my $fee = $biz->[3];
		my $fii = $biz->[4];
		my $fuu = $biz->[5];
		$decl{'%pff'} = 1;
		$foo .= "$s    \$pff{'$fuu'} = {} if ! exists \$pff{'$fuu'};\n"
		    if ! exists $brz{"pff $fuu"};
		$brz{"pff $fuu"} = 1;
		$foo .= "$s    \$pff{'$fuu'}{$fee} = $fii;\n";
		die "129 LABEL (" . _roman($fii) . ") NOT DEFINED\n"
		    if ! exists $fof->{$fii};
	    };
	    $biz->[2] eq 'ENROL' and do {
		my $fee = $biz->[3];
		my @fii = @$biz;
		splice @fii, 0, 4;
		my $fii = join(', ', @fii);
		if ($fee =~ /^[\d\$]/) {
		    $decl{'%fpp'} = 1;
		    $fee = "_baz('$fee', \\\%fpp)";
		} else {
		    $fee = "'$fee'";
		}
		$decl{'$fee'} = $decl{'$fii'} = $decl{'%ffp'} = 1;
		$foo .= "$s    \$fee = $fee;\n"
		      . "$s    \$fii = _enrol(\\\%pff, $fii);\n"
		      . "$s    \$ffp{\$fee} = [] if ! exists \$ffp{\$fee};\n"
		      . "$s    push \@{\$ffp{\$fee}}, \$fii;\n";
	    };
	    $biz->[2] eq 'LEARN' and do {
		$buz = 1;
		my $fop = 1 + $bqz;
		my $fee = $biz->[3];
		if ($fee =~ /^[\d\$]/) {
		    $decl{'%fpp'} = 1;
		    $fee = "_baz('$fee', \\\%fpp)";
		} else {
		    $fee = "'$fee'";
		}
		$decl{'$fee'} = $decl{'$fii'} = $decl{'%fpp'} = $decl{'%ffp'} = $decl{'%pff'} = $decl{'%fpp'} = $decl{'@fpp'} = 1;
		$foo .= "$s    \$fee = $fee;\n"
		      . "$s    \$fii = _learns(\$fee, $biz->[4], \\\%pff, \\\%ffp);\n"
		      . "$s    \$fpp{\$fii} = [] if ! exists \$fpp{\$fii};\n"
		      . "$s    push \@fpp, [\$fee, \$fii, $fop, \@{\$fpp{\$fii}}];\n"
		      . "$s    unshift \@{\$fpp{\$fii}}, \$fee;\n"
		      . "$s    \$fee = \$pff{\$fii}{$biz->[4]};\n";
		die "799 THIS MUST BE A HOLIDAY\n" if ! exists $bbz{$biz->[4]};
		my @bop = @{$bbz{$biz->[4]}};
		if (@bop > 1) {
		    for $fop (@bop) {
			$foo .= "$s    goto INTERCAL_${labcount}_$fof->{$fop} if $fop == \$fee;\n";
		    }
		} else {
		    $foo .= "$s    goto INTERCAL_${labcount}_$fof->{$bop[0]};\n";
		}
	    };
	    $biz->[2] eq 'FINISH' and do {
		$decl{'$fee'} = $decl{'$fii'} = $decl{'$foo'} = $decl{'$fpp'} = $decl{'%fpp'} = $decl{'@foo'} = $decl{'@fpp'} = 1;
		$foo .= "$s    die \"801 NOT IN A LECTURE\\n\" if ! \@fpp;\n"
		      . "$s    \$fpp = pop \@fpp;\n"
		      . "$s    (\$fee, \$fii, \$foo, \@foo) = \@\$fpp;\n"
		      . "$s    \$fpp{\$fii} = [\@foo];\n";
		my $boz = join(', ', map {"$_ => 'INTERCAL_${labcount}_${_}_'"} @boz);
		$foo .= "$s    goto { $boz } ->{\$foo};\n";
	    };
	    $biz->[2] eq 'GRADUATE' and do {
		my $fee = $biz->[3];
		if ($fee =~ /^[\d\$]/) {
		    $decl{'%fpp'} = 1;
		    $fee = "_baz('$fee', \\\%fpp)";
		} else {
		    $fee = "'$fee'";
		}
		$decl{'$fee'} = $decl{'%ffp'} = 1;
		$foo .= "$s    \$fee = $fee;\n"
		      . "$s    die \"822 \$fee IS NOT A STUDENT\\n\" if ! exists \$ffp{\$fee};\n"
		      . "$s    delete \$ffp{\$fee};\n";
	    };
	}
	if ($s ne '') {
	    $foo .= "    }\n";
	}
	if ($buz) {
	    $foo .= "INTERCAL_${labcount}_" . ($bqz + 1) . "_:\n";
	}
	if ($biz->[0] && @biz) {
	    my $boz;
	    my $bdz = 0;
	    my @blz = grep {$biz{$_} == $biz->[0]} @bjz;
	    $boz = _roman($biz->[0]);
	    die "555 MULTIPLE COME FROM ($boz)\n" if @blz > 1;
	    $decl{'@ppp'} = 1 if @bkz;
	    $foo .= "    \@ppp = ();\n" if @bkz;
	    my @kkz = ();
	    for $boz (@bkz) {
		if ($biz{$boz} =~ /^(\d+)\s*&&\s*/) {
		    if ($1 == $biz->[0]) {
			$foo .= "    push \@ppp, $bdz if $';\n";
			push @kkz, $boz;
			$bdz++;
		    }
		} else {
		    $foo .= "    push \@ppp, $bdz if $biz->[0] == $biz{$boz};\n";
		    push @kkz, $boz;
		    $bdz++;
		}
	    }
	    $boz = _roman($biz->[0]);
	    my $zoz = @blz ? 0 : 1;
	    $foo .= "    die \"555 MULTIPLE COME FROM ($boz)\\n\" if \@ppp > $zoz;\n"
	    	if @bkz + @blz > 1;
	    if (@blz) {
		my $boz = $blz[0];
		$foo .= "    goto INTERCAL_${labcount}_$boz;\n";
	    } elsif (@kkz == 1) {
		$foo .= "    goto INTERCAL_${labcount}_$kkz[0] if \@ppp;\n";
	    } else {
		$bdz = join(' ', map { "INTERCAL_${labcount}_$_" } @kkz);
		$foo .= "    goto (qw($bdz))[\$ppp[0]] if \@ppp;\n";
	    }
	}
    }
    $foo .= "    die \"633 FALLING OFF THE EDGE OF THE PROGRAM\\n\";\n" if $bwz;
    $foo .= "}\n";
    my $decl = join(', ', sort (keys %decl));
    $foo =~ s/\nDECLARATIONS\n/\n    my ($decl) = ();\n/ if $decl ne '';
    $foo =~ s/\nDECLARATIONS\n/\n/ if $decl eq '';
    $labcount++;
    # print STDERR $foo; # @@@@
    $foo;
}

sub _flax {
    my ($paz) = @_;
    my ($baz, $zab, @baz) = @$paz;
    $baz eq 'CONSTANT' and @baz and return "('$zab', @baz)";
    $baz eq 'CONSTANT' and return "('.,:;', $zab)";
    ($baz eq 'AND' or $baz eq 'OR' or $baz eq 'XOR') and do {
	my $zaz = _flax($zab);
	return "_\L$baz\E($zaz)";
    };
    $baz eq 'INTERLEAVE' and do {
	my $zub = _flax($zab);
	my $pof = _flax($baz[0]);
	return "_interleave($zub, $pof)";
    };
    $baz eq 'SELECT' and do {
	my $zub = _flax($zab);
	my $pof = _flax($baz[0]);
	return "_select($zub, $pof)";
    };
    $baz eq 'REGISTER' and do {
	my $fee = $zab;
	if ($fee =~ /^[\d\$]/) {
	    $fee = "_baz('$fee', \\\%fpp)";
	} else {
	    $fee = "'$fee'";
	}
    	return "_register($fee, \\\%fop, \\\%fpp)";
    };
    $baz eq 'SUBSCRIPT' and do {
	my @fff = ();
	my $ffg;
	for $ffg (@baz) {
	    push @fff, _flax($ffg);
	}
	$ffg = join(', ', @fff);
	my $fee = $zab;
	if ($fee =~ /^[\d\$]/) {
	    $fee = "_baz('$fee', \\\%fpp)";
	} else {
	    $fee = "'$fee'";
	}
	return "_subscript($fee, \\\%fpp, \\\%fop, $ffg)";
    };
    0;
}

sub _default_init {
    my ($boo, $intercal) = @_;
    my $foo = @_ > 2 ? ' from ' . $_[2] : '';

    my $perl = $Config::Config{'perlpath'};

    '#!' . $perl . '

# "Perl" code generated by ' . $intercal . $foo . ' -- do not read

eval \'exec ' . $perl . ' -S $0 ${1+"@"}\'
	if 0; # running under some shell

use Getopt::Long;

my $input_alphabet = 2;
my $output_alphabet = 0;
my $obsolete = 0;

Getopt::Long::config qw(no_ignore_case auto_abbrev permute bundling);

GetOptions("obsolete"  => \$obsolete,
	   "a"         => sub { $input_alphabet = 0 },
	   "ascii"     => sub { $input_alphabet = 0 },
	   "b"         => sub { $input_alphabet = 1 },
	   "baudot"    => sub { $input_alphabet = 1 },
	   "e"         => sub { $input_alphabet = 2 },
	   "ebcdic"    => sub { $input_alphabet = 2 },
	   "A"         => sub { $output_alphabet = 0 },
	   "ASCII"     => sub { $output_alphabet = 0 },
	   "B"         => sub { $output_alphabet = 1 },
	   "BAUDOT"    => sub { $output_alphabet = 1 },
	   "E"         => sub { $output_alphabet = 2 },
	   "EBCDIC"    => sub { $output_alphabet = 2 },
	   "o:s"       => sub { open(STDOUT, "> " . $_[1]) or die "$_[1]\: $!\n" },
	   "output:s"  => sub { open(STDOUT, "> " . $_[1]) or die "$_[1]\: $!\n" })
or die "Usage: $0 [-aAbBeE] [input files]\n";

fiddle Language::INTERCAL "next" if $obsolete;

eval "require Charset::EBCDIC" if $input_alphabet != 2 || $output_alphabet == 2;
eval "require Charset::Baudot" if $input_alphabet == 1 || $output_alphabet == 1;

' . $boo . '(
    sub {
	my $t;
	if (@_) {
	    read ARGV, $t, @_;
	} else {
	    $t = <ARGV>;
	    if ($input_alphabet == 1) {
		$t =~ s/\n/B/g;
		$t = baudot2ascii($t);
	    }
	    if ($input_alphabet != 2) {
		$t =~ s![cC]\010[/|]!�!g;
		$t =~ s![vV]\010-!�!g;
		$t = ascii2ebcdic($t);
	    }
	}
	$t;
    },
    sub {
	my $t = join("", @_);
	$t = ascii2baudot($t) if $output_alphabet == 1;
	$t = ascii2ebcdic($t) if $output_alphabet == 2;
	print $t;
    });

';
}

sub _default_pod {
    my ($boo, $intercal) = @_;
    '

__END__

=pod

=head1 NAME

' . $boo . ' - a program generated by ' . $intercal . '

=head1 SYNOPSIS

B<' . $boo . '> [options] B<files>...\n";

=head1 DESCRIPTION

This is just a description of the command-line options, as the compiler has
no way to figure out what the program does (can I<you> figure out what an
INTERCAL program does just by looking at it?). The programmer can change
this paragraph if this is a problem.

=over 4

=item B<-A>

Produce output in ASCII.

=item B<-B>

Produce output in Baudot.

=item B<-E>

Produce output in EBCDIC.

=item B<-a>

Accept input in ASCII.

=item B<-b>

Accept input in Baudot.

=item B<-e>

Accept input in EBCDIC.

=item B<-o> I<name>

Internally redirects the standard output to the named file.

=back

=head1 SEE ALSO

L<Language::INTERCAL>, and, most importantly, a qualified psychiatrist.

';
}

1;

__END__

=head1 NAME

Language::INTERCAL::PerlText - Perl back end for CLC-INTERCAL

=head1 SYNOPSIS

    use Language::INTERCAL;

    my $program = compile Language::INTERCAL 'program text';

    $program->backend('PerlText', 'fun.pl');

    system 'perl', 'fun.pl';

=head1 DESCRIPTION

I<Language::INTERCAL::PerlText> contains a back end for I<Language::INTERCAL>
which creates a Perl script.

The back end is normally invoked using the method I<backend> of package
I<Language::INTERCAL>, with the string 'PerlText' as first argument and
the name of the file to be created as second argument.

The program produced by this back end will contain the same Perl code as
internally generated by the 'Perl' back end (see L<Language::INTERCAL::Perl>),
with a wrapper to parse some command-line options and fiddle with the input
and output alphabet. See the POD in the generated file for details.

=head1 COPYRIGHT

This module is part of CLC-INTERCAL.

Copyright (c) 1999 by Claudio Calvelli E<lt>C<lunatic@assurdo.com>E<gt>,
all (f)rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

=head1 SEE ALSO

A qualified psychiatrist.

