package Language::INTERCAL::PerlRuntime;

use vars qw($VERSION $fdd);

$VERSION = '0.03';
$fdd = 0;

use Charset::EBCDIC;
use Charset::Baudot;

sub _roman {
    my ($foo) = @_;
    if ($foo == 0) {
	"NIHIL";
    } elsif ($foo < 4000) {
	_flix('M..', int($foo / 1000)) .
	_flix('CDM', int($foo / 100) % 10) .
	_flix('XLC', int($foo / 10) % 10) .
	_flix('IVX', $foo % 10);
    } elsif ($foo >= 1000000) {
	my $flux = _roman(int($foo / 1000000));
	$fdd ? ($flux =~ s/./_\010$&/g) : ($flux =~ s/./\\$&/g);;
	$flux . ($foo % 1000000 ? _roman($foo % 1000000) : '');
    } else {
	_flix('cdm', int($foo / 100000) % 10) .
	_flix('xlc', int($foo / 10000) % 10) .
	_flix('ivx', int($foo / 1000) % 10) .
	_flix('CDM', int($foo / 100) % 10) .
	_flix('XLC', int($foo / 10) % 10) .
	_flix('IVX', $foo % 10);
    }
}

sub _flix {
    my ($foo, $bar, $baz, $fop) = @_;
    ($foo, $baz, $fop) = split(/ */, $foo);
    ["",
     "$foo",
     "$foo$foo",
     "$foo$foo$foo",
     "$foo$baz",
     "$baz",
     "$baz$foo",
     "$baz$foo$foo",
     "$baz$foo$foo$foo",
     "$foo$fop"]->[$bar];
}

sub _assign {
    my ($fee, $fop, $pof, @fee) = @_;
    if ($fee =~ /^[,;]/) {
	my @fii = ();
	while (@fee) {
	    my $eef = shift @fee;
	    $eef = shift @fee;
	    die "240 ARRAY TOO SMALL\n" if ! $eef;
	    push @fii, $eef;
	}
	if (! exists $pof->{$fee} || ! $pof->{$fee}) {
	    $fop->{$fee} = _fiip(@fii);
	}
    } else {
	die "275 INCOMPATIBLE NUMBER OF SPOTS IN ASSIGNMENT\n"
	    if index($fee[0], substr($fee, 0, 1)) < 0
	    && $fee[1] >= 0x10000;
	if (! exists $pof->{$fee} || ! $pof->{$fee}) {
	    $fop->{$fee} = $fee[1];
	}
    }
}

sub _sassign {
    my ($fee, $fop, $pof, @fee) = @_;
    my $fgg = substr($fee, 0, 1);
    if (! exists $pof->{$fee} || ! $pof->{$fee}) {
	my $uuf = pop @fee;
	my $oof = pop @fee;
	my $eef = $fop->{$fee};
	while (@fee > 2) {
	    my $iff = shift @fee;
	    $iff = shift @fee;
	    die "241 $fee DOES NOT HAVE THAT MANY DIMENSIONS\n"
		if ! ref $eef;
	    die "241 ILLEGAL SUBSCRIPT TO $fee\n" if $iff == 0;
	    die "241 SUBSCRIPT OUTSIDE ARRAY $fee\n" if $iff > @$eef;
	    $eef = $eef->[$iff - 1];
	}
	my $iff = shift @fee;
	$iff = shift @fee;
	die "241 $fee DOES NOT HAVE THAT MANY DIMENSIONS\n"
	    if ! ref $eef;
	die "241 $fee HAS MORE DIMENSIONS THAN THAT\n"
	    if ref $eef->[$iff - 1];
	my $iif = shift @fee;
	$iif = shift @fee;
	die "241 ILLEGAL SUBSCRIPT TO $fee\n" if $iff == 0;
	die "241 SUBSCRIPT OUTSIDE ARRAY $fee\n" if $iff > @$eef;
	die "275 INCOMPATIBLE NUMBER OF SPOTS IN ASSIGNMENT\n"
		if index($oof, $fgg) < 0
		&& $uuf >= 0x10000;
	$eef->[$iff - 1] = $uuf;
    }
}

sub _enrol {
    my ($pff, @fee) = @_;
    my $ppf;
    my @fii = ();
    FOO: for $ppf (keys %$pff) {
	my $fii;
	for $fii (@fee) {
	    next FOO if ! exists $pff->{$ppf}{$fii};
	}
	push @fii, $ppf;
    }
    die "799 SORRY, THIS MUST BE A HOLIDAY\n" if ! @fii;
    die "603 CLASS WAR BETWEEN \@$fii[0] and \@$fii[1]\n" if @fii > 1;
    $fii[0];
}

sub _learns {
    my ($fee, $foo, $pff, $ffp) = @_;
    die "822 $fee IS NOT A STUDENT\n" if ! exists $ffp->{$fee};
    my $fii = '';
    my $eef;
    for $eef (@{$ffp->{$fee}}) {
	next if ! exists $pff->{$eef}{$foo};
	$fii = $eef;
	last;
    }
    die "823 #$foo NOT IN $fee\'S CURRICULUM\n" if $fii eq '';
    $fii;
}

sub _read_out {
    my ($fee, $fop, $bez) = @_;
    my $baz = substr($fee, 0, 1);
    _output($bez, _roman($fop->{$fee}), "\n")
	if $baz eq '.' || $baz eq ':';
    if ($baz eq ',' || $baz eq ';') {
	die "241 ARRAY $fee NOT DIMENSIONED\n"
	    if ! exists $fop->{$fee} || ! ref $fop->{$fee};
	die "241 ARRAY $fee NOT MONODIMENSIONAL\n"
	    if ref $fop->{$fee}[0];
    }
    if ($baz eq ',') {
	my $aaz = join('', map { sprintf("%c", $_) }
			       grep($_, @{$fop->{$fee}}));
	_output($bez, baudot2ascii($aaz), "\n");
    }
    if ($baz eq ';') {
	my @aaz = @{$fop->{$fee}};
	my $azz = $Language::INTERCAL::fff;
	my $aaz;
	my $zza = '';
	for $aaz (grep { $_ } @aaz) {
	    my $zzz = $aaz;
	    my $fff = 0;
	    my $ggg = 0;
	    my $www;
	    for ($www = 0; $www < 8; $www++) {
		$fff >>= 1;
		$ggg >>= 1;
		$fff |= 0x80 if $zzz & 2;
		$ggg |= 0x80 if $zzz & 1;
		$zzz >>= 2;
	    }
	    $zzz = 0;
	    for ($www = 0; $www < 8; $www++) {
		$zzz >>= 1;
		if ($azz & 1) {
		    $zzz |= 0x80 if $fff & 1;
		    $fff >>= 1;
		} else {
		    $zzz |= 0x80 if !($ggg & 1);
		    $ggg >>= 1;
		}
		$azz >>= 1;
	    }
	    $zza .= sprintf("%c", $zzz);
	    $azz = $zzz;
	}
	_output($bez, $zza);
    }
}

sub _write_in {
    my ($fee, $fop, $pof, $buz) = @_;
    my $baz = substr($fee, 0, 1);
    if ($baz eq '.' || $baz eq ':') {
	my $zaz = _input($buz, 0);
	my $bub = _fulx($zaz);
	die "241 INPUT VALUE HAS TOO MANY SPOTS\n"
	    if $bub > ($baz eq '.' ? 65536 : 4294967296);
	$fop->{$fee} = $bub
	    if ! exists $pof->{$fee} || ! $pof->{$fee};
    }
    if ($baz eq ',' || $baz eq ';') {
	die "241 ARRAY $fee NOT DIMENSIONED\n"
	    if ! exists $fop->{$fee} || ! ref $fop->{$fee};
	die "241 ARRAY $fee NOT MONODIMENSIONAL\n"
	    if ref $fop->{$fee}[0];
    }
    if ($baz eq ',') {
	my $zaz = _input($buz, 0);
	$zaz = ebcdic2ascii($zaz);
	$zaz = ascii2baudot($zaz);
	my $aaz = scalar @{$fop->{$fee}};
	die "997 INPUT RECORD TOO LONG FOR ARRAY\n"
	    if length($zaz) > $aaz;
	my @aaz = map { ord($_) } split(/ *?/, $zaz);
	push @aaz, (0) x ($aaz - @aaz);
	$fop->{$fee} = \@aaz if ! exists $pof->{$fee} || ! $pof->{$fee};
    }
    if ($baz eq ';') {
	my $azz = $Language::INTERCAL::fff;
	my $aaz = scalar @{$fop->{$fee}};
	my $zza = _input($buz, $aaz);
	my @aaz = ();
	while ($zza ne '') {
	    my $zzz = ord($zza);
	    my $xxx = $zzz;
	    $zza = substr($zza, 1);
	    my $fff = 0;
	    my $ggg = 0;
	    my $www;
	    for ($www = 0; $www < 8; $www++) {
		if ($azz & 0x80) {
		    $fff <<= 1;
		    $fff |= 1 if $zzz & 0x80;
		} else {
		    $ggg <<= 1;
		    $ggg |= 1 if ! ($zzz & 0x80);
		}
		$zzz <<= 1;
		$azz <<= 1;
	    }
	    $zzz = int(rand 0x7fff) + 1;
	    for ($www = 0; $www < 8; $www++) {
		$zzz <<= 2;
		$zzz |= 2 if $fff & 0x80;
		$zzz |= 1 if $ggg & 0x80;
		$fff <<= 1;
		$ggg <<= 1;
	    }
	    push @aaz, $zzz;
	    $azz = $xxx;
	}
	push @aaz, (0) x ($aaz - @aaz);
	$fop->{$fee} = \@aaz if ! exists $pof->{$fee} || ! $pof->{$fee};
    }
}

sub _fulx {
    my ($baz, $foo) = @_;
    $foo = 0;
    $baz =~ s/^100*//;
    $baz =~ s/[\n\t]/\100/g;
    while ($baz =~ s/([\226\326][\225\325][\205\305]
		     |[\243\343][\246\346][\226\326]
		     |[\243\343][\210\310][\231\331][\205\305][\205\305]
		     |[\206\306][\226\326][\244\344][\231\331]
		     |[\206\306][\211\311][\245\345][\205\305]
		     |[\242\342][\211\311][\247\347]
		     |[\242\342][\205\305][\245\345][\205\305][\225\325]
		     |[\205\305][\211\311][\207\307][\210\310][\243\343]
		     |[\225\325][\211\311][\225\325][\205\305]
		     |[\251\351][\205\305][\231\331][\226\326]
		     )\100*//x)
    {
	(my $baz = $1) =~ tr[\200-\277][\300\377];
	$foo *= 10;
	$foo += {"\351\305" => 0, "\326\325" => 1, "\343\346" => 2,
		 "\343\310" => 3, "\306\326" => 4, "\306\311" => 5,
		 "\342\311" => 6, "\342\305" => 7, "\305\311" => 8,
		 "\325\311" => 9}->{substr($baz, 0, 2)};
    }
    $foo;
}

sub _register {
    my ($zzz, $fop, $fpp) = @_;
    my $zab = substr($zzz, 0, 1);
    die "241 $zzz IS AN ARRAY REGISTER\n" if $zab ne '.' && $zab ne ':';
    ($zab eq ':' ? ':;' : '.,:;',
    	exists $fop->{$zzz} && defined $fop->{$zzz} ? $fop->{$zzz} : 0);
}

sub _subscript {
    my ($zzz, $fpp, $fop, @baz) = @_;
    my $zab = substr($zzz, 0, 1);
    die "241 $zzz IS NOT AN ARRAY REGISTER\n"
	if $zab ne ',' && $zab ne ';';
    exists $fop->{$zzz} or return ($zab eq ':' ? ':;' : '.,:;', 0);
    my $baz = $fop->{$zzz};
    while (@baz) {
	ref $baz or die "241 $zzz DOES NOT HAVE THAT MANY DIMENSIONS\n";
	my $fff = shift @baz;
	$fff = shift @baz;
	die "241 ILLEGAL SUBSCRIPT\n" if $fff == 0;
	die "241 SUBSCRIPT OUTSIDE ARRAY\n" if $fff > @$baz;
	$baz = $baz->[$fff - 1];
    }
    ref $baz and die "241 $zzz HAS MORE DIMENSIONS THAN THAT\n";
    ($zab eq ';' ? ':;' : '.,:;', $baz);
}

sub _interleave {
    my ($zub, $baz, $pof, $zab) = @_;
    die "533 INTERLEAVE REQUIRES TWO 16 BITS VALUES\n"
	if $baz >= 0x10000 || $zab >= 0x10000;
    my $zzz = 0;
    my $ZZZ = 0;
    while ($ZZZ++ < 16) {
	$zzz <<= 2;
	$zzz |= 2 if $baz & 0x8000;
	$zzz |= 1 if $zab & 0x8000;
	$baz <<= 1;
	$zab <<= 1;
    }
    (':;', $zzz);
}

sub _select {
    my ($zub, $baz, $pof, $zab) = @_;
    my $zzz = 0;
    my $ZZZ = 0;
    while ($ZZZ++ < 32) {
	if ($zab & 0x80000000) {
	    $zzz <<= 1;
	    $zzz |= 1 if $baz & 0x80000000;
	}
	$baz &= 0x7fffffff;
	$zab &= 0x7fffffff;
	$baz <<= 1;
	$zab <<= 1;
    }
    ($zzz > 0x10000 ? ':;' : '.,:;', $zzz);
}

sub _and {
    my ($zub, $baz) = @_;
    my $zba = $baz >> 1;
    $zba |= index($zub, '.') < 0 ? 0x80000000 : 0x8000 if ($baz & 1);
    ($zub, $baz & $zba);
}

sub _or {
    my ($zub, $baz) = @_;
    my $zba = $baz >> 1;
    $zba |= index($zub, '.') < 0 ? 0x80000000 : 0x8000 if ($baz & 1);
    ($zub, $baz | $zba);
}

sub _xor {
    my ($zub, $baz) = @_;
    my $zba = $baz >> 1;
    $zba |= index($zub, '.') < 0 ? 0x80000000 : 0x8000 if ($baz & 1);
    ($zub, $baz ^ $zba);
}

sub _baz {
    my ($baz, $fpp) = @_;
    my $zab = $baz;
    my $zaz = '';
    $baz =~ s/^[\044\062-\071]*// and ($zaz = $&);
    $zaz =~ s/\044/\061/g;
    while ($zaz =~ s/^.//) {
	my $zuz = $& - 1;
	die "512 $baz IS A FREE REGISTER (FROM $zab)\n" if ! exists $fpp->{$baz};
	my @fpp = @{$fpp->{$baz}};
	die "512 $baz DOES'T HAVE THAT MANY OWNERS (FROM $zab)\n"
	    if $zuz >= @fpp;
	$baz = $fpp[$zuz];
    }
    $baz;
}

sub _fiip {
    my ($fee, @fee) = @_;
    if (@fee) {
	my @eef = ();
	while ($fee-- > 0) {
	    push @eef, _fiip(@fee);
	}
	\@eef;
    } else {
	[(0) x $fee];
    }
}

sub _input {
    my ($buz, $zub) = @_;
    if ($zub) {
	ref $buz eq 'CODE' ? ($buz = &$buz($zub)) : read $buz, $buz, $zub;
    } else {
	$buz = ref $buz eq 'CODE' ? &$buz() : <$buz>;
	chomp $buz;
    }
    $buz;
}

sub _output {
    my ($bez, @bez) = @_;
    if (ref $bez eq 'CODE') {
	&$bez(@bez);
    } else {
	print $bez @bez;
    }
}

1;

__END__

=head1 NAME

Language::INTERCAL::RunTime - Runtime library for CLC-INTERCAL

=head1 SYNOPSIS

    use Language::INTERCAL::RunTime;

    sub program {
        ...
    }

    program();

=head1 DESCRIPTION

I<Language::INTERCAL::RunTime> provides the runtime library for CLC-INTERCAL's
default back end (I<Perl>), as well as the other perl back end (I<PerlText>).
You should never need to access this package directly, as the compiler does
that automatically.

=head1 COPYRIGHT

This module is part of CLC-INTERCAL.

Copyright (c) 1999 by Claudio Calvelli E<lt>C<lunatic@assurdo.com>E<gt>,
all (f)rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

=head1 SEE ALSO

A qualified psychiatrist.

