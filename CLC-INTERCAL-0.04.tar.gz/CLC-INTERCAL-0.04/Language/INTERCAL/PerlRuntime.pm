package Language::INTERCAL::PerlRuntime;

# Runtime for CLC-INTERCAL (Perl and PerlText backends)

# This file is part of CLC-INTERCAL.

# Copyright (C) 1999 Claudio Calvelli <lunatic@assurdo.com>, all rights reserved

# WARNING - do not operate heavy machinery while using CLC-INTERCAL

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either 2 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

use vars qw($VERSION $fdd);

$VERSION = '0.04';
$fdd = 0;

use Charset::EBCDIC;
use Charset::Baudot;

sub _roman {
    my ($number) = @_;
    $number =~ s/^[\.:]//;
    if ($number == 0) {
	return "NIHIL";
    }
    my $result = '';
    my @digits = (
    	[ 1000000000, '\i', '\v', '\x', '\l', '\c', '\d', '\m' ],
    	[    1000000, '\I', '\V', '\X', '\L', '\C', '\D', '\M' ],
    	[       1000,  'i',  'v',  'x',  'l',  'c',  'd',  'm' ],
    	[          1,  'I',  'V',  'X',  'L',  'C',  'D',  'M' ],
    );
    while ($number && @digits) {
    	my $digits = shift @digits;
	my ($multiply, $i, $v, $x, $l, $c, $d, $m) = @$digits;
	next if $number < 4 * $multiply && @digits;
	my $r = '';
	if ($number >= 1000 * $multiply) {
	    $r .= $m x int($number / 1000 / $multiply);
	    $number = $number % (1000 * $multiply);
	}
	if ($number >= 999 * $multiply) {
	    $r .= $i . $m;
	    $number -= 999 * $multiply;
	}
	if (int($number / $multiply) == 499) {
	    $r .= $i . $d;
	    $number -= 499 * $multiply;
	}
	if ($number >= 100 * $multiply) {
	    $r .= _numeral($c, $d, $m, int($number / 100 / $multiply));
	    $number = $number % (100 * $multiply);
	}
	if ($number >= 99 * $multiply) {
	    $r .= $i . $c;
	    $number -= 99 * $multiply;
	}
	if (int($number / $multiply) == 49) {
	    $r .= $i . $l;
	    $number -= 49 * $multiply;
	}
	if ($number >= 10 * $multiply) {
	    $r .= _numeral($x, $l, $c, int($number / 10 / $multiply));
	    $number = $number % (10 * $multiply);
	}
	if ($number >= 4 * $multiply || $r ne '') {
	    $r .= _numeral($i, $v, $x, int($number / $multiply));
	} else {
	    $r .= $i x int($number / $multiply);
	}
	$number = $number % $multiply;
	$result .= $r;
    }
    $result;
}

sub _numeral {
    my ($i, $v, $x, $value) = @_;
    if ($value >= 9) { return $i . $x };
    if ($value >= 5) { return $v . ($i x ($value - 5)) }
    if ($value >= 4) { return $i . $v };
    return $i x $value;
}

sub _read_out {
    my ($fee, $regs, $bez) = @_;
    my $baz = $regs->type($fee);
    _output($bez, _roman($regs->value($fee)), "\n")
	if $baz eq '.' || $baz eq ':';
    return if $baz ne ',' && $baz ne ';';
    die "241 ARRAY $fee NOT DIMENSIONED\n" if ! $regs->size($fee);
    my @val = $regs->array($fee);
    if ($baz eq ',') {
	my $aaz = join('', map { sprintf("%c", $_) } @val);
	_output($bez, baudot2ascii($aaz), "\n");
    }
    if ($baz eq ';') {
	my $azz = $Language::INTERCAL::fff;
	my $aazz;
	my $zza = '';
	for $aazz (@val) {
	    (my $aaz = $aazz) =~ s/^[\.:]//;
	    next if ! $aaz;
	    my $zzz = $aaz;
	    my $fff = 0;
	    my $ggg = 0;
	    my $www;
	    for ($www = 0; $www < 8; $www++) {
		$fff >>= 1;
		$ggg >>= 1;
		$fff |= 0x80 if $zzz & 2;
		$ggg |= 0x80 if $zzz & 1;
		$zzz >>= 2;
	    }
	    $zzz = 0;
	    for ($www = 0; $www < 8; $www++) {
		$zzz >>= 1;
		if ($azz & 1) {
		    $zzz |= 0x80 if $fff & 1;
		    $fff >>= 1;
		} else {
		    $zzz |= 0x80 if !($ggg & 1);
		    $ggg >>= 1;
		}
		$azz >>= 1;
	    }
	    $zza .= sprintf("%c", $zzz);
	    $azz = $zzz;
	}
	_output($bez, $zza);
    }
}

sub _write_in {
    my ($fee, $regs, $buz) = @_;
    my $baz = $regs->type($fee);
    if ($baz eq '.' || $baz eq ':') {
	my $zaz = _input($buz, 0);
	my $bub = _convert_number($zaz);
	die "241 INPUT VALUE HAS TOO MANY SPOTS\n"
	    if $baz eq '.' && substr($bub, 0, 1) eq ':';
	$regs->value($fee, $bub);
    }
    return if $baz ne ',' && $baz ne ';';
    my $aaz = $regs->size($fee);
    die "241 ARRAY $fee NOT DIMENSIONED\n" if ! $aaz;
    if ($baz eq ',') {
	my $zaz = _input($buz, 0);
	$zaz = ebcdic2ascii($zaz);
	$zaz = ascii2baudot($zaz);
	die "997 INPUT RECORD TOO LONG FOR ARRAY\n" if length($zaz) > $aaz;
	$regs->array($fee,
		     [map {ord substr($zaz, $_, 1)} (0..(length($zaz)-1))]);
    }
    if ($baz eq ';') {
	my $azz = $Language::INTERCAL::fff;
	my $zza = _input($buz, $aaz);
	my $ptr = 0;
	my @val = ();
	while ($zza ne '') {
	    my $zzz = ord($zza);
	    my $xxx = $zzz;
	    $zza = substr($zza, 1);
	    my $fff = 0;
	    my $ggg = 0;
	    my $www;
	    for ($www = 0; $www < 8; $www++) {
		if ($azz & 0x80) {
		    $fff <<= 1;
		    $fff |= 1 if $zzz & 0x80;
		} else {
		    $ggg <<= 1;
		    $ggg |= 1 if ! ($zzz & 0x80);
		}
		$zzz <<= 1;
		$azz <<= 1;
	    }
	    $zzz = int(rand 0x7fff) + 1;
	    for ($www = 0; $www < 8; $www++) {
		$zzz <<= 2;
		$zzz |= 2 if $fff & 0x80;
		$zzz |= 1 if $ggg & 0x80;
		$fff <<= 1;
		$ggg <<= 1;
	    }
	    ++$ptr;
	    push @val, $zzz;
	    $azz = $xxx;
	}
	$regs->array($fee, \@val);
    }
}

sub _convert_number {
    my ($baz, $foo) = @_;
    $foo = 0;
    $baz =~ s/[\n\t\100]//g;
    while ($baz =~ s/ [\226\326][\225\325][\205\305]
		     |[\243\343][\246\346][\226\326]
		     |[\243\343][\210\310][\231\331][\205\305][\205\305]
		     |[\206\306][\226\326][\244\344][\231\331]
		     |[\206\306][\211\311][\245\345][\205\305]
		     |[\242\342][\211\311][\247\347]
		     |[\242\342][\205\305][\245\345][\205\305][\225\325]
		     |[\205\305][\211\311][\207\307][\210\310][\243\343]
		     |[\225\325][\211\311][\225\325][\205\305][\231\331]?
		     |[\251\351][\205\305][\231\331][\226\326]
		     |[\225\326][\210\310]
		     //x)
    {
	(my $baz = $&) =~ tr[\200-\277][\300-\377];
	$foo *= 10;
	$foo += {"\351\305" => 0, "\326\325" => 1, "\343\346" => 2,
		 "\343\310" => 3, "\306\326" => 4, "\306\311" => 5,
		 "\342\311" => 6, "\342\305" => 7, "\305\311" => 8,
		 "\325\311" => 9, "\326\310" => 0}->{substr($baz, 0, 2)};
    }
    ($foo > 65535 ? ':' : '.') . $foo;
}

sub _enrol {
    my ($pff, @fee) = @_;
    my $ppf;
    my @fii = ();
    FOO: for $ppf (keys %$pff) {
	my $fii;
	for $fii (@fee) {
	    next FOO if ! exists $pff->{$ppf}{$fii};
	}
	push @fii, $ppf;
    }
    die "799 SORRY, THIS MUST BE A HOLIDAY\n" if ! @fii;
    die "603 CLASS WAR BETWEEN \@$fii[0] and \@$fii[1]\n" if @fii > 1;
    $fii[0];
}

sub _learns {
    my ($fee, $regs, $pff, $foo) = @_;
    my @enrol = $regs->enrol($fee);
    die "822 $fee IS NOT A STUDENT\n" if ! @enrol;
    my $fii = '';
    my $eef;
    for $eef (@enrol) {
	next if ! exists $pff->{$eef}{$foo};
	$fii = $eef;
	last;
    }
    die "823 #$foo NOT IN $fee\'S CURRICULUM\n" if $fii eq '';
    $fii;
}

sub _interleave {
    my ($val1, $val2) = @_;
    $val1 =~ s/^[\.:]//;
    $val2 =~ s/^[\.:]//;
    die "533 INTERLEAVE REQUIRES TWO 16 BITS VALUES\n"
	if $val1 >= 0x10000 || $val2 >= 0x10000;
    my $zzz = 0;
    my $ZZZ = 0;
    while ($ZZZ++ < 16) {
	$zzz <<= 2;
	$zzz |= 2 if $val1 & 0x8000;
	$zzz |= 1 if $val2 & 0x8000;
	$val1 <<= 1;
	$val2 <<= 1;
    }
    ':' . $zzz;
}

sub _select {
    my ($val1, $val2) = @_;
    $val1 =~ s/^[\.:]//;
    $val2 =~ s/^[\.:]//;
    my $zzz = 0;
    my $ZZZ = 0;
    my $pof = 0;
    while ($ZZZ++ < 32) {
	if ($val2 & 0x80000000) {
	    $zzz <<= 1;
	    $zzz |= 1 if $val1 & 0x80000000;
	    $pof ++;
	}
	$val1 &= 0x7fffffff;
	$val2 &= 0x7fffffff;
	$val1 <<= 1;
	$val2 <<= 1;
    }
    ($pof > 16 ? ':' : '.') . $zzz;
}

sub _and {
    my ($val) = @_;
    (my $n1 = $val) =~ s/^[\.:]//;
    $val = substr($val, 0, 1);
    my $n2 = $n1 >> 1;
    $n2 |= ($val eq ':' ? 0x80000000 : 0x8000) if $n1 & 1;
    $val . ($n1 & $n2);
}

sub _or {
    my ($val) = @_;
    (my $n1 = $val) =~ s/^[\.:]//;
    $val = substr($val, 0, 1);
    my $n2 = $n1 >> 1;
    $n2 |= ($val eq ':' ? 0x80000000 : 0x8000) if $n1 & 1;
    $val . ($n1 | $n2);
}

sub _xor {
    my ($val) = @_;
    (my $n1 = $val) =~ s/^[\.:]//;
    $val = substr($val, 0, 1);
    my $n2 = $n1 >> 1;
    $n2 |= ($val eq ':' ? 0x80000000 : 0x8000) if $n1 & 1;
    $val . ($n1 ^ $n2);
}

sub _input {
    my ($buz, $zub) = @_;
    if ($zub) {
	ref $buz eq 'CODE' ? ($buz = &$buz($zub)) : read $buz, $buz, $zub;
    } else {
	$buz = ref $buz eq 'CODE' ? &$buz() : <$buz>;
	chomp $buz;
    }
    $buz;
}

sub _output {
    my ($bez, @bez) = @_;
    if (ref $bez eq 'CODE') {
	&$bez(@bez);
    } else {
	print $bez @bez;
    }
}

1;

__END__

=head1 NAME

Language::INTERCAL::PerlRuntime - Runtime library for CLC-INTERCAL

=head1 SYNOPSIS

    use Language::INTERCAL::PerlRuntime;

    sub program {
        ...
    }

    program();

=head1 DESCRIPTION

I<Language::INTERCAL::PerlRuntime> provides the runtime library for
CLC-INTERCAL's default back end (I<Perl>), as well as the other perl back end
(I<PerlText>). You should never need to access this package directly, as the
compiler does that automatically.

=head1 COPYRIGHT

This module is part of CLC-INTERCAL.

Copyright (c) 1999 by Claudio Calvelli E<lt>C<lunatic@assurdo.com>E<gt>,
all (f)rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

=head1 SEE ALSO

A qualified psychiatrist.

