package Language::INTERCAL::QuantumRegs;

# Emulator to run Quantum INTERCAL programs on a classical computer - 
# this module replaces Language::INTERCAL::RegBlock

# This file is part of CLC-INTERCAL.

# Copyright (C) 1999 Claudio Calvelli <lunatic@assurdo.com>, all rights reserved

# WARNING - do not operate heavy machinery while using CLC-INTERCAL

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either 2 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

use Language::INTERCAL::RegBlock;
use Carp;
use FileHandle;
use Socket;

use vars qw($VERSION);
$VERSION = '0.04';

# I was going to use SysV IPC but this is a lot more fun. And it also works
# if you don't have shared memory (e.g. if you can create threads on remote
# computers). What we do is to create a "shared memory server" which will
# hold all non-private variables and connect to it to obtain/change values.
# To use it on a network you'll need to bind to any interface instead of
# just localhost, and to connect to the appropriate place. Maybe in a future
# version I'll do these changes.

sub regblock {
    my ($class) = @_;
    my ($port, $host) = _start_server();
    bless [
	_connect($port, $host),
	Language::INTERCAL::RegBlock->regblock(),
	$port,
	$host,
    ], $class;
}

sub DESTROY {
    my ($regs) = @_;
    my $server = $regs->[0];
    if (defined $server && defined fileno($server)) {
	$regs->_send_command('QUIT');
	shutdown $server, 2;
	close $server;
    }
}

sub value {
    my ($regs, $name, @assign) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->value($name, @assign);
    } else {
	($regs->_send_command('VALUE', $name, @assign))[0];
    }
}

sub array {
    my ($regs, $name, @assign) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->array($name, @assign);
    } else {
	if (@assign) {
	    @assign = (0, @{$assign[0]});
	}
	$regs->_send_command('ARRAY', $name, @assign);
    }
}

sub size {
    my ($regs, $name) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->size($name);
    } else {
	($regs->_send_command('SIZE', $name))[0];
    }
}

sub subscript {
    my ($regs, $name, @list) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->subscript($name, @list);
    } else {
	($regs->_send_command('SUBSCRIPT', $name, @list))[0];
    }
}

sub sassign {
    my ($regs, $name, $value, @list) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->sassign($name, $value, @list);
    } else {
	$regs->_send_command('SASSIGN', $name, $value, @list);
    }
}

sub privatise {
    my ($regs, $name) = @_;
    $name = $regs->_dereference($name);
    return if $regs->[1]->exists($name);
    $regs->[1]->restore($name, $regs->save($name));
}

sub ignore {
    my ($regs, $name, $value) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->ignore($name, $value);
    } else {
	$regs->_send_command('IGNORE', $name, $value);
    }
}

sub stash {
    my ($regs, $name) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->stash($name);
    } else {
	$regs->_send_command('STASH', $name);
    }
}

sub retrieve {
    my ($regs, $name) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->retrieve($name);
    } else {
	$regs->_send_command('RETRIEVE', $name);
    }
}

sub enslave {
    my ($regs, $name, $owner) = @_;
    $name = $regs->_dereference($name);
    $owner = $regs->_dereference($owner);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->enslave($name, $owner);
    } else {
	$regs->_send_command('ENSLAVE', $name, $owner);
    }
}

sub free {
    my ($regs, $name, $owner) = @_;
    $name = $regs->_dereference($name);
    $owner = $regs->_dereference($owner);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->free($name, $owner);
    } else {
	$regs->_send_command('FREE', $name, $owner);
    }
}

sub enrol {
    my ($regs, $name, $class) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->enrol($name, $class);
    } else {
	$regs->_send_command('ENROL', $name, $class);
    }
}

sub graduate {
    my ($regs, $name) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->graduate($name);
    } else {
	$regs->_send_command('GRADUATE', $name);
    }
}

sub save {
    my ($regs, $name) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->save($name);
    } else {
	($regs->_send_command('SAVE', $name))[0];
    }
}

sub restore {
    my ($regs, $name, $save) = @_;
    $name = $regs->_dereference($name);
    if ($regs->[1]->exists($name)) {
	$regs->[1]->restore($name, $save);
    } else {
	$regs->_send_command('RESTORE', $name, $save);
    }
}

sub type {
    my ($regs, $name) = @_;
    $name = $regs->_dereference($name);
    substr($name, 0, 1);
}

sub _dereference {
    my ($regs, $name) = @_;
    return $name if $name !~ /^[\$\d]+/;
    my $belongs = $&;
    my $reg = $';
    while ($belongs =~ s/^.//) {
	my $owner = $& eq '$' ? '1' : $&;
	if ($regs->[1]->exists($reg)) {
	    $reg = $regs->[1]->owner($reg, $owner);
	} else {
	    $reg = ($regs->_send_command('OWNER', $reg, $owner))[0];
	}
    }
    $reg;
}

sub thread {
    my ($regs) = @_;
    $regs->_send_command('FORK');
    my $pid = fork;
    return undef if ! defined $pid;
    return $pid if $pid;
    $regs->[0] = _connect($regs->[2], $regs->[3]);
    $pid;
}

sub _connect {
    my ($port, $host) = @_;
    my $proto = getprotobyname('tcp') || 6;
    my $socket = new FileHandle;
    die "667 new FileHandle: $!\n" if ! defined $socket;
    socket($socket, PF_INET, SOCK_STREAM, $proto) or die "667 socket: $!\n";
    connect($socket, pack_sockaddr_in($port, $host)) or die "667 connect: $!\n";
    $socket;
}

sub _send_command {
    my ($regs, @data) = @_;
    my $server = $regs->[0];
    _send_data($server, @data);
    my @result = _get_data($server);
    my $err = shift @result;
    die $err if $err;
    @result;
}

sub _get_data {
    my ($socket) = @_;
    my $packet;
    sysread $socket, $packet, 4;
    sysread $socket, $packet, unpack('N', $packet);
    my @result = ();
    while ($packet) {
	my $l = unpack('N', substr($packet, 0, 4));
	push @result, substr($packet, 4, $l);
	$packet = substr($packet, 4 + $l);
    }
    @result;
}

sub _send_data {
    my ($socket, @data) = @_;
    my $packet = pack('NA*' x @data, map {(length($_), $_)} @data);
    $packet = pack('NA*', length($packet), $packet);
    syswrite $socket, $packet, length($packet);
}

sub _start_server {
    my $proto = getprotobyname('tcp') || 6;
    my $socket = new FileHandle;
    die "667 new filehandle: $!\n" if ! defined $socket;
    socket($socket, PF_INET, SOCK_STREAM, $proto) or die "667 socket: $!\n";
    bind($socket, pack_sockaddr_in(0, INADDR_LOOPBACK)) or die "667 bind: $!\n";
    listen($socket, SOMAXCONN) or die "667 listen: $!\n";
    my $port = getsockname($socket) or die "667 getsockname: $!\n";
    $port = (unpack_sockaddr_in $port)[0];
    my $pid = fork;
    die "666 PROBLEM HANGING MYSELF - SHOOTING MYSELF IN THE FOOT INSTEAD\n"
	if ! defined $pid;
    return ($port, INADDR_LOOPBACK) if $pid;
    my @client = _wait_client($socket);
    my $data = Language::INTERCAL::RegBlock->regblock();
    while (@client) {
	my $rbits = '';
	my $c = 0;
	while ($c < @client) {
	    my $client = $client[$c];
	    if (defined fileno($client)) {
		vec($rbits, fileno($client), 1) = 1;
		$c++;
	    } else {
		splice(@client, $c, 1);
	    }
	}
	my $ebits = $rbits;
	my $waiting = select($rbits, undef, $ebits, undef);
	$c = 0;
	while ($c < @client) {
	    my $client = $client[$c];
	    $c++;
	    if (vec($rbits, fileno($client), 1)) {
		my @cmd = _get_data($client);
		if (@cmd) {
		    my $cmd = shift @cmd;
		    if ($cmd eq 'QUIT') {
			$c--;
			splice(@client, $c, 1);
			_send_data($client, '');
			shutdown $client, 2;
			close $client;
		    } elsif ($cmd eq 'FORK') {
			_send_data($client, '');
			push @client, _wait_client($socket);
		    } elsif ($cmd eq 'VALUE') {
			$@ = '';
			my @r = eval { $data->value(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'ARRAY') {
			$@ = '';
			my $name = shift @cmd;
			my @arr = ();
			if (@cmd) {
			    shift @cmd;
			    push @arr, \@cmd;
			}
			my @r = eval { $data->array($name, @arr); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'SIZE') {
			$@ = '';
			my @r = eval { $data->size(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'SUBSCRIPT') {
			$@ = '';
			my @r = eval { $data->subscript(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'SASSIGN') {
			$@ = '';
			my @r = eval { $data->sassign(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'IGNORE') {
			$@ = '';
			my @r = eval { $data->ignore(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'STASH') {
			$@ = '';
			my @r = eval { $data->stash(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'RETRIEVE') {
			$@ = '';
			my @r = eval { $data->retrieve(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'ENSLAVE') {
			$@ = '';
			my @r = eval { $data->enslave(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'FREE') {
			$@ = '';
			my @r = eval { $data->free(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'ENROL') {
			$@ = '';
			my @r = eval { $data->enrol(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'GRADUATE') {
			$@ = '';
			my @r = eval { $data->graduate(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'OWNER') {
			$@ = '';
			my @r = eval { $data->owner(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'SAVE') {
			$@ = '';
			my @r = eval { $data->save(@cmd); };
			_send_data($client, $@, @r);
		    } elsif ($cmd eq 'RESTORE') {
			$@ = '';
			my @r = eval { $data->restore(@cmd); };
			_send_data($client, $@, @r);
		    } else {
			_send_data($client, '');
		    }
		}
	    } elsif (vec($ebits, fileno($client), 1)) {
		shutdown $client, 2;
		close $client;
		$c--;
		splice(@client, $c, 1);
	    }
	}
    }
    shutdown $socket, 2;
    exit 0;
}

sub _wait_client {
    my ($socket) = @_;
    my $client = new FileHandle;
    die "667 new filehandle: $!\n" if ! defined $client;
    accept($client, $socket) or die "667 accept: $!\n";
    $client;
}

1;

__END__

=head1 NAME

Language::INTERCAL::QuantumEmulation - run quantum programs on classical computers

=head1 SYNOPSIS

    use Language::INTERCAL::QuantumEmulation;

    my $qq = tie %q, Language::INTERCAL::QuantumEmulation, 'q';

    $q{'a'} = 'b';

    $qq->privatise('a');

=head1 DESCRIPTION

I<Language::INTERCAL::QuantumEmulation> is used to emulate a quantum
computer's variables on a classical one. On a quantum computers, a
variable can have several values at the same time, and � program can
follow several execution paths at once (this is because the "program
counter" or equivalent can have multiple values). It is easy to
emulate this behaviour on a multithreaded system; however, some of
its variables must be shared between threads, while other are private.
Moreover, shared variables can become private at any time (this is because
a "multiple assignment" occurs, which causes threads to start and have
their own private copies).

This package only manages hash variables. The values can be scalars or
hash references. This is enough to run Quantum INTERCAL programs.

The I<tie> function takes one argument after the class name: this is
the name of the variable in the "shared memory segment" which contains
all common variables within a program. This is not a real shared memory
segment, as the module works on a distributed system with no shared memory
between the noded. However, it helps to think of it as a shared memory
segment. To remind the reader that this is not real shared memory, I shall
refer to it as "virtual shared memory" in this page.

Any value stored in the hash is copied to the virtual shared memory, and
any access is done by looking up the appropriate key in the virtual shared
memory. If a value is a hash reference, it is transparently copied to
the virtual shared memory and replaced with a new tied hash with an internally
generated name. These internally generated names always start with "0"
(zero), so if you keep to names which start with alphabetic or underscore
you won't have any name clashes.

There might be a problem when Perl transparently creates hash references:
you might end up with two threads referring to the same key but obtaining
different hash references, both in the virtual shared memory. For this
reason, the Quantum INTERCAL com�iler always locks the variables (see below)
before this can happen, and creates references explicitely if possible.

The return value of I<tie> is an object, which can be used to do "other
things" on the hash. Currently, three methods are available:

=over 4

=item lock OBJECT, KEY

Locks the "cell" correspondign to I<KEY> in the hash corresponding to
I<OBJECT>. The locks are not enforced - the Quantum INTERCAL compiler
always locks variables before starting updates. The exception is those
variables which are always updated atomically, which do not require locks.
If the "cell" is already locked, it does not return until the lock has
been released.

=item unlock OBJECT, KEY

The opposite of I<lock>. It checks if other threads are waiting for a lock
and restarts one of them.

=item privatise OBJECT [, KEY]

Marks the entire hash (or a cell, if a key is specified) as private to the
thread. This means that its values are copied from the virtual shared memory
and then the hash becomes a normal hash. This is not the same as I<untie>,
which just breaks the connection to the virtual shared memory and leaves the
hash empty.

=back

This module needs to know of any threads which need to access virtual
shared memory. The best way to do this is to start threads using the
function I<thread> (which is not exported, so you need to call it as
I<Language::INTERCAL::QuantumEmulation::thread>). Its return value is
the same as I<fork>: undefined for error (sets I<$!>), true for the
parent thread, and false for the child thread.

In addition, a subroutine I<unlock_all> removes any lock created by the
present thread. It is a good idea to call it if there is an exception,
otherwise it can cause the whole program to deadlock.

If all this seems unclear, perhaps you should run your program on a quantum
computer, instead of attempting to emulate it on a classical one.

=head1 COPYRIGHT

This module is part of CLC-INTERCAL.

Copyright (c) 1999 by Claudio Calvelli E<lt>C<lunatic@assurdo.com>E<gt>,
all (f)rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

=head1 SEE ALSO

A qualified psychiatrist.

