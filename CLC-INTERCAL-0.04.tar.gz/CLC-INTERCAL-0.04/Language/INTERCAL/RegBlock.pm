package Language::INTERCAL::RegBlock;

# Runtime for CLC-INTERCAL (Perl and PerlText backends, non-quantum mode)

# This file is part of CLC-INTERCAL.

# Copyright (C) 1999 Claudio Calvelli <lunatic@assurdo.com>, all rights reserved

# WARNING - do not operate heavy machinery while using CLC-INTERCAL

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either 2 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

use vars qw($VERSION);

use Data::Dumper;

$VERSION = '0.04';

sub regblock {
    my ($class) = @_;
    bless {}, $class;
}

sub value {
    my ($regs, $name, @assign) = @_;
    my $ptr = $regs->_ptr($name);
    if ($ptr->{'isarray'}) {
	if (@assign) {
	    my $a;
	    my $sz = 1;
	    for $a (@assign) {
		$a =~ s/^[\.:]//;
		die "240 ARRAY TOO SMALL\n" if $a <= 0;
		$sz *= $a;
	    }
	    if (! $ptr->{'ignore'}) {
		$ptr->{'subscripts'} = \@assign;
		$ptr->{'size'} = $sz;
		$ptr->{'data'} = {};
	    }
	} elsif ($ptr->{'isarray'}) {
	    die "241 $name IS AN ARRAY REGISTER\n";
	}
	return $ptr->{'size'};
    } else {
	if (@assign > 1) {
	    die "241 $name IS NOT AN ARRAY REGISTER\n";
	}
	if (@assign) {
	    my $a = shift @assign;
	    $a =~ s/^[\.:]//;
	    die "275 INCOMPATIBLE NUMBER OF SPOTS IN ASSIGNMENT\n"
		if $a >= [0, 65536, 4294967296]->[$ptr->{'spots'}];
	    $ptr->{'value'} = $a || 0 if ! $ptr->{'ignore'};
	}
	return ($ptr->{'spots'} > 1 ? ':' : '.') . $ptr->{'value'};
    }
}

sub _sptr {
    join(':', map {/^[\.:]/ ? $' : $_} @_);
}

sub array {
    my ($regs, $name, @assign) = @_;
    my $ptr = $regs->_ptr($name);
    die "241 $name IS NOT AN ARRAY REGISTER\n" if ! $ptr->{'isarray'};
    if (@assign) {
	my $a = shift @assign;
	my @s = (1) x @{$ptr->{'subscripts'}};
	$s[-1] = 0;
	my $v;
	for $v (@$a) {
	    die "241 $name OVERSTUFFED\n" if _incs($ptr, \@s);
	    $ptr->{'data'}{_sptr(@s)} = $v if ! $ptr->{'ignore'};
	}
	while (! _incs($ptr, \@s)) {
	    delete $ptr->{'data'}{_sptr(@s)};
	}
	return @$a;
    } else {
	my @s = (1) x @{$ptr->{'subscripts'}};
	$s[-1] = 0;
	my @a;
	while (! _incs($ptr, \@s)) {
	    my $s = _sptr(@s);
	    push @a, $ptr->{'data'}{$s} if exists $ptr->{'data'}{$s};
	}
	return @a;
    }
}

sub _incs {
    my ($ptr, $subs) = @_;
    my $i = @$subs;
    while ($i > 0) {
	$i--;
	if ($subs->[$i] < $ptr->{'subscripts'}[$i]) {
	    $subs->[$i] ++;
	    return 0;
	}
	$subs->[$i] = 1;
    }
    return 1;
}

sub size {
    my ($regs, $name) = @_;
    $regs->_ptr($name)->{'size'};
}

sub _subscript {
    my ($regs, $name, $subs, @val) = @_;
    my $ptr = $regs->_ptr($name);
    die "241 $name IS NOT AN ARRAY REGISTER\n" if ! $ptr->{'isarray'};
    die "241 DIMENSION MISMATCH IN $name\n"
	if @$subs != @{$ptr->{'subscripts'}};
    my $i;
    for ($i = 0; $i < @$subs; $i++) {
	$subs->[$i] =~ s/^[\.:]//;
	die "241 ILLEGAL SUBSCRIPT\n" if $subs->[$i] <= 0;
	die "241 OVEROPTIMISTIC SUBSCRIPT $subs->[$i] TO $name\n"
	    if $subs->[$i] > $ptr->{'subscripts'}[$i];
    }
    my $s = _sptr(@$subs);
    if (@val) {
	my $v = shift @val;
	$v =~ s/^[\.:]//;
	die "275 INCOMPATIBLE NUMBER OF SPOTS IN ASSIGNMENT\n"
	    if $v >= [0, 65536, 4294967296]->[$ptr->{'spots'}];
	$ptr->{'data'}{$s} = $v if ! $ptr->{'ignore'};
    } elsif (exists $ptr->{'data'}{$s}) {
	($ptr->{'spots'} > 1 ? ':' : '.') . $ptr->{'data'}{$s};
    } else {
	($ptr->{'spots'} > 1 ? ':' : '.') . '0';
    }
}

sub subscript {
    my ($regs, $name, @subs) = @_;
    $regs->_subscript($name, \@subs);
}

sub sassign {
    my ($regs, $name, $value, @subs) = @_;
    $regs->_subscript($name, \@subs, $value);
}

sub __ptr {
    my ($regs, $name) = @_;
    return $regs->{$name} if exists $regs->{$name};
    $regs->{$name} = {
	'ignore'  => 0,
	'stash'   => [],
	'belongs' => [],
	'value'   => 0,
	'name'    => $name,
	'enrol'   => [],
    };
    if ($name =~ /^[\.:]/) {
	$regs->{$name}{'spots'} = $& eq '.' ? 1 : 2;
	$regs->{$name}{'isarray'} = 0;
    } elsif ($name =~ /^[,;]/) {
	$regs->{$name}{'spots'} = $& eq ',' ? 1 : 2;
	$regs->{$name}{'isarray'} = 1;
	$regs->{$name}{'size'} = 0;
	$regs->{$name}{'subscripts'} = [];
	$regs->{$name}{'data'} = {};
    } else {
	$regs->{$name}{'spots'} = 0;
	$regs->{$name}{'isarray'} = 0;
    }
    $regs->{$name};
}

sub _ptr {
    my ($regs, $name) = @_;
    my $orig = $name;
    if ($name =~ s/^[\$\d]+//) {
	(my $belongs = $&) =~ s/\$/1/g;
	my $ptr = $regs->__ptr($name);
	while ($belongs =~ s/^.//) {
	    my $owner = $&;
	    die "512 $name DOES NOT HAVE THAT MANY OWNERS (FROM $orig)\n"
		if $owner > @{$ptr->{'belongs'}};
	    $name = $ptr->{'belongs'}[$owner - 1];
	    $ptr = $regs->__ptr($name);
	}
	return $ptr;
    }
    $regs->__ptr($name);
}

sub exists {
    my ($regs, $name) = @_;
    exists $regs->{$name};
}

sub owner {
    my ($regs, $name, $num) = @_;
    my $ptr = $regs->__ptr($name);
    die "512 $name DOES NOT HAVE THAT MANY OWNERS\n"
	if $num > @{$ptr->{'belongs'}};
    $ptr->{'belongs'}[$num - 1];
}

sub ignore {
    my ($regs, $name, $ign) = @_;
    $regs->_ptr($name)->{'ignore'} = $ign;
}

sub enslave {
    my ($regs, $name, $owner) = @_;
    my $ptr = $regs->_ptr($name);
    return if $ptr->{'ignore'};
    unshift @{$ptr->{'belongs'}}, $regs->_ptr($owner)->{'name'};
}

sub free {
    my ($regs, $name, $owner) = @_;
    my $oname = $regs->_ptr($owner)->{'name'};
    my @nb = grep {$_ ne $oname} @{$regs->_ptr($name)->{'belongs'}};
    if (@nb == @{$regs->_ptr($name)->{'belongs'}}) {
	die "512 $name DOES NOT BELONG TO $owner\n";
    }
    my $ptr = $regs->_ptr($name);
    $regs->_ptr($name)->{'belongs'} = \@nb if ! $ptr->{'ignore'};
}

sub enrol {
    my ($regs, $name, @class) = @_;
    my $ptr = $regs->_ptr($name);
    while (@class && ! $ptr->{'ignore'}) {
	my $class = shift @class;
	$class = '@' . $class if $class !~ /^\@/;
	push @{$ptr->{'enrol'}}, $class;
    }
    @{$ptr->{'enrol'}};
}

sub graduate {
    my ($regs, $name) = @_;
    my $ptr = $regs->_ptr($name);
    $ptr->{'enrol'} = [] if ! $ptr->{'ignore'};
}

sub stash {
    my ($regs, $name) = @_;
    my $ptr = $regs->_ptr($name);
    my @save = (
	$ptr->{'ignore'},
	$ptr->{'value'},
	[@{$ptr->{'belongs'}}], 
	[@{$ptr->{'enrol'}}], 
    );
    if ($ptr->{'isarray'}) {
	my %data = %{$regs->{$name}{'data'}};
	push @save, (
	    $ptr->{'size'},
	    [@{$ptr->{'subscripts'}}], 
	    \%data,
	);
    }
    push @{$ptr->{'stash'}}, \@save;
}

sub retrieve {
    my ($regs, $name) = @_;
    my $ptr = $regs->_ptr($name);
    if (@{$ptr->{'stash'}}) {
	my $save = pop @{$ptr->{'stash'}};
	return if $ptr->{'ignore'};
	$ptr->{'ignore'} = shift @$save;
	$ptr->{'value'} = shift @$save;
	$ptr->{'belongs'} = shift @$save;
	$ptr->{'enrol'} = shift @$save;
	if ($ptr->{'isarray'}) {
	    $ptr->{'size'} = shift @$save;
	    $ptr->{'subscripts'} = shift @$save;
	    $ptr->{'data'} = shift @$save;
	}
    } else {
	die "436 $name IS HIDDEN TOO WELL\n";
    }
}

sub type {
    my ($regs, $name) = @_;
    my $ptr = $regs->_ptr($name);
    substr($ptr->{'name'}, 0, 1);
}

sub save {
    my ($regs, $name) = @_;
    my $ptr = $regs->_ptr($name);
    local $Data::Dumper::Indent = 0;
    local $Data::Dumper::Terse = 1;
    Data::Dumper::Dumper($ptr);
}

sub restore {
    my ($regs, $name, $value) = @_;
    $regs->{$name} = eval $value;
}

1;

__END__

=head1 NAME

Language::INTERCAL::RegBlock - Runtime library for CLC-INTERCAL

=head1 SYNOPSIS

    use Language::INTERCAL::RegBlock;

    sub program {
        ...
    }

    program();

=head1 DESCRIPTION

I<Language::INTERCAL::RegBlock> implements all the operations on registers
for CLC-INTERCAL. This is for quantum programs running on quantum computers,
or for classical programs running on any computer. For quantum programs
running on classical computers this module must be replaced with
I<Language::INTERCAL::QuantumRegs>. You should never need to access this
package directly, as the compiler does that automatically.

=head1 COPYRIGHT

This module is part of CLC-INTERCAL.

Copyright (c) 1999 by Claudio Calvelli E<lt>C<lunatic@assurdo.com>E<gt>,
all (f)rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

=head1 SEE ALSO

A qualified psychiatrist.

