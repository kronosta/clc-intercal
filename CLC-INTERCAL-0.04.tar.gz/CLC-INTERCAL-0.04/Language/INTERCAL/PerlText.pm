package Language::INTERCAL::PerlText;

# Back end for CLC-INTERCAL to generate Perl code

# This file is part of CLC-INTERCAL.

# Copyright (C) 1999 Claudio Calvelli <lunatic@assurdo.com>, all rights reserved

# WARNING - do not operate heavy machinery while using CLC-INTERCAL

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either 2 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

use Language::INTERCAL::PerlRuntime;

use vars qw($VERSION);
$VERSION = '0.04';

use Fcntl;
use Config;

my $nice = 1;

sub backend {
    my ($baz, $foo, $fubar, $fubaz, $fufoo, @foo) = @_;
    @foo == 1 or die
	'SYNTAX IS "backend PARSE_TREE \'PerlText\', <program_name>" '
      . " at $fubaz line $fufoo\n";
    my $bar = shift @foo;
    open(BAR, '> ' . $bar) or die "12 $bar\: $!\n";
    (my $boo = $bar) =~ s/\.[^\.]*$//;
    $boo =~ s!^.*/!!;
    $boo =~ s/\W|^\d/_/g;
    my $intercal = 'CLC-INTERCAL ' . $VERSION;
    print BAR _default_init($boo, $intercal, @$foo > 4 ? ($foo->[4]) : ());
    print BAR "sub $boo ";
    print BAR _generate_perl(@$foo);
    print BAR _default_pod($boo, $intercal);
    close BAR;
    chmod 0777 & ~ umask, $bar;
}

sub suffix { '.pl' }

*_roman = \&Language::INTERCAL::PerlRuntime::_roman;

my $labcount = 'AAA';

sub _generate_perl {
    my ($baz, $boz, $ppf, $fof) = @_;
    my $biz;
    my %biz = ();
    my @bez = ();
    my @boz = ();
    my %buz = ();
    my %bbz = ();
    my %bfz = ();
    my %bez = ();
    my $quantum = 0;
    for ($biz = 0; $biz < @$baz; $biz++) {
	$baz->[$biz][2] eq 'NEXT' and do {
	    push @bez, $biz + 1;
	    if (exists $fof->{$baz->[$biz][3]}) {
		$bez{$fof->{$baz->[$biz][3]}} = 1;
	    }
	};
	push @boz, $biz + 1 if $baz->[$biz][2] eq 'LEARN';
	$baz->[$biz][2] eq 'STUDY' and do {
	    my $bbz = $baz->[$biz][3];
	    my $bcz = $baz->[$biz][4];
	    $bbz{$bbz} = [] if ! exists $bbz{$bbz};
	    push @{$bbz{$bbz}}, $bcz;
	    if (exists $fof->{$bcz}) {
		$bez{$fof->{$bcz}} = 1;
	    }
	};
	($baz->[$biz][2] eq 'VFORK' or
	 $baz->[$biz][2] eq 'GFORK' or
	 $baz->[$biz][2] eq 'FORK') and do
	{
	    warn "WARNING: this is not a quantum computer, using emulation\n"
		if ! $quantum;
	    $quantum = 1;
	};
	($baz->[$biz][2] eq 'ABSTAIN' or
	 $baz->[$biz][2] eq 'REINSTATE' or
	 $baz->[$biz][2] eq 'FORK') and do
	{
	    if (exists $fof->{$baz->[$biz][3]}) {
		$buz{$fof->{$baz->[$biz][3]}} = 1;
	    }
	};
	($baz->[$biz][2] eq 'GABSTAIN' or
	 $baz->[$biz][2] eq 'GREINSTATE' or
	 $baz->[$biz][2] eq 'GFORK') and do
	{
	    my @baz = @{$baz->[$biz]};
	    splice @baz, 0, 3;
	    my @zaz = map { exists $boz->{$_} ? @{$boz->{$_}} : () } @baz;
	    my $zuz;
	    for $zuz (@zaz) {
		$buz{$zuz} = 1;
	    }
	};
    }

    my @buz = sort { $a <=> $b } (keys %buz);
    my $buz;
    for ($buz = 0; $buz < @buz; $buz++) {
	$buz{$buz[$buz]} = $buz;
	$buz[$buz] = $baz->[$buz[$buz]][1][0];
    }
    my %buz1 = %buz;

    for ($biz = 0; $biz < @$baz; $biz++) {
	next if $baz->[$biz][2] ne 'COME' and $baz->[$biz][2] ne 'CCOME';

	my $jmp = $baz->[$biz][2] eq 'COME'
		? $baz->[$biz][3]
		: "substr(" . _expr($baz->[$biz][3]) . ", 1)";

	$jmp .= " && substr(\$regs->value('.reinstate.$buz{$biz}'), 1) > 0"
	    if exists $buz{$biz};
	if (ref $baz->[$biz][1][1]) {
	    $jmp .= " && substr(" . _expr($baz->[$biz][1][1]) . ", 1) > rand(100)";
	} elsif ($baz->[$biz][1][1] < 100) {
	    $jmp .= " && $baz->[$biz][1][1] > rand(100)";
	}

	$baz->[$biz][1][0] = 1;
	$baz->[$biz][1][1] = 100;
	delete $buz1{$biz};

	$biz{$biz} = $jmp;
    }

    my @biz = sort {$a <=> $b} (keys %biz);
    my @bjz = grep($biz{$_} =~ /^\d+$/, @biz);
    my @bkz = grep($biz{$_} !~ /^\d+$/, @biz);

    my $foo = "{\n"
	    . "    my (\$fubar, \$fubaz, \$fufoo) = caller;\n"
	    . "    \@_ > 2 and die \"3 TOO MANY COMMAND-LINE ARGUMENTS at \$fubaz line \$fufoo\\n\";\n"
	    . "    use Language::INTERCAL::PerlRuntime;\n"
	    . "    package Language::INTERCAL::PerlRuntime;\n"
	    . "    my \$buz = \@_ ? shift(\@_) : \\*STDIN;\n"
	    . "    my \$bez = \@_ ? shift(\@_) : \\*STDOUT;\n";
    if ($quantum) {
	$foo .= "    my \%clan = ();\n"
	      . "    local \$SIG{'CHLD'} = sub {\n"
	      . "        my \$pid = wait;\n"
	      . "        delete \$clan{\$pid};\n"
	      . "    };\n"
	      . "    require Language::INTERCAL::QuantumRegs;\n"
	      . "    my \$regs = Language::INTERCAL::QuantumRegs->regblock();\n";
    } else {
	$foo .= "    require Language::INTERCAL::RegBlock;\n"
	      . "    my \$regs = Language::INTERCAL::RegBlock->regblock();\n";
    }
    if (@buz) {
	my $i = 0;
	for ($i = 0; $i < @buz; $i++) {
	    $foo .= "    \$regs->value('.reinstate.$i', $buz[$i]);\n";
	}
    }
    $foo .= "DECLARATIONS\n";
    my $xs = '';
    if ($quantum) {
    	$xs = '    ';
	$foo .= "    eval {\n";
    }
    my $bqz;
    my $bug = 1;
    my $die = sub {
	my ($s, $m) = @_;
	$m =~ s/[\\"\$\@\%]/\\$&/g;
	my $b = _roman($bug + $bqz);
	$foo .= "$s    die \"$m ($b)\\n\";\n"
    };
    my %decl = ();
    my %brz = ();
    my $bwz = 1;
    for ($bqz = 0; $bqz < @$baz; $bqz++) {
	$bwz = 1;
	my $biz = $baz->[$bqz];
	my $s = $xs;
	$foo .= "# SOURCE LINE " . _roman($bug + $bqz) . " $biz->[2]\n" if $nice;
	if (exists $bez{$bqz} ||
	    $biz->[2] eq 'COME' || $biz->[2] eq 'CCOME' ||
	    grep($_ == $bqz, @$ppf))
	{
	    $foo .= "$xs    0;\n"
		if $foo =~ /\nINTERCAL_${labcount}_\d+_*:\n(?:# SOURCE LINE .*\n)?$/;
	    $foo .= "INTERCAL_${labcount}_${bqz}:\n";
	    %brz = ();
	}
	my $bjz = 1;
	if (exists $buz1{$bqz}) {
	    if (ref $biz->[1][1]) {
		$foo .= "$xs    if (substr(\$regs->value('.reinstate.$buz{$bqz}'), 1) > 0 && substr(" . _expr($biz->[1][1]) . ", 1) > rand(100)) { \n";
	    } elsif ($biz->[1][1] < 100) {
		$foo .= "$xs    if (substr(\$regs->value('.reinstate.$buz{$bqz}'), 1) > 0 && $biz->[1][1] > rand(100)) { \n";
	    } else {
		$foo .= "$xs    if (substr(\$regs->value('.reinstate.$buz{$bqz}'), 1) > 0) { \n";
	    }
	    $s = $xs . '    ';
	} elsif (ref $biz->[1][1]) {
	    $foo .= "$xs    if (substr(" . _expr($biz->[1][1]) . ", 1) > rand(100)) { \n";
	    $s = $xs . '    ';
	} elsif ($biz->[1][1] < 100) {
	    $foo .= "$xs    if ($biz->[1][1] > rand(100)) {\n";
	    $s = $xs . '    ';
	} elsif (! $biz->[1][0]) {
	    $bjz = 0;
	}
	my $buz = 0;
	if ($bjz) {
	    $biz->[2] eq 'ASSIGN' and do {
		my $fee = $biz->[3];
		my @boz = ();
		my $boz;
		for ($boz = 4; $boz < @$biz; $boz++) {
		    push @boz, _expr($biz->[$boz]);
		}
		$boz = join(', ', @boz);
		$foo .= "$s    \$regs->value('$fee', $boz);\n";
	    };
	    $biz->[2] eq 'SASSIGN' and do {
		my $fee = $biz->[3];
		my @boz = ();
		my $boz;
		for ($boz = 4; $boz < @$biz; $boz++) {
		    push @boz, _expr($biz->[$boz]);
		}
		my $val = pop @boz;
		$boz = join(', ', @boz);
		$foo .= "$s    \$regs->sassign('$fee', $val, $boz);\n";
	    };
	    ($biz->[2] eq 'COME' or $biz->[2] eq 'CCOME') and do {
	    };
	    $biz->[2] eq 'BUG' and do {
		$bug = 0;
		&$die($s, '774 COMPILER ERROR');
	    };
	    $biz->[2] eq 'UBUG' and do {
		$bug = 0;
		&$die($s, '774 UNEXPLAINABLE COMPILER ERROR');
	    };
	    $biz->[2] eq 'READ' and do {
		my $fee = $biz->[3];
		$foo .= "$s    _read_out('$fee', \$regs, \$bez);\n";
	    };
	    $biz->[2] eq 'WRITE' and do {
		my $fee = $biz->[3];
		$foo .= "$s    _write_in('$fee', \$regs, \$buz);\n";
	    };
	    $biz->[2] eq 'ILLEGAL' and do {
		my $biz = sprintf "%03d %s", $biz->[3], $biz->[4];
		$biz =~ s/[\n\s]+$//;
		&$die($s, $biz);
		$bwz = 0;
	    };
	    $biz->[2] eq 'STOP' and do {
		my @ppp = grep($_ > $bqz && $_ < @$baz, @$ppf);
		if (! @ppp && $quantum) { push @ppp, 'end' }
		if (@ppp) {
		    $foo .= "$s    goto INTERCAL_${labcount}_$ppp[0];\n"
		} else {
		    $foo .= "$s    return;\n";
		}
		$bwz = 0;
	    };
	    ($biz->[2] eq 'GABSTAIN' or
	     $biz->[2] eq 'GREINSTATE' or
	     $biz->[2] eq 'GFORK') and do
	    {
		my $zaz;
		my @baz = @$biz;
		splice @baz, 0, 3;
		my @zaz = map { exists $boz->{$_} ? @{$boz->{$_}} : () } @baz;
		@zaz = map { $buz{$_} } @zaz;
		if ($biz->[2] eq 'GFORK') {
		    if (@zaz) {
			my $z;
			for $z (@zaz) {
			    $foo .= "$s    \$regs->privatise('.reinstate.$z');\n";
			}
			$decl{'$baz'} = 1;
			$foo .= "$s    \$baz = \$regs->thread();\n"
			      . "$s    if (! defined \$baz) {\n";
			&$die($s . '    ',
			      "666 PROBLEM HANGING MYSELF - SHOOTING MYSELF IN THE FOOT INSTEAD");
			$foo .= "$s    }\n";
			$foo .= "$s    \$clan{\$baz} = 1 if \$baz;\n";
			$zaz = '($baz == 0)';
		    }
		} else {
		    $zaz = $biz->[2] eq 'GABSTAIN' ? 0 : 1;
		}
		if (@zaz) {
		    my $y;
		    for $y (@zaz) {
			$foo .= "$s    \$regs->value('.reinstate.$y', $zaz);\n";
		    }
		}
	    };
	    ($biz->[2] eq 'ABSTAIN' or
	     $biz->[2] eq 'REINSTATE' or
	     $biz->[2] eq 'FORK') and do
	    {
		my $zaz;
		if ($biz->[2] eq 'FORK') {
		    if (exists $fof->{$biz->[3]}) {
			$decl{'$baz'} = 1;
			$foo .= "$s    \$baz = \$regs->thread();\n"
			      . "$s    if (! defined \$baz) {\n";
			&$die($s . '    ',
			      "666 PROBLEM HANGING MYSELF - SHOOTING MYSELF IN THE FOOT INSTEAD");
			$foo .= "$s    }\n";
			$foo .= "$s    \$clan{\$baz} = 1 if \$baz;\n";
			$zaz = '($baz == 0)';
		    }
		} else {
		    $zaz = $biz->[2] eq 'ABSTAIN' ? 0 : 1;
		}
		if (exists $fof->{$biz->[3]}) {
		    my $n = $buz{$fof->{$biz->[3]}};
		    $foo .= "$s    \$regs->privatise('.reinstate.$n');\n" if $quantum;
		    $foo .= "$s    \$regs->value('.reinstate.$n', $zaz);\n";
		}
	    };
	    ($biz->[2] eq 'IGNORE' or
	     $biz->[2] eq 'REMEMBER' or
	     $biz->[2] eq 'VFORK') and do
	    {
		my $zaz;
		my @baz = ();
		my $baz;
		for ($baz = 3; $baz < @$biz; $baz++) {
		    push @baz, $biz->[$baz];
		}
		if ($biz->[2] eq 'VFORK') {
		    if (@baz) {
			my $b;
			for $b (@baz) {
			    $foo .= "$s    \$regs->privatise('$b');\n";
			}
			$decl{'$baz'} = 1;
			$foo .= "$s    \$baz = \$regs->thread();\n"
			      . "$s    if (! defined \$baz) {\n";
			&$die($s . '    ',
			      "666 PROBLEM HANGING MYSELF - SHOOTING MYSELF IN THE FOOT INSTEAD");
			$foo .= "$s    }\n";
			$foo .= "$s    \$clan{\$baz} = 1 if \$baz;\n";
			$zaz = '($baz == 0)';
		    }
		} else {
		    $zaz = $biz->[2] eq 'IGNORE' ? 1 : 0;
		}
		if (@baz) {
		    my $z = '';
		    my $y;
		    for $y (@baz) {
			$foo .= "$s    \$regs->ignore('$y', $zaz);\n";
		    }
		}
	    };
	    $biz->[2] eq 'STASH' and do {
		my $baz;
		for ($baz = 3; $baz < @$biz; $baz++) {
		    $foo .= "$s    \$regs->stash('$biz->[$baz]');\n";
		}
	    };
	    $biz->[2] eq 'RETRIEVE' and do {
		my $baz;
		for ($baz = @$biz - 1; $baz >= 3; $baz--) {
		    $foo .= "$s    \$regs->retrieve('$biz->[$baz]');\n";
		}
	    };
	    $biz->[2] eq 'NEXT' and do {
		my $baz = $biz->[3];
		my $Baz = _roman($baz);
		die "129 LABEL ($Baz) NOT DEFINED\n" if ! exists $fof->{$baz};
		$decl{'@fop'} = 1;
		$foo .= "$s    if (! \$Language::INTERCAL::fcc) {\n";
		&$die($s . '    ', "401 YOUR PROGRAM IS OBSOLETE");
		$foo .= "$s    }\n"
		      . "$s    unshift \@fop, " . (1 + $bqz) . ";\n"
		      . "$s    goto INTERCAL_${labcount}_$fof->{$baz};\n";
		$buz = 1;
	    };
	    ($biz->[2] eq 'RESUME' or $biz->[2] eq 'FORGET') and do {
		my $boz = _expr($biz->[3]);
		my $zaz = $biz->[2] eq 'RESUME' ? 'RESUMING' : 'FORGETTING';
		$decl{'$baz'} = $decl{'@fop'} = 1;
		$foo .= "$s    if (! \$Language::INTERCAL::fcc) {\n";
		&$die($s . '    ', "401 YOUR PROGRAM IS OBSOLETE");
		$foo .= "$s    }\n"
		      . "$s    (\$baz = $boz) =~ s/^[\\.:]//;\n"
		      . "$s    if (! \$baz) {\n";
		&$die ($s . '    ', "621 POINTLESSS $biz->[2]");
		$foo .= "$s    }\n"
		      . "$s    if (\$baz > \@fop) {\n";
		&$die ($s . '    ', "632 $zaz TOO MUCH");
		$foo .= "$s    }\n"
		      . "$s    \$baz = (splice \@fop, 0, \$baz)[\$baz - 1];\n";
		$biz->[2] eq 'RESUME' and do {
		    my $bez;
		    for $bez (@bez) {
			$foo .= "$s    goto INTERCAL_${labcount}_${bez}_ if $bez == \$baz;\n";
		    }
		};
	    };
	    $biz->[2] eq 'ENSLAVE' and do {
		$foo .= "$s    \$regs->enslave('$biz->[3]', '$biz->[4]');\n";
	    };
	    $biz->[2] eq 'FREE' and do {
		$foo .= "$s    \$regs->free('$biz->[3]', '$biz->[4]');\n";
	    };
	    $biz->[2] eq 'STUDY' and do {
		my $fee = $biz->[3];
		my $fii = $biz->[4];
		my $fuu = $biz->[5];
		$decl{'%pff'} = 1;
		$foo .= "$s    \$pff{'$fuu'} = {} if ! exists \$pff{'$fuu'};\n"
		    if ! exists $brz{"pff $fuu"};
		$brz{"pff $fuu"} = 1;
		$foo .= "$s    \$pff{'$fuu'}{$fee} = $fii;\n";
		die "129 LABEL (" . _roman($fii) . ") NOT DEFINED\n"
		    if ! exists $fof->{$fii};
	    };
	    $biz->[2] eq 'ENROL' and do {
		my $fee = $biz->[3];
		my @fii = @$biz;
		splice @fii, 0, 4;
		my $fii = join(', ', @fii);
		$decl{'$fii'} = $decl{'%pff'} = 1;
		$foo .= "$s    \$fii = _enrol(\\\%pff, $fii);\n";
		$foo .= "$s    \$regs->enrol('$fee', \$fii);\n";
	    };
	    $biz->[2] eq 'LEARN' and do {
		$buz = 1;
		my $fop = 1 + $bqz;
		my $fee = $biz->[3];
		$decl{'$fii'} = $decl{'%pff'} = $decl{'@fpp'} = $decl{'$fee'} = 1;
		$foo .= "$s    \$fii = _learns('$fee', \$regs, \\\%pff, $biz->[4]);\n";
		$foo .= "$s    push \@fpp, ['$fee', \$fii, $fop, \$regs->save(\$fii)];\n";
		$foo .= "$s    \$fee = \$pff{\$fii}{$biz->[4]};\n";
		$foo .= "$s    \$regs->enslave(\$fii, '$fee');\n";
		die "799 THIS MUST BE A HOLIDAY\n" if ! exists $bbz{$biz->[4]};
		my @bop = @{$bbz{$biz->[4]}};
		if (@bop > 1) {
		    for $fop (@bop) {
			$foo .= "$s    goto INTERCAL_${labcount}_$fof->{$fop} if $fop == \$fee;\n";
		    }
		} else {
		    $foo .= "$s    goto INTERCAL_${labcount}_$fof->{$bop[0]};\n";
		}
	    };
	    $biz->[2] eq 'FINISH' and do {
		$decl{'$fee'} = $decl{'$fii'} = $decl{'$foo'} = $decl{'$fpp'} = $decl{'@fpp'} = 1;
		$foo .= "$s    if (! \@fpp) {\n";
		&$die ($s . '    ', "801 NOT IN A LECTURE");
		$foo .= "$s    }\n"
		      . "$s    \$fpp = pop \@fpp;\n";
		$foo .= "$s    (\$fee, \$fii, \$foo, \$fpp) = \@\$fpp;\n"
		      . "$s    \$regs->restore(\$fii, \$fpp);\n";
		my $boz = join(', ', map {"$_ => 'INTERCAL_${labcount}_${_}_'"} @boz);
		$foo .= "$s    goto { $boz } ->{\$foo};\n";
	    };
	    $biz->[2] eq 'GRADUATE' and do {
		my $fee = $biz->[3];
		$foo .= "$s    \$regs->graduate('$fee');\n";
	    };
	}
	if ($s ne $xs) {
	    $foo .= "$xs    }\n";
	}
	if ($buz) {
	    $foo .= "INTERCAL_${labcount}_" . ($bqz + 1) . "_:\n";
	}
	if ($biz->[0] && @biz) {
	    my $boz;
	    my $bdz = 0;
	    my @blz = grep {$biz{$_} == $biz->[0]} @bjz;
	    $boz = _roman($biz->[0]);
	    die "555 MULTIPLE COME FROM ($boz)\n" if @blz > 1;
	    $decl{'@ppp'} = 1 if @bkz;
	    $foo .= "$xs    \@ppp = ();\n" if @bkz;
	    my @kkz = ();
	    for $boz (@bkz) {
		if ($biz{$boz} =~ /^(\d+)\s*&&\s*/) {
		    if ($1 == $biz->[0]) {
			$foo .= "$xs    push \@ppp, $bdz if $';\n";
			push @kkz, $boz;
			$bdz++;
		    }
		} else {
		    $foo .= "$xs    push \@ppp, $bdz if $biz->[0] == $biz{$boz};\n";
		    push @kkz, $boz;
		    $bdz++;
		}
	    }
	    $boz = _roman($biz->[0]);
	    my $zoz = @blz ? 0 : 1;
	    if (@bkz + @blz > 1) {
		$foo .= "$xs    if (\@ppp > $zoz) {\n";
		&$die ($s . '    ', "555 MULTIPLE COME FROM ($boz)");
		$foo .= "$xs    }\n";
	    }
	    if (@blz) {
		my $boz = $blz[0];
		$foo .= "$xs    goto INTERCAL_${labcount}_$boz;\n";
	    } elsif (@kkz == 1) {
		$foo .= "$xs    goto INTERCAL_${labcount}_$kkz[0] if \@ppp;\n";
	    } else {
		$bdz = join(' ', map { "INTERCAL_${labcount}_$_" } @kkz);
		$foo .= "$xs    goto (qw($bdz))[\$ppp[0]] if \@ppp;\n";
	    }
	}
    }
    $foo .= "# END OF PROGRAM\n" if $nice;
    &$die ('', "633 FALLING OFF THE EDGE OF THE PROGRAM") if $bwz;
    if ($quantum) {
	$foo .= "INTERCAL_${labcount}_end:\n"
	      . "    };\n"
	      . "    my \$at = \$\@;\n"
	      . "    \$| = 1; print '';\n"
	      . "    my \@clan = keys \%clan;\n"
	      . "    \$SIG{'CHLD'} = 'IGNORE';\n"
	      . "    while (\@clan) { \n"
	      . "        my \$pid = wait;\n"
	      . "        last if \$pid < 0;\n"
	      . "        delete \$clan{\$pid};\n"
	      . "        \@clan = keys \%clan;\n"
	      . "    }\n"
	      . "    die \$at if \$at;\n";
    }
    $foo .= "}\n";
    my @decl = sort (keys %decl);
    if (! @decl) {
	$foo =~ s/\nDECLARATIONS\n/\n/;
    } else {
	my $decl = join(', ', @decl);
	$foo =~ s/\nDECLARATIONS\n/\n    my ($decl) = ();\n/;
    }
    $labcount++;
    if ($nice) { open(T, '>/tmp/intercal.pl'); print T $foo; close T; }
    $foo;
}

sub _expr {
    my ($paz) = @_;
    my ($baz, $zab, @baz) = @$paz;
    $baz eq 'CONSTANT' and do {
	$zab = '.' . $zab if $zab =~ /^\d/;
	return "'$zab'";
    };
    ($baz eq 'AND' or $baz eq 'OR' or $baz eq 'XOR') and do {
	my $zaz = _expr($zab);
	return "_\L$baz\E($zaz)";
    };
    $baz eq 'INTERLEAVE' and do {
	my $zub = _expr($zab);
	my $pof = _expr($baz[0]);
	return "_interleave($zub, $pof)";
    };
    $baz eq 'SELECT' and do {
	my $zub = _expr($zab);
	my $pof = _expr($baz[0]);
	return "_select($zub, $pof)";
    };
    $baz eq 'REGISTER' and do {
	return "\$regs->value('$zab')";
    };
    $baz eq 'SUBSCRIPT' and do {
	my @fff = ();
	my $ffg;
	for $ffg (@baz) {
	    push @fff, _expr($ffg);
	}
	$ffg = join(', ', @fff);
	return "\$regs->subscript('$zab', $ffg)";
    };
    0;
}

sub _default_init {
    my ($boo, $intercal) = @_;
    my $foo = @_ > 2 ? ' from ' . $_[2] : '';

    my $perl = $Config::Config{'perlpath'};

    '#!' . $perl . '

# DO NOT READ^H^H^H^H EDIT THIS "PERL" CODE
# IT HAS BEEN AUTOMATICALLY GENERATED BY ' . $intercal . $foo . '

eval \'exec ' . $perl . ' -S $0 ${1+"@"}\'
	if 0; # running under some shell

use Getopt::Long;

my $input_alphabet = 2;
my $output_alphabet = 0;
my $obsolete = 0;

Getopt::Long::config qw(no_ignore_case auto_abbrev permute bundling);

GetOptions("obsolete"  => \$obsolete,
	   "a"         => sub { $input_alphabet = 0 },
	   "ascii"     => sub { $input_alphabet = 0 },
	   "b"         => sub { $input_alphabet = 1 },
	   "baudot"    => sub { $input_alphabet = 1 },
	   "e"         => sub { $input_alphabet = 2 },
	   "ebcdic"    => sub { $input_alphabet = 2 },
	   "A"         => sub { $output_alphabet = 0 },
	   "ASCII"     => sub { $output_alphabet = 0 },
	   "B"         => sub { $output_alphabet = 1 },
	   "BAUDOT"    => sub { $output_alphabet = 1 },
	   "E"         => sub { $output_alphabet = 2 },
	   "EBCDIC"    => sub { $output_alphabet = 2 },
	   "o:s"       => sub { open(STDOUT, "> " . $_[1]) or die "$_[1]\: $!\n" },
	   "output:s"  => sub { open(STDOUT, "> " . $_[1]) or die "$_[1]\: $!\n" })
or die "Usage: $0 [-aAbBeE] [input files]\n";

fiddle Language::INTERCAL "next" if $obsolete;

eval "require Charset::EBCDIC" if $input_alphabet != 2 || $output_alphabet == 2;
eval "require Charset::Baudot" if $input_alphabet == 1 || $output_alphabet == 1;

' . $boo . '(
    sub {
	my $t;
	if (@_) {
	    read ARGV, $t, @_;
	} else {
	    $t = <ARGV>;
	    if ($input_alphabet == 1) {
		$t =~ s/\n/B/g;
		$t = Charset::Baudot::baudot2ascii($t);
	    }
	    if ($input_alphabet != 2) {
		$t =~ s![cC]\010[/|]!�!g;
		$t =~ s![vV]\010-!�!g;
		$t = Charset::EBCDIC::ascii2ebcdic($t);
	    }
	}
	$t;
    },
    sub {
	my $t = join("", @_);
	$t = Charset::Baudot::ascii2baudot($t) if $output_alphabet == 1;
	$t = Charset::EBCDIC::ascii2ebcdic($t) if $output_alphabet == 2;
	print $t;
    });

';
}

sub _default_pod {
    my ($boo, $intercal) = @_;
    '

__END__

=pod

=head1 NAME

' . $boo . ' - a program generated by ' . $intercal . '

=head1 SYNOPSIS

B<' . $boo . '> [options] B<files>...\n";

=head1 DESCRIPTION

This is just a description of the command-line options, as the compiler has
no way to figure out what the program does (can I<you> figure out what an
INTERCAL program does just by looking at it?). The programmer can change
this paragraph if this is a problem.

=over 4

=item B<-A>

Produce output in ASCII.

=item B<-B>

Produce output in Baudot.

=item B<-E>

Produce output in EBCDIC.

=item B<-a>

Accept input in ASCII.

=item B<-b>

Accept input in Baudot.

=item B<-e>

Accept input in EBCDIC.

=item B<-o> I<name>

Internally redirects the standard output to the named file.

=back

=head1 SEE ALSO

L<Language::INTERCAL>, and, most importantly, a qualified psychiatrist.

';
}

1;

__END__

=head1 NAME

Language::INTERCAL::PerlText - Perl back end for CLC-INTERCAL

=head1 SYNOPSIS

    use Language::INTERCAL;

    my $program = compile Language::INTERCAL 'program text';

    $program->backend('PerlText', 'fun.pl');

    system 'perl', 'fun.pl';

=head1 DESCRIPTION

I<Language::INTERCAL::PerlText> contains a back end for I<Language::INTERCAL>
which creates a Perl script.

The back end is normally invoked using the method I<backend> of package
I<Language::INTERCAL>, with the string 'PerlText' as first argument and
the name of the file to be created as second argument.

The program produced by this back end will contain the same Perl code as
internally generated by the 'Perl' back end (see L<Language::INTERCAL::Perl>),
with a wrapper to parse some command-line options and fiddle with the input
and output alphabet. See the POD in the generated file for details.

=head1 COPYRIGHT

This module is part of CLC-INTERCAL.

Copyright (c) 1999 by Claudio Calvelli E<lt>C<lunatic@assurdo.com>E<gt>,
all (f)rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

=head1 SEE ALSO

A qualified psychiatrist.

