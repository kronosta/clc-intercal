package Language::INTERCAL;

# Parser and generic compiler functionality for CLC-INTERCAL

# This file is part of CLC-INTERCAL.

# Copyright (C) 1999 Claudio Calvelli <lunatic@assurdo.com>, all rights reserved

# WARNING - do not operate heavy machinery while using CLC-INTERCAL

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either 2 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

use vars qw($VERSION);

$VERSION = '0.04';

use Charset::EBCDIC;
use Charset::Baudot;
use Language::INTERCAL::PerlRuntime;

use vars qw(*fudge *fiddle);

*fudge = *fiddle = \&toggle;

*_output = \&Language::INTERCAL::PerlRuntime::_output;
*_roman = \&Language::INTERCAL::PerlRuntime::_roman;

use vars qw($fcc $fff);

my $faa = 0;
my $fbb = 0;
$fcc = 0;
my $fee = 43;
$fff = 172;
my $fgg = 5;
my $fhh = 0.005;

sub toggle {
    my $f;
    for $f (@_) {
	lc($f) eq 'mingle' and $faa = ! $faa;
	lc($f) eq 'xor' and $fbb = ! $fbb;
	lc($f) eq 'next' and $fcc = ! $fcc;
	lc($f) eq 'roman' and
	    $Language::INTERCAL::PerlRuntime::fdd =
		! $Language::INTERCAL::PerlRuntime::fdd;
	$f =~ /^width\s*(\d+)/ and $fee = $1 - 37;
	$f =~ /^width\s*=\s*(\d+)/ and $fee = $1 - 37;
	$f =~ /^io\s*(\d+)/ and $fff = $1;
	$f =~ /^io\s*=\s*(\d+)/ and $fff = $1;
	$f =~ /^bug\s*(\d+)/ and $fgg = $1;
	$f =~ /^bug\s*=\s*(\d+)/ and $fgg = $1;
	$f =~ /^ubug\s*(\d+)/ and $fhh = $1;
	$f =~ /^ubug\s*=\s*(\d+)/ and $fhh = $1;
    }
}

sub import {
    goto &compile if @_ > 1;
}

sub compile {
    my ($fubar, $fubaz, $fufoo) = caller;
    my $syntax = 
	'SYNTAX IS "use|compile Language::INTERCAL <program>, <source> " '
      . "[, <list_filehandle>], ['optimise'] at $fubaz line $fufoo\n";
    @_ < 3 and die $syntax;
    my $foo = shift @_;
    my $bar = shift @_;
    my $baz = shift @_;
    my $fop = undef;
    my $pof = 0;
    while (@_) {
	my $foo = shift @_;
	if (ref $foo && (ref $foo eq 'CODE' || UNIVERSAL::isa($foo, 'GLOB'))) {
	    $fop = $foo;
	} elsif ($foo =~ /^opt(?:imi[sz]e)?$/i) {
	    $pof = 1;
	} elsif ($foo =~ /^nobug$/i) {
	    $fgg = 0;
	} elsif ($foo =~ /^noubug$/i) {
	    $fhh = 0;
	} else {
	    die $syntax;
	}
    }
    my @biz = _parse('' . $baz, $fop, $fubaz, $fufoo);
    optimise(\@biz) if $pof;
    require Language::INTERCAL::Perl;
    Language::INTERCAL::Perl::backend('Perl', \@biz,
				      $fubar, $fubaz, $fufoo, $bar);
}

sub name {
    my ($fubar, $fubaz, $fufoo) = caller;
    @_ == 2 or die
	'SYNTAX IS "name PARSE_TREE <name>" '
      . "[, <list_filehandle>] at $fubaz line $fufoo\n";
    my $self = shift;
    $self->[4] = shift;
    $self;
}

sub parse {
    my ($fubar, $fubaz, $fufoo) = caller;
    @_ == 2 or (@_ == 3 and ref $_[2]
			and (ref $_[2] eq 'CODE' or
			     UNIVERSAL::isa($_[2], 'GLOB'))
	       )
	    or die
	'SYNTAX IS "parse Language::INTERCAL <program>" '
      . "[, <list_filehandle>] at $fubaz line $fufoo\n";
    my ($foo, $bar, $fop) = @_;
    my @biz = _parse('' . $bar, $fop, $fubaz, $fufoo);
    bless \@biz;
}

sub backend {
    my ($fubar, $fubaz, $fufoo) = caller;
    @_ >= 2 or die
	'SYNTAX IS "backend PARSE_TREE <type>, <arguments>" '
      . " at $fubaz line $fufoo\n";
    my ($foo, $baz, @foo) = @_;
    $@ = '';
    eval "require Language::INTERCAL::$baz"
	if ! defined &{ "Language::INTERCAL::$baz\::backend" };
    die "CANNOT FIND '$baz' BACK END\n" if $@;
    &{ "Language::INTERCAL::$baz\::backend" }
		    ($baz, $foo, $fubar, $fubaz, $fufoo, @foo);
}

sub complete_name {
    my ($fubar, $fubaz, $fufoo) = caller;
    @_ == 3 or die
	'SYNTAX IS "complete_name PARSE_TREE <backend>, <name>" '
      . " at $fubaz line $fufoo\n";
    my ($foo, $baz, $bap) = @_;
    $@ = '';
    eval "require Language::INTERCAL::$baz"
	if ! defined &{ "Language::INTERCAL::$baz\::backend" };
    die "CANNOT FIND '$baz' BACK END\n" if $@;
    return $baz if ! defined &{ "Language::INTERCAL::$baz\::suffix" };
    $bap .= &{ "Language::INTERCAL::$baz\::suffix"}();
    $bap;
}

sub optimise {
    my ($fubar, $fubaz, $fufoo) = caller;
    @_ == 1 or die "SYNTAX IS optimise PARSE_TREE at $fubaz line $fufoo\n";
    my $foo = shift;
    my ($baz, $boz, $ppf, $fof) = @$foo;
    my $zaz;
    my $lab = 0;
    my $biz;
    for ($biz = 0; $biz < @$baz; $biz++) {
	my $zaz = $baz->[$biz];
	if ($zaz->[2] eq 'COME' or $zaz->[2] eq 'CCOME') {
	    $lab = 1;
	}
	if (! $lab && $zaz->[0]) {
	    my $bbb;
	    FOO: for $bbb (@$baz) {
		$lab = 1 if $bbb->[2] eq 'CCOME';
		$lab = 1 if $bbb->[2] eq 'NEXT' && $bbb->[3] == $zaz->[0];
		$lab = 1 if $bbb->[2] eq 'STUDY' && $bbb->[4] == $zaz->[0];
		last FOO if $lab;
	    }
	}
	if (! $lab &&
	    (! $zaz->[1][0] || $zaz->[1][1] < 100) &&
	    ($zaz->[2] eq 'ABSTAIN' ||
	     $zaz->[2] eq 'REINSTATE' ||
	     $zaz->[2] eq 'GABSTAIN' ||
	     $zaz->[2] eq 'GREINSTATE'))
	{
	    $lab = 1;
	}
	if (! $lab && ($zaz->[2] eq 'FORK' || $zaz->[2] eq 'GFORK')) {
	    $lab = 1;
	}
	if (! $lab && $zaz->[1][0] && $zaz->[1][1] >= 100) {
	    if ($zaz->[2] eq 'ABSTAIN' || $zaz->[2] eq 'REINSTATE') {
		if (exists $fof->{$zaz->[3]} &&
		    $fof->{$zaz->[3]} > $biz)
		{
		    $baz->[$fof->{$zaz->[3]}][1][0] =
			$zaz->[2] eq 'ABSTAIN' ? 0 : 1;
		}
		@{$boz->{$zaz->[2]}} = grep {$_ != $biz} @{$boz->{$zaz->[2]}};
		$zaz->[2] = 'NOOP';
		$zaz->[1][0] = 0;
	    }
	    if ($zaz->[2] eq 'GABSTAIN' or $zaz->[2] eq 'GREINSTATE') {
		my $zuz = $zaz->[2] eq 'GABSTAIN' ? 0 : 1;
		my @baz = @$zaz;
		splice @baz, 0, 3;
		my @zaz = map { exists $boz->{$_} ? @{$boz->{$_}} : () } @baz;
		my @paz = grep { $_ > $biz } @zaz;
		my $paz;
		for $paz (@paz) {
		    $baz->[$paz][1][0] = $zuz;
		}
		@{$boz->{$zaz->[2]}} = grep {$_ != $biz} @{$boz->{$zaz->[2]}};
		$zaz->[2] = 'NOOP';
		$zaz->[1][0] = 0;
	    }
	}
	if (! $lab && !$zaz->[1][0]) {
	    @{$boz->{$zaz->[2]}} = grep {$_ != $biz} @{$boz->{$zaz->[2]}};
	    $zaz->[2] = 'NOOP';
	    $zaz->[1][0] = 0;
	}
	if ($zaz->[2] eq 'CCOME') {
	    _optimise_expr($zaz->[3]);
	    if ($zaz->[3][0] eq 'CONSTANT') {
		$zaz->[2] = 'COME';
		my $a = (@{$zaz->[3]})[1];
		$a =~ s/^[\.:]//;
		$zaz->[3] = $a;
	    }
	}
	if ($zaz->[2] eq 'RESUME' or $zaz->[2] eq 'FORGET') {
	    _optimise_expr($zaz->[3]);
	}
	if ($zaz->[2] eq 'ASSIGN' or $zaz->[2] eq 'SASSIGN') {
	    my $boz;
	    for ($boz = 4; $boz < @$zaz; $boz++) {
		_optimise_expr($zaz->[$boz]);
	    }
	}
    }
    if (! exists $boz->{'CCOME'} || ! @{$boz->{'CCOME'}}) {
	for ($biz = 0; $biz < @$baz; $biz++) {
	    my $zaz = $baz->[$biz];
	    if ($zaz->[0]) {
		my $bbb;
		my $use = 0;
		for $bbb (map {exists $boz->{$_} ? @{$boz->{$_}} : ()}
			  qw(NEXT ABSTAIN REINSTATE STUDY COME))
		{
		    next if $baz->[$bbb][$baz->[$bbb][2] eq 'STUDY' ? 4 : 3] != $zaz->[0];
		    $use = 1;
		    last;
		}
		if (! $use) {
		    $zaz->[0] = 0;
		}
	    }
	}
    }
    $foo;
}

sub _optimise_expr {
    my ($foo) = @_;
    return if $foo->[0] eq 'CONSTANT' || $foo->[0] eq 'REGISTER';
    if ($foo->[0] eq 'AND' || $foo->[0] eq 'OR' || $foo->[0] eq 'XOR') {
	_optimise_expr($foo->[1]);
	if ($foo->[1][0] eq 'CONSTANT') {
	    my $op = "Language::INTERCAL::PerlRuntime::_\L$foo->[0]";
	    my @val = @{$foo->[1]};
	    shift @val;
	    my $val = shift @val;
	    $val = '.' . $val if $val =~ /^\d/;
	    $_[0] = ['CONSTANT', &$op($val)];
	}
	return;
    }
    if ($foo->[0] eq 'INTERLEAVE' || $foo->[0] eq 'SELECT') {
	_optimise_expr($foo->[1]);
	_optimise_expr($foo->[2]);
	if ($foo->[1][0] eq 'CONSTANT' && $foo->[2][0] eq 'CONSTANT') {
	    my $op = "Language::INTERCAL::PerlRuntime::_\L$foo->[0]";
	    my @val = @{$foo->[1]};
	    shift @val;
	    my $val = shift @val;
	    $val = '.' . $val if $val =~ /^\d/;
	    my @vbl = @{$foo->[2]};
	    shift @vbl;
	    my $vbl = shift @vbl;
	    $vbl = '.' . $vbl if $vbl =~ /^\d/;
	    $_[0] = ['CONSTANT', &$op($val, $vbl)];
	}
	return;
    }
    if ($foo->[0] eq 'SUBSCRIPT') {
	my $boz;
	for ($boz = 2; $boz < @$foo; $boz++) {
	    _optimise_expr($foo->[$boz]);
	}
	return;
    }
}

sub link {
    my $foo = $_[0];
    my @biz = ();
    my %boz = ();
    my @bez = ();
    my %buz = ();
    my $baz;
    for $baz (@_) {
	if (! UNIVERSAL::isa($baz, 'ARRAY') ||
	    (@$baz != 4 && @$baz != 5) ||
	    ! UNIVERSAL::isa($baz->[0], 'ARRAY') ||
	    ! UNIVERSAL::isa($baz->[1], 'HASH') ||
	    ! UNIVERSAL::isa($baz->[2], 'ARRAY') ||
	    ! UNIVERSAL::isa($baz->[3], 'HASH'))
	{
	    my ($fubar, $fubaz, $fufoo) = caller;
	    die "SYNTAX IS link parse_tree parse_tree... at $fubaz (line $fufoo)\n";
	}
	my $buz;
	for $buz (keys %{$baz->[3]}) {
	    die "458 YOU LIKE LABEL (" . _roman($buz) . ") A LOT\n"
		if exists $buz{$buz};
	    $buz{$buz} = $baz->[3]{$buz} + @biz;
	}
	push @bez, map { $_ + @biz } @{$baz->[2]};
	my $boz;
	for $boz (keys %{$baz->[1]}) {
	    $boz{$boz} = [] if ! exists $boz{$boz};
	    push @{$boz{$boz}}, map { $_ + @biz } @{$baz->[1]{$boz}};
	}
	push @biz, @{$baz->[0]};
    }
    $foo->[0] = \@biz;
    $foo->[1] = \%boz;
    $foo->[2] = \@bez;
    $foo->[3] = \%buz;
    $foo;
}

sub save {
    my ($fubar, $fubaz, $fufoo) = caller;
    @_ == 2 or die "SYNTAX IS SAVE PARSE_TREE, NAME at $fubaz (line $fufoo)\n";
    my ($foo, $bar) = @_;
    my ($biz, $boz, $bez, $baz, $buz) = @$foo;
    open(BAR, '> ' . $bar) or die "$bar\: $!\n";
    _save(@$biz);
    my @bar = keys %$boz;
    print BAR scalar(@bar), "\n";
    for $buz (@bar) {
	my $bar = '';
	for $foo ($buz, @{$boz->{$buz}}) {
	    my $foo = $foo;
	    $foo =~ s/[\s\n\000-\037\177-\377:]/sprintf(":%d:", ord($&))/ge;
	    print BAR $bar, $foo;
	    $bar = ' ';
	}
	print BAR "\n";
    }
    _save(@$bez);
    @bar = keys %$baz;
    print BAR scalar(@bar), "\n";
    for $buz (@bar) {
	my $bar = '';
	for $foo ($buz, $baz->{$buz}) {
	    my $foo = $foo;
	    $foo =~ s/[\s\n\000-\037\177-\377:]/sprintf(":%d:", ord($&))/ge;
	    print BAR $bar, $foo;
	    $bar = ' ';
	}
	print BAR "\n";
    }
    close BAR;
}

sub _save {
    my @foo = @_;
    my ($buz);
    print BAR '@' . scalar(@foo), "\n";
    for $buz (@foo) {
	if (ref $buz) {
	    _save(@$buz);
	} else {
	    my $buz = $buz;
	    $buz =~ s([\s\n\000-\037\177-\377:\@\$])
		     (sprintf(":%d:", ord($&)))ge;
	    print BAR '$', $buz, "\n";
	}
    }
}

sub load {
    my ($fubar, $fubaz, $fufoo) = caller;
    @_ == 2 or die "SYNTAX IS LOAD NAME at $fubaz (line $fufoo)\n";
    my ($foo, $bar) = @_;
    open(BAR, '< ' . $bar) or die "$bar\: $!\n";
    my @foo = @{_load()};
    my %foo = ();
    $foo = <BAR>;
    chomp $foo;
    while ($foo-- > 0) {
	my $foo = <BAR>;
	chomp $foo;
	my @bar = split(/ /, $foo);
	for (@bar) {
	    s/:(\d+):/sprintf("%c", $1)/ge;
	}
	my $bar = shift @bar;
	$foo{$bar} = \@bar;
    }
    my @fop = @{_load()};
    my %fop = ();
    $foo = <BAR>;
    chomp $foo;
    while ($foo-- > 0) {
	my $foo = <BAR>;
	chomp $foo;
	my @bar = split(/ /, $foo);
	for (@bar) {
	    s/:(\d+):/sprintf("%c", $1)/ge;
	}
	my $bar = shift @bar;
	$fop{$bar} = shift @bar;
    }
    close BAR;
    bless [\@foo, \%foo, \@fop, \%fop, $bar];
}

sub _load {
    my $foo = <BAR>;
    chomp $foo;
    $foo =~ s/^.//;
    if ($& eq '$') {
	$foo =~ s/:(\d+):/sprintf("%c", $1)/ge;
	return $foo;
    } elsif ($& eq '@') {
	my @foo = ();
	while ($foo-- > 0) {
	    push @foo, _load();
	}
	return \@foo;
    } else {
	die "497 INVALID OBJECT FORMAT\n";
    }
}

sub unimport {
    my ($fubar, $fubaz, $fufoo) = caller;
    die "$fubaz (line $fufoo) attempted to remove INTERCAL!\n";
}

sub _remove_spaces {
    $_[0] =~ s/^[\011\015\012\100]+//;
}

sub _parse_abstain {
    my %zaz = (
	"\301\302\342\343\301\311\325\311\325\307"     => [qw(ABSTAIN GABSTAIN FORK GFORK)],
	"\331\305\311\325\342\343\301\343\311\325\307" => [qw(REINSTATE GREINSTATE FORK GFORK)],
	"\305\325\342\323\301\345\311\325\307"         => [qw(ENSLAVE)],
	"\305\342\303\301\327\311\325\307"             => [qw(FREE)],
	"\303\301\323\303\344\323\301\343\311\325\307" => [qw(ASSIGN SASSIGN)],
	"\303\326\324\311\325\307"                     => [qw(COME CCOME)],
	"\303\326\324\311\325\307\306\331\326\324"     => [qw(COME CCOME)],
	"\346\331\311\343\311\325\307"                 => [qw(WRITE)],
	"\346\331\311\343\311\325\307\311\325"         => [qw(WRITE)],
	"\331\305\301\304\311\325\307"                 => [qw(READ)],
	"\331\305\301\304\311\325\307\326\344\343"     => [qw(READ)],
	"\325\305\347\343\311\325\307"                 => [qw(NEXT)],
	"\307\311\345\311\325\307"                     => [()],
	"\307\311\345\311\325\307\344\327"             => [()],
	"\331\305\342\344\324\311\325\307"             => [qw(RESUME)],
	"\306\326\331\307\305\343\343\311\325\307"     => [qw(FORGET)],
	"\311\307\325\326\331\311\325\307"             => [qw(IGNORE VFORK)],
	"\331\305\324\305\324\302\305\331\311\325\307" => [qw(REMEMBER VFORK)],
	"\342\343\301\342\310\311\325\307"             => [qw(STASH)],
	"\331\305\343\331\311\305\345\311\325\307"     => [qw(RETRIEVE)],
	"\305\325\331\326\323\323\311\325\307"         => [qw(ENROL)],
	"\342\343\344\304\350\311\325\307"             => [qw(STUDY)],
	"\323\305\301\331\325\311\325\307"             => [qw(LEARN)],
	"\307\331\301\304\344\301\343\311\325\307"     => [qw(GRADUATE)],
	"\306\311\325\311\342\310\311\325\307"         => [qw(FINISH)],
	"\306\311\325\311\342\310\311\325\307\323\305\303\343\344\331\305"
						       => [qw(FINISH)],
    );
    if ($_[0] =~ s/^\115([\360-\371]+)\135//) {
	(my $bub = $1) =~ tr[\360-\371][\060-\071];
	$bub =~ s/^0+(\d)/$1/;
	return (72, '') if $bub < 1 || $bub > 65535;
	_remove_spaces($_[0]);
	return ('', '(' . _roman($bub) . ')', $bub);
    }

    if ($_[0] =~ s/^
		   ([\201\301][\202\302][\242\342][\243\343][\201\301]
		    [\211\311][\225\325][\211\311][\225\325][\207\307]
		   |[\231\331][\205\305][\211\311][\225\325][\242\342]
		    [\243\343][\201\301][\243\343][\211\311][\225\325]
		    [\207\307]
		   |[\205\305][\225\325][\242\342][\223\323][\201\301]
		    [\245\345][\211\311][\225\325][\207\307]
		   |[\203\303][\201\301][\223\323][\203\303][\244\344]
		    [\223\323][\201\301][\243\343][\211\311][\225\325]
		    [\207\307]
		   |[\203\303][\226\326][\224\324][\211\311][\225\325]
		    [\207\307]
		    [\011\015\012\100]*(?:[\206\306][\231\331][\226\326][\224\324])?
		   |[\246\346][\231\331][\211\311][\243\343][\211\311]
		    [\225\325][\207\307]
		    [\011\015\012\100]*(?:[\211\311][\225\325])?
		   |[\231\331][\205\305][\201\301][\204\304][\211\311]
		    [\225\325][\207\307]
		    [\011\015\012\100]*(?:[\236\326][\244\344][\243\343])?
		   |[\225\325][\205\305][\247\347][\243\343][\211\311]
		    [\225\325][\207\307]
		   |[\207\307][\211\311][\245\345][\211\311][\225\325]
		    [\207\307]
		    [\011\015\012\100]*(?:[\244\344][\227\327])?
		   |[\231\331][\205\305][\242\342][\244\344][\224\324]
		    [\211\311][\225\325][\207\307]
		   |[\206\306][\226\326][\231\331][\207\307][\205\305]
		    [\243\343][\243\343][\211\311][\225\325][\207\307]
		   |[\211\311][\207\307][\235\335][\226\326][\231\331]
		    [\211\311][\225\325][\207\307]
		   |[\231\331][\205\305][\224\324][\205\305][\224\324]
		    [\202\302][\205\305][\231\331][\211\311][\225\325]
		    [\207\307]
		   |[\242\342][\243\343][\201\301][\242\342][\210\310]
		    [\211\311][\225\325][\207\307]
		   |[\231\331][\205\305][\243\343][\231\331][\211\311]
		    [\205\305][\245\345][\211\311][\225\325][\207\307]
		   |[\205\305][\242\342][\203\303][\201\301][\227\327]
		    [\211\311][\225\325][\207\307]
		   |[\205\305][\225\325][\231\331][\226\326][\223\323]
		    [\223\323][\211\311][\225\325][\207\307]
		   |[\242\342][\243\343][\244\344][\204\304][\250\350]
		    [\211\311][\225\325][\207\307]
		   |[\223\323][\205\305][\201\301][\231\331][\225\325]
		    [\211\311][\225\325][\207\307]
		   |[\207\307][\231\331][\201\301][\204\304][\244\344]
		    [\201\301][\243\343][\211\311][\225\325][\207\307]
		   |[\206\306][\211\311][\225\325][\211\311][\242\342]
		    [\210\310][\211\311][\225\325][\207\307]
		    [\011\015\012\100]*(?:[\223\323][\205\305][\203\303][\243\343]
		    [\244\344][\211\311][\205\305])?
		   )//x)
    {
	my $bub = $1;
	$bub =~ tr[\200-\277][\300-\377];
	$bub =~ s/[\011\015\012\100]//g;
	_remove_spaces($_[0]);
	my $Bub = ebcdic2ascii($bub);
	$bub = $zaz{$bub};
	my @fop = ('G', $Bub, @$bub);
	while ($_[0] =~ s/^\116[\011\015\012\100]*
			  ([\201\301][\202\302][\242\342][\243\343][\201\301]
			   [\211\311][\225\325][\211\311][\225\325][\207\307]
			  |[\231\331][\205\305][\211\311][\225\325][\242\342]
			   [\243\343][\201\301][\243\343][\211\311][\225\325]
			   [\207\307]
			  |[\205\305][\225\325][\242\342][\223\323][\201\301]
			   [\245\345][\211\311][\225\325][\207\307]
			  |[\203\303][\201\301][\223\323][\203\303][\244\344]
			   [\223\323][\201\301][\243\343][\211\311][\225\325]
			   [\207\307]
			  |[\203\303][\226\326][\224\324][\211\311][\225\325]
			   [\207\307]
			   [\011\015\012\100]*(?:[\206\306][\231\331][\226\326][\224\324])?
			  |[\246\346][\231\331][\211\311][\243\343][\211\311]
			   [\225\325][\207\307]
			   [\011\015\012\100]*(?:[\211\311][\225\325])?
			  |[\231\331][\205\305][\201\301][\204\304][\211\311]
			   [\225\325][\207\307]
			   [\011\015\012\100]*(?:[\236\326][\244\344][\243\343])?
			  |[\225\325][\205\305][\247\347][\243\343][\211\311]
			   [\225\325][\207\307]
			  |[\207\307][\211\311][\245\345][\211\311][\225\325]
			   [\207\307]
			   [\011\015\012\100]*(?:[\244\344][\227\327])?
			  |[\231\331][\205\305][\242\342][\244\344][\224\324]
			   [\211\311][\225\325][\207\307]
			  |[\206\306][\226\326][\231\331][\207\307][\205\305]
			   [\243\343][\243\343][\211\311][\225\325][\207\307]
			  |[\211\311][\207\307][\235\335][\226\326][\231\331]
			   [\211\311][\225\325][\207\307]
			  |[\231\331][\205\305][\224\324][\205\305][\224\324]
			   [\202\302][\205\305][\231\331][\211\311][\225\325]
			   [\207\307]
			  |[\242\342][\243\343][\201\301][\242\342][\210\310]
			   [\211\311][\225\325][\207\307]
			  |[\231\331][\205\305][\243\343][\231\331][\211\311]
			   [\205\305][\245\345][\211\311][\225\325][\207\307]
			  |[\205\305][\242\342][\203\303][\201\301][\227\327]
			   [\211\311][\225\325][\207\307]
			  |[\205\305][\225\325][\231\331][\226\326][\223\323]
			   [\223\323][\211\311][\225\325][\207\307]
			  |[\242\342][\243\343][\244\344][\204\304][\250\350]
			   [\211\311][\225\325][\207\307]
			  |[\223\323][\205\305][\201\301][\231\331][\225\325]
			   [\211\311][\225\325][\207\307]
			  |[\207\307][\231\331][\201\301][\204\304][\244\344]
			   [\201\301][\243\343][\211\311][\225\325][\207\307]
			  |[\206\306][\211\311][\225\325][\211\311][\242\342]
			   [\210\310][\211\311][\225\325][\207\307]
			   [\011\015\012\100]*(?:[\223\323][\205\305][\203\303][\243\343]
			   [\244\344][\211\311][\205\305])?
			  )//x)
	{
	    my $bub = $1;
	    $bub =~ tr[\200-\277][\300-\377];
	    $bub =~ s/[\011\015\012\100]//g;
	    _remove_spaces($_[0]);
	    my $Bub = ebcdic2ascii($bub);
	    $bub = $zaz{$bub};
	    $fop[1] .= ' + ' . $Bub;
	    push @fop, @$bub;
	}
	return @fop;
    }
    return (1, '');
}

sub _parse_ignore {
    my ($splat, $reg, $text) = _parse_register($_[0]);
    return ($splat, $text, $reg) if $splat;
    my @reg = ($reg);
    while ($_[0] =~ s/^\116//) {
	_remove_spaces($_[0]);
	my $ntext;
	($splat, $reg, $ntext) = _parse_register($_[0]);
	return ($splat, $text, @reg) if $splat;
	$text .= ' + ' . $ntext;
	push @reg, $reg;
    }
    return ($splat, $text, @reg);
}

sub _parse_register {
    my $belongs = '';

    while ($_[0] =~ s/^[\133\362-\371]//) {
	(my $bcc = $&) =~ tr[\133\362-\371][\044\062-\071];
	$belongs .= $bcc;
	_remove_spaces($_[0]);
    }

    $_[0] =~ s/^[\113\153\172\136\174]// or return (299, '', '');
    (my $prefix = $&) =~ tr[\113\153\172\136\174][\056\054\072\073\100];
    _remove_spaces($_[0]);

    my $logop = '';
    my $lognam = '';

    if ($_[1] && $_[0] =~ s/^[\145\120\345]//) {
	($logop = $&) =~ tr[\145\120\345][\245\046\126];
	_remove_spaces($_[0]);
	$lognam = {"\245" => 'XOR', "\046" => 'AND', "\126" => 'OR'}->{$logop};
    }

    $_[0] =~ s/^[\360-\371]+// or return (299, '', '');
    (my $number = $&) =~ tr[\360-\371][\060-\071];
    $number =~ s/^0+(\d)/$1/;
    return (299, '', '') if $number < 1 || $number > 65535;
    _remove_spaces($_[0]);

    my $Belongs = join(' ', map { $_ eq '$' ? $_ : _roman($_) }
			    (split(/ */, $belongs)));
    $Belongs .= $prefix;
    my $cname = _roman($number);
    my $creg = $belongs . $prefix . $number;

    if ($logop ne '') {
	$cname = $logop . $cname;
	$creg = [$lognam, ['REGISTER', $creg]];
    } elsif ($_[1]) {
	$creg = ['REGISTER', $creg];
    }

    return (0, $creg, $Belongs . $cname);
}

sub _parse_constant {
    $_[0] =~ s/^\173// or return (199, '', '');
    _remove_spaces($_[0]);

    my $logop = '';
    my $lognam = '';

    if ($_[1] && $_[0] =~ s/^[\145\120\345]//) {
	($logop = $&) =~ tr[\145\120\345][\245\046\126];
	_remove_spaces($_[0]);
	$lognam = {"\245" => 'XOR', "\046" => 'AND', "\126" => 'OR'}->{$logop};
    }

    $_[0] =~ s/^[\360-\371]+// or return (99, '', '');
    (my $number = $&) =~ tr[\360-\371][\060-\071];
    $number =~ s/^0+(\d)/$1/;
    return (199, '', '') if $number > 65535;
    _remove_spaces($_[0]);

    my $cname = _roman($number);
    if ($logop ne '') {
	$cname = $logop . $cname;
	$number = [$lognam, ['CONSTANT', $number]];
    } elsif ($_[1]) {
	$number = ['CONSTANT', $number];
    }

    return (0, $number, '#' . $cname);
}

sub _parse {
    # this comment intentionally left blank
    my ($baz, $fooflux, $flux, $flix) = @_;
    # $fooflux = \*STDERR; # @@@@
    my @baz = ();
    my %baz = ();
    my $oof = 0;
    my $pof = 0;
    my %fof = ();
    _output($fooflux, sprintf("     %-16s%-16s%s\n\n",
			      'STMT #', '(LABEL)', 'STATEMENT'))
	if defined $fooflux;
    _remove_spaces($baz);
    my $orig = $baz;
    _remove_spaces($baz);
    while ($baz ne '') {
	my $splat = 0;
	my $foo = 0;
	my $fop = [1, 100];
	my $bar = 0;
	$oof ++;
	my @fop = ();
	if ($baz =~ s/^\115([\360-\371]+)\135//) {
	    ($foo = $1) =~ tr[\360-\371][\060-\071];
	    $foo =~ s/^0+(\d)/$1/;
	    $splat = 72 if $foo < 1 || $foo > 65535;
	    _remove_spaces($baz);
	    $orig = $baz;
	}
	if (! $splat) {
	    if ($baz =~ s/^[\227\327][\223\323][\205\305]
			   [\201\301][\242\342][\205\305]//x)
	    {
		_remove_spaces($baz);
		$baz =~ s/^[\204\304][\226\326]// and _remove_spaces($baz);
		$bar = ++ $pof;
	    } elsif ($baz =~ s/^[\204\304][\226\326]//) {
		_remove_spaces($baz);
	    } else {
		$splat = 81;
	    }
	}
	if (! $splat &&
	    $baz =~ s/^(?:[\225\325][\226\326\175][\243\343]|\137)//)
	{
	    _remove_spaces($baz);
	    $fop->[0] = 0;
	}
	my $double_oh_seven = '';
	if (! $splat && $baz =~ s/^\154//) {
	    _remove_spaces($baz);
	    if ($baz =~ s/^([\360-\371]+)//) {
		(my $fff = $1) =~ tr[\360-\371][\060-\071];
		$fff =~ s/^0+(\d)/$1/;
		$splat = 100 if $fff > 100 || $fff < 1;
		$fop->[1] = $fff;
		$double_oh_seven = ' %' . _roman($fff);
		_remove_spaces($baz);
	    } else {
		($splat, $double_oh_seven, $fop->[1]) =
		    _parse_expression($baz);
		$double_oh_seven = ' %' . $double_oh_seven;
	    }
	}
	my $good = 0;
	VERB: while (! $splat) {
	    if ($baz =~ s/^([\201\301][\202\302][\242\342][\243\343]
			    [\201\301][\211\311][\225\325])//x)
	    {
		_remove_spaces($baz);
		if ($baz =~ s/[\206\306][\231\331][\226\326][\224\324]//) {
		    _remove_spaces($baz);
		    my ($type, $text, @data) = _parse_abstain($baz);
		    if ($type =~ /^\d+$/) {
			$splat = $type;
		    } else {
			@fop = ("ABSTAIN FROM " . $text,
				$type . 'ABSTAIN', @data);
			$good = 1;
		    }
		    if ($baz =~ /^[\246\346][\210\310][\211\311]
				  [\223\323][\205\305]/x)
		    {
			my $bar = $';
			_remove_spaces($bar);
			if ($bar =~ s/^[\231\331][\205\305][\211\311][\225\325]
				       [\242\342][\243\343][\201\301][\243\343]
				       [\211\311][\225\325][\207\307]//x)
		        {
			    _remove_spaces($bar);
			    if ($bar =~ s/^[\211\311][\243\343]//) {
				_remove_spaces($bar);
				$baz = $bar;
				$fop[0] .= ' WHILE REINSTATING IT';
				$fop[1] = $type . 'FORK';
			    }
			}
		    }
		} else {
		    $splat = 87;
		}
		last VERB;
	    }
	    if ($baz =~ s/^([\231\331][\205\305][\211\311][\225\325][\242\342]
			    [\243\343][\201\301][\243\343][\205\305])//x)
	    {
		_remove_spaces($baz);
		my ($type, $text, @data) = _parse_abstain($baz);
		if ($type =~ /^\d+$/) {
		    $splat = $type;
		} else {
		    @fop = ("REINSTATE " . $text,
			    $type . 'REINSTATE', @data);
		    $good = 1;
		    if ($baz =~ /^[\246\346][\210\310][\211\311]
				  [\223\323][\205\305]/x)
		    {
			my $bar = $';
			_remove_spaces($bar);
			if ($bar =~ s/^[\201\301][\202\302][\242\342][\243\343]
				       [\201\301][\211\311][\225\325][\211\311]
				       [\225\325][\207\307]//x)
		        {
			    _remove_spaces($bar);
			    if ($bar =~ s/^[\206\306][\231\331]
					   [\226\326][\224\324]//x)
			    {
				_remove_spaces($bar);
				if ($bar =~ s/^[\211\311][\243\343]//) {
				    _remove_spaces($bar);
				    $baz = $bar;
				    $fop[0] .= ' WHILE ABSTAINING FROM IT';
				    $fop[1] = $type . 'FORK';
				}
			    }
			}
		    }
		}
		last VERB;
	    }
	    if ($baz =~ s/^[\205\305][\225\325][\242\342][\223\323][\201\301]
			   [\245\345][\205\305]//x)
	    {
		_remove_spaces($baz);
		my ($slave, $stext);
		($splat, $slave, $stext) = _parse_register($baz);
		last VERB if $splat;
		$baz =~ s/^[\243\343][\226\326]// or do {
		    $splat = 112;
		    last VERB;
		};
		_remove_spaces($baz);
		my ($master, $mtext);
		($splat, $master, $mtext) = _parse_register($baz);
		last VERB if $splat;
		@fop = ("ENSLAVE $stext TO $mtext", 'ENSLAVE', $slave, $master);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\206\306][\231\331][\205\305][\205\305]//) {
		_remove_spaces($baz);
		my ($slave, $stext);
		($splat, $slave, $stext) = _parse_register($baz);
		last VERB if $splat;
		$baz =~ s/^[\206\306][\231\331][\226\326][\224\324]// or do {
		    $splat = 116;
		    last VERB;
		};
		_remove_spaces($baz);
		my ($master, $mtext);
		($splat, $master, $mtext) = _parse_register($baz);
		last VERB if $splat;
		@fop = ("FREE $stext FROM $mtext", 'FREE', $slave, $master);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\211\311][\207\307][\225\325][\226\326]
			   [\231\331][\205\305]//x)
	    {
		_remove_spaces($baz);
		my ($ign, @list);
		($splat, $ign, @list) = _parse_ignore($baz);
		last VERB if $splat;
		@fop = ("IGNORE " . $ign, 'IGNORE', @list);
		$good = 1;
		if ($baz =~ /^[\246\346][\210\310][\211\311]
			      [\223\323][\205\305]/x)
		{
		    my $bar = $';
		    _remove_spaces($bar);
		    if ($bar =~ s/^[\231\331][\205\305][\224\324][\205\305]
				   [\224\324][\202\302][\205\305][\231\331]
				   [\211\311][\225\325][\207\307]//x)
		    {
			_remove_spaces($bar);
			if ($bar =~ s/^[\211\311][\243\343]
				      |[\243\343][\210\310][\205\305][\224\324]//x)
			{
			    _remove_spaces($bar);
			    $baz = $bar;
			    $fop[0] .= ' WHILE REMEMBERING ';
			    $fop[0] .= @list > 1 ? 'THEM' : 'IT';
			    $fop[1] = 'VFORK';
			}
		    }
		}
		last VERB;
	    }
	    if ($baz =~ s/^[\231\331][\205\305][\224\324][\205\305]
			   [\224\324][\202\302][\205\305][\231\331]//x)
	    {
		_remove_spaces($baz);
		my ($ign, @list);
		($splat, $ign, @list) = _parse_ignore($baz);
		last VERB if $splat;
		@fop = ("REMEMBER " . $ign, 'REMEMBER', @list);
		$good = 1;
		if ($baz =~ /^[\246\346][\210\310][\211\311]
			      [\223\323][\205\305]/x)
		{
		    my $bar = $';
		    _remove_spaces($bar);
		    if ($bar =~ s/^[\211\311][\207\307][\225\325][\226\326]
				   [\231\331][\211\311][\225\325][\207\307]//x)
		    {
			_remove_spaces($bar);
			if ($bar =~ s/^[\211\311][\243\343]
				      |[\243\343][\210\310][\205\305][\224\324]//x)
			{
			    _remove_spaces($bar);
			    $baz = $bar;
			    $fop[0] .= ' WHILE IGNORING ';
			    $fop[0] .= @list > 1 ? 'THEM' : 'IT';
			    $fop[1] = 'VFORK';
			}
		    }
		}
		last VERB;
	    }
	    if ($baz =~ s/^[\242\342][\243\343][\201\301][\242\342][\210\310]//)
	    {
		_remove_spaces($baz);
		my ($ign, @list);
		($splat, $ign, @list) = _parse_ignore($baz);
		last VERB if $splat;
		@fop = ("STASH " . $ign, 'STASH', @list);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\231\331][\205\305][\243\343][\231\331]
			   [\211\311][\205\305][\245\345][\205\305]//x)
	    {
		_remove_spaces($baz);
		my ($ign, @list);
		($splat, $ign, @list) = _parse_ignore($baz);
		last VERB if $splat;
		@fop = ("RETRIEVE " . $ign, 'RETRIEVE', @list);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\205\305][\225\325][\231\331]
			   [\226\326][\223\323][\223\323]?//x)
	    {
		_remove_spaces($baz);
		if (length($&) > 5) {
		    $splat = 201;
		    last VERB;
		}
		my ($student, $stext);
		($splat, $student, $stext) = _parse_register($baz);
		last VERB if $splat;
		$baz =~ s/^[\243\343][\226\326]// or do {
		    $splat = 202;
		    last VERB;
		};
		_remove_spaces($baz);
		$baz =~ s/^[\223\323][\205\305]
			   [\201\301][\231\331][\225\325]//x or do
		{
		    $splat = 202;
		    last VERB;
		};
		_remove_spaces($baz);
		my ($subject, $jtext);
		($splat, $subject, $jtext) = _parse_constant($baz, 0);
		last VERB if $splat;
		@fop = ("ENROL $stext TO LEARN $jtext",
			'ENROL', $student, $subject);
		while ($baz =~ s/^\116//) {
		    _remove_spaces($baz);
		    ($splat, $subject, $jtext) = _parse_constant($baz, 0);
		    last VERB if $splat;
		    $fop[0] .= ' + ' . $jtext;
		    push @fop, $subject;
		}
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\242\342][\243\343][\244\344][\204\304][\250\350]//)
	    {
		_remove_spaces($baz);
		my ($subject, $jtext);
		($splat, $subject, $jtext) = _parse_constant($baz, 0);
		last VERB if $splat;
		$baz =~ s/^[\201\301][\243\343]// or do {
		    $splat = 252;
		    last VERB;
		};
		_remove_spaces($baz);
		if ($baz !~ s/^\115([\360-\371]+)\135//) {
		    $splat = 252;
		    last VERB;
		}
		(my $foo = $1) =~ tr[\360-\371][\060-\071];
		$foo =~ s/^0+(\d)/$1/;
		$splat = 999 if $foo < 1000;
		$splat = 72 if $foo > 65535;
		last VERB if $splat;
		my $Foo = _roman($foo);
		_remove_spaces($baz);
		$baz =~ s/^[\211\311][\225\325]// or do {
		    $splat = 252;
		    last VERB;
		};
		_remove_spaces($baz);
		$baz =~ s/^[\203\303][\223\323]
			   [\201\301][\242\342][\242\342]//x or do
		{
		    $splat = 252;
		    last VERB;
		};
		_remove_spaces($baz);
		my ($class, $ctext);
		($splat, $class, $ctext) = _parse_register($baz);
		last VERB if $splat;
		if ($class !~ /^\@/) {
		    $splat = 252;
		    last VERB;
		}
		@fop = ("STUDY $jtext AT ($Foo) IN CLASS $ctext",
			'STUDY', $subject, $foo, $class);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\206\306][\211\311][\225\325][\211\311]
			   [\242\342][\210\310]//x)
	    {
		_remove_spaces($baz);
		$baz =~ s/^[\223\323][\205\305][\203\303][\243\343]
			   [\244\344][\231\331][\205\305]//x or do
		{
		    $splat = 87;
		    last VERB;
		};
		@fop = ("FINISH LECTURE", 'FINISH');
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\203\303][\226\326][\224\324][\205\305]//) {
		_remove_spaces($baz);
		$baz =~ s/^[\206\306][\231\331][\226\326][\224\324]// or do {
		    $splat = 87;
		    last VERB;
		};
		_remove_spaces($baz);
		if ($baz =~ s/^\115([\360-\371]+)\135//) {
		    _remove_spaces($baz);
		    (my $bub = $1) =~ tr[\360-\371][\060-\071];
		    $bub =~ s/^0+(\d)/$1/;
		    $splat = 72 if $bub < 1 || $bub > 65535;
		    last VERB if $splat;
		    _remove_spaces($baz);
		    my $Bub = _roman($bub);
		    @fop = ("COME FROM ($Bub)", 'COME', $bub);
		    $good = 1;
		    last VERB;
		}
		my ($label, $ltext);
		($splat, $ltext, $label) = _parse_expression($baz);
		last VERB if $splat;
		@fop = ("COME FROM $ltext", 'CCOME', $label);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\246\346][\231\331][\211\311][\243\343][\205\305]//)
	    {
		_remove_spaces($baz);
		$baz =~ s/^[\211\311][\225\325]// or do {
		    $splat = 87;
		    last VERB;
		};
		_remove_spaces($baz);
		my ($reg, $rtext);
		($splat, $reg, $rtext) = _parse_register($baz);
		last VERB if $splat;
		@fop = ("WRITE IN $rtext", 'WRITE', $reg);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\231\331][\205\305][\201\301][\204\304]//)
	    {
		_remove_spaces($baz);
		$baz =~ s/^[\226\326][\244\344][\243\343]// or do {
		    $splat = 87;
		    last VERB;
		};
		_remove_spaces($baz);
		my ($reg, $rtext);
		($splat, $reg, $rtext) = _parse_register($baz);
		last VERB if $splat;
		@fop = ("READ OUT $rtext", 'READ', $reg);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\207\307][\211\311][\245\345][\205\305]//) {
		_remove_spaces($baz);
		$baz =~ s/^[\244\344][\227\327]// or do {
		    $splat = 87;
		    last VERB;
		};
		_remove_spaces($baz);
		@fop = ("GIVE UP", 'STOP');
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\231\331][\205\305][\242\342][\244\344]
			   [\224\324][\205\305]//x)
	    {
		_remove_spaces($baz);
		my ($expr, $etext);
		($splat, $etext, $expr) = _parse_expression($baz);
		last VERB if $splat;
		@fop = ("RESUME $etext", 'RESUME', $expr);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\206\306][\226\326][\231\331][\207\307]
			   [\205\305][\243\343]//x)
	    {
		_remove_spaces($baz);
		my ($expr, $etext);
		($splat, $etext, $expr) = _parse_expression($baz);
		last VERB if $splat;
		@fop = ("FORGET $etext", 'FORGET', $expr);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^\115([\360-\371]+)\135//) {
		(my $bub = $1) =~ tr[\360-\371][\060-\071];
		$bub =~ s/^0+(\d)/$1/;
		$splat = 72 if $bub < 1 || $bub > 65535;
		last VERB if $splat;
		_remove_spaces($baz);
		my $Bub = _roman($bub);
		$baz =~ s/^[\225\325][\205\305][\247\347][\243\343]// or do {
		    $splat = 0;
		    last VERB;
		};
		_remove_spaces($baz);
		@fop = ("($Bub) NEXT", 'NEXT', $bub);
		$good = 1;
		last VERB;
	    }
	    my ($err, $reg, $rtext) = _parse_register($baz);
	    if ($err) {
		$splat = 0;
		last VERB;
	    }
	    if ($baz =~ s/^[\223\323][\205\305][\201\301][\231\331]
			   [\225\325][\242\342]//x)
	    {
		_remove_spaces($baz);
		my ($subject, $jtext);
		($splat, $subject, $jtext) = _parse_constant($baz, 0);
		last VERB if $splat;
		@fop = ("$rtext LEARNS $jtext", 'LEARN', $reg, $subject);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\207\307][\231\331][\201\301][\204\304][\244\344]
			   [\201\301][\243\343][\205\305][\242\342]//x)
	    {
		_remove_spaces($baz);
		@fop = ("$rtext GRADUATES", 'GRADUATE', $reg);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^[\242\342][\244\344][\202\302]//) {
		_remove_spaces($baz);
		my ($stext, $sub);
		my @stext = ();
		my @sub = ();
		($splat, $stext, $sub) = _parse_expression($baz);
		last VERB if $splat;
		my $bbaz = $baz;
		while (! $splat) {
		    $bbaz = $baz;
		    push @stext, $stext;
		    push @sub, $sub;
		    ($splat, $stext, $sub) = _parse_expression($baz);
		}
		$splat = 0;
		$baz =~ s/^\114\140// or do {
		    $splat = 93;
		    last VERB;
		};
		_remove_spaces($baz);
		($splat, $stext, $sub) = _parse_expression($baz);
		last VERB if $splat;
		@fop = ("$rtext SUB @stext <- $stext",
			'SASSIGN', $reg, @sub, $sub);
		$good = 1;
		last VERB;
	    }
	    if ($baz =~ s/^\114\140//) {
		_remove_spaces($baz);
		my ($stext, $sub);
		($splat, $stext, $sub) = _parse_expression($baz);
		last VERB if $splat;
		@fop = ("$rtext <- $stext", 'ASSIGN', $reg, $sub);
		while ($baz =~ s/^[\202\302][\250\350]//) {
		    _remove_spaces($baz);
		    ($splat, $stext, $sub) = _parse_expression($baz);
		    last VERB if $splat;
		    $fop[0] .= ' BY ' . $stext;
		    push @fop, $sub;
		}
		$good = 1;
		last VERB;
	    }
	    last VERB;
	}
	if (! $good) {
	    if ($baz =~ /\115([\360-\371]+)\135
			|[\227\327][\223\323][\205\305]
			 [\201\301][\242\342][\205\305]
			|[\204\304][\226\326]/x)
	    {
		$baz = $& . $';
	    } else {
		$baz = '';
	    }
	    my $o = ebcdic2ascii(substr($orig, 0, length($orig) - length($baz)));
	    @fop = ($o, 'ILLEGAL', $splat, $o);
	}
	my $bub = shift @fop;
	if (defined $fooflux) {
	    my $fff = _roman($oof);
	    if ($good) {
		if (! $fop->[0]) {
		    $bub = ($bar ? "PLEASE DON'T" : "DON'T")
			 . $double_oh_seven . ' ' . $bub;
		} else {
		    $bub = ($bar ? "PLEASE" : "DO")
			 . $double_oh_seven . ' ' . $bub;
		}
	    }
	    my $ffo = $foo;
	    $splat = $good ? '' : "*$splat";
	    if (! $good) {
		while ($bub =~ /\t/) {
		    $bub = $` . (' ' x (8 - (length($`) % 8))) . $';
		}
	    }
	    do {
		my $bbb = substr($bub, 0, $fee + 1);
		length($bbb) >= $fee and $bbb =~ s/\s+$//;
		length($bbb) >= $fee and $bbb =~ s/\s+\S+$//;
		$bbb = $` if $bbb =~ /[\r\n]/;
		($bbb eq '' or length($bbb) >= $fee) and
			$bbb = substr($bub, 0, $fee - 1);
		my $bqq = $bbb;
		$faa or $bbb =~ s!�!c\010/!g;
		$fbb or $bbb =~ s!�!V\010-!g;
		_output($fooflux, sprintf("%-4s %-16s%-16s%s\n",
					  $splat,
					  $fff,
					  $ffo ? "(" . _roman($ffo) . ")" : "",
					  $bbb));
		$bub = substr($bub, length $bqq);
		$bub =~ s/^\s+//;
		$fff = '';
		$ffo = 0;
	    } while ($bub ne '');
	}
	push @baz, [$foo, $fop, @fop];
	push @{$baz{$fop[0]}}, $#baz;
	if ($foo) {
	    my $Foo = _roman($foo);
	    die "458 YOU LIKE THAT LABEL ($Foo) A LOT ($flux\:$flix [$oof])\n"
		if exists $fof{$foo};
	    $fof{$foo} = $#baz;
	}
	_remove_spaces($baz);
	$orig = $baz;
    }
    $pof * 3 > $oof and $oof > 5 and
	die "499 PROGRAMMER IS TOO POLITE ($flux\:$flix [$oof])\n";
    $pof * 5 < $oof and $oof > 5 and
	die "499 PROGRAMMER IS NOT POLITE ENOUGH ($flux\:$flix [$oof])\n";
    my $zaz = int(rand(scalar @baz));
    splice @baz, $zaz, 0, [0, [1, $fgg || $fhh], $fgg ? 'BUG' : 'UBUG'];
    for $baz (keys %baz) {
	my $zab;
	for $zab (@{$baz{$baz}}) {
	    $zab++ if $zab >= $zaz;
	}
    }
    for $baz (keys %fof) {
	$fof{$baz}++ if $fof{$baz} >= $zaz;
    }
    (\@baz, \%baz, [scalar @baz], \%fof);
}

sub _parse_expression {
    my ($splat, $text, $value);

    if ($_[0] =~ s/^[\175\177\117]//) {
	my $ear = $&;
	_remove_spaces($_[0]);
	my $baz = $_[0];
	if ($& eq "\117") {
	    $baz = "\113" . $baz;
	    $ear = "\175";
	}
	($splat, $text, $value) = _parse_expression($baz);
	(my $aer = $ear) =~ tr[\175\177][\047\042];
	$text = $aer . $text . $aer;
	$_[0] = $baz;
	$_[0] =~ s/^$ear// or $splat = $ear eq "\175" ? 398 : 399;
	_remove_spaces($_[0]);
    } else {
	($splat, $text, $value) = _parse_subexpression($_[0]);
    }
    return ($splat, $text, $value) if $splat;

    while ($_[0] =~ s/^[\112\241]//) {
	(my $op = $&) =~ tr[\112\241][\242\176];
	_remove_spaces($_[0]);
	my ($xsplat, $xtext, $xvalue) = _parse_expression($_[0]);
	return ($xsplat, $xtext, $xvalue) if $xsplat;
	$text .= ' ' . $op . ' ' . $xtext;
	$value = [$op eq '~' ? 'SELECT' : 'INTERLEAVE', $value, $xvalue];
    }

    return ($splat, $text, $value);
}

sub _parse_subexpression {
    if ($_[0] =~ /^[\175\177\117]/) {
	return _parse_expression($_[0]);
    }

    if ($_[0] =~ s/^[\145\120\345]//) {
	(my $fff = $&) =~ tr[\145\120\345][\245\046\126];
	_remove_spaces($_[0]);
	my ($splat, $text, $value) = _parse_expression($_[0]);
	$text = $fff . $text;
	return ($splat, $text, $value) if $splat;
	$value = [{"\245" => 'XOR', "\046" => 'AND', "\126" => 'OR'}->{$fff}, $value];
	return ($splat, $text, $value);
    }

    if ($_[0] =~ /^\173/) {
	return (_parse_constant($_[0], 1))[0, 2, 1];
    }

    my ($splat, $reg, $text) = _parse_register($_[0], 1);
    return ($splat, $text, $reg)
	if $splat || ! ($_[0] =~ s/^[\242\342][\244\344][\202\302]//);
    _remove_spaces($_[0]);
    my ($stext, $sub);
    ($splat, $stext, $sub) = _parse_expression($_[0]);
    return ($splat, $stext, $sub) if $splat;

    my $snam = ' SUB ';
    my $baz = $_[0];
    while (! $splat) {
	$_[0] = $baz;
	$text .= $snam . $stext;
	if ($reg->[0] eq 'REGISTER' || $reg->[0] eq 'SUBSCRIPT') {
	    $reg->[0] = 'SUBSCRIPT';
	    push @$reg, $sub;
	} else {
	    $reg->[1][0] = 'SUBSCRIPT';
	    push @{$reg->[1]}, $sub;
	}
	($splat, $stext, $sub) = _parse_expression($baz);
	$snam = ' ';
    }
    $splat = 0;
    return ($splat, $text, $reg);
}

1;
